﻿//-----------------------------------------------------------------------
// <copyright file="TramInvoeren.Designer.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
    public partial class TramInvoeren
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox tbTramNr;
        private System.Windows.Forms.TextBox tbSpoorNr;
        private System.Windows.Forms.TextBox tbSectorNr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbTramNr = new System.Windows.Forms.TextBox();
            this.tbSpoorNr = new System.Windows.Forms.TextBox();
            this.tbSectorNr = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbTramNr
            // 
            this.tbTramNr.Location = new System.Drawing.Point(68, 119);
            this.tbTramNr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbTramNr.Multiline = true;
            this.tbTramNr.Name = "tbTramNr";
            this.tbTramNr.Size = new System.Drawing.Size(132, 69);
            this.tbTramNr.TabIndex = 0;
            // 
            // tbSpoorNr
            // 
            this.tbSpoorNr.Location = new System.Drawing.Point(321, 119);
            this.tbSpoorNr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbSpoorNr.Multiline = true;
            this.tbSpoorNr.Name = "tbSpoorNr";
            this.tbSpoorNr.Size = new System.Drawing.Size(132, 69);
            this.tbSpoorNr.TabIndex = 1;
            // 
            // tbSectorNr
            // 
            this.tbSectorNr.Location = new System.Drawing.Point(560, 119);
            this.tbSectorNr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbSectorNr.Multiline = true;
            this.tbSectorNr.Name = "tbSectorNr";
            this.tbSectorNr.Size = new System.Drawing.Size(132, 69);
            this.tbSectorNr.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 73);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tramnummer:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(317, 73);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Spoornummer:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(568, 73);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Sectornummer:";
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(207, 249);
            this.btnOk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(128, 74);
            this.btnOk.TabIndex = 6;
            this.btnOk.Text = "OK!";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(444, 249);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(128, 74);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // TramInvoeren
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 374);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbSectorNr);
            this.Controls.Add(this.tbSpoorNr);
            this.Controls.Add(this.tbTramNr);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "TramInvoeren";
            this.Text = "TramInvoeren";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}