﻿//-----------------------------------------------------------------------
// <copyright file="SchoonmaakSysteem.Designer.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
    public partial class SchoonmaakSysteem
    {
        private System.Windows.Forms.Label lblTram;
        private System.Windows.Forms.Label lblKlaar;
        private System.Windows.Forms.Label lblBeurt;
        private System.Windows.Forms.Label lblSchoonmaker;
        private System.Windows.Forms.CheckBox cbKlaar;
        private System.Windows.Forms.Label lblTramnr;
        private System.Windows.Forms.Label lblSchoonmakerNaam;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnTerug;
        private System.Windows.Forms.Button btnOngedaanMaken;
        private System.Windows.Forms.ListView lvSchoonmaaklijst;
        private System.Windows.Forms.ColumnHeader soortBeurt;
        private System.Windows.Forms.ColumnHeader beginDatum;
        private System.Windows.Forms.ColumnHeader eindtijd;
        private System.Windows.Forms.ColumnHeader tramnr;
        private System.Windows.Forms.Label lblSoortBeurt;
        private System.Windows.Forms.ColumnHeader schoonmaker;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTram = new System.Windows.Forms.Label();
            this.lblKlaar = new System.Windows.Forms.Label();
            this.lblBeurt = new System.Windows.Forms.Label();
            this.lblSchoonmaker = new System.Windows.Forms.Label();
            this.cbKlaar = new System.Windows.Forms.CheckBox();
            this.lblTramnr = new System.Windows.Forms.Label();
            this.lblSchoonmakerNaam = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnTerug = new System.Windows.Forms.Button();
            this.btnOngedaanMaken = new System.Windows.Forms.Button();
            this.lvSchoonmaaklijst = new System.Windows.Forms.ListView();
            this.soortBeurt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.beginDatum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.eindtijd = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tramnr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.schoonmaker = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblSoortBeurt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpBeginDatum = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lblTram
            // 
            this.lblTram.AutoSize = true;
            this.lblTram.Location = new System.Drawing.Point(13, 73);
            this.lblTram.Name = "lblTram";
            this.lblTram.Size = new System.Drawing.Size(34, 13);
            this.lblTram.TabIndex = 4;
            this.lblTram.Text = "Tram:";
            // 
            // lblKlaar
            // 
            this.lblKlaar.AutoSize = true;
            this.lblKlaar.Location = new System.Drawing.Point(13, 163);
            this.lblKlaar.Name = "lblKlaar";
            this.lblKlaar.Size = new System.Drawing.Size(31, 13);
            this.lblKlaar.TabIndex = 5;
            this.lblKlaar.Text = "Klaar";
            // 
            // lblBeurt
            // 
            this.lblBeurt.AutoSize = true;
            this.lblBeurt.Location = new System.Drawing.Point(13, 104);
            this.lblBeurt.Name = "lblBeurt";
            this.lblBeurt.Size = new System.Drawing.Size(35, 13);
            this.lblBeurt.TabIndex = 6;
            this.lblBeurt.Text = "Beurt:";
            // 
            // lblSchoonmaker
            // 
            this.lblSchoonmaker.AutoSize = true;
            this.lblSchoonmaker.Location = new System.Drawing.Point(13, 134);
            this.lblSchoonmaker.Name = "lblSchoonmaker";
            this.lblSchoonmaker.Size = new System.Drawing.Size(76, 13);
            this.lblSchoonmaker.TabIndex = 7;
            this.lblSchoonmaker.Text = "Schoonmaker:";
            // 
            // cbKlaar
            // 
            this.cbKlaar.AutoSize = true;
            this.cbKlaar.Enabled = false;
            this.cbKlaar.Location = new System.Drawing.Point(91, 162);
            this.cbKlaar.Name = "cbKlaar";
            this.cbKlaar.Size = new System.Drawing.Size(15, 14);
            this.cbKlaar.TabIndex = 8;
            this.cbKlaar.UseVisualStyleBackColor = true;
            this.cbKlaar.CheckedChanged += new System.EventHandler(this.CbKlaar_CheckedChanged);
            // 
            // lblTramnr
            // 
            this.lblTramnr.AutoSize = true;
            this.lblTramnr.Location = new System.Drawing.Point(88, 73);
            this.lblTramnr.Name = "lblTramnr";
            this.lblTramnr.Size = new System.Drawing.Size(10, 13);
            this.lblTramnr.TabIndex = 9;
            this.lblTramnr.Text = "-";
            // 
            // lblSchoonmakerNaam
            // 
            this.lblSchoonmakerNaam.AutoSize = true;
            this.lblSchoonmakerNaam.Location = new System.Drawing.Point(88, 134);
            this.lblSchoonmakerNaam.Name = "lblSchoonmakerNaam";
            this.lblSchoonmakerNaam.Size = new System.Drawing.Size(10, 13);
            this.lblSchoonmakerNaam.TabIndex = 10;
            this.lblSchoonmakerNaam.Text = "-";
            // 
            // btnOk
            // 
            this.btnOk.Enabled = false;
            this.btnOk.Location = new System.Drawing.Point(10, 191);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 12;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.BtnOk_Click);
            // 
            // btnTerug
            // 
            this.btnTerug.Location = new System.Drawing.Point(10, 11);
            this.btnTerug.Name = "btnTerug";
            this.btnTerug.Size = new System.Drawing.Size(75, 23);
            this.btnTerug.TabIndex = 13;
            this.btnTerug.Text = "Terug";
            this.btnTerug.UseVisualStyleBackColor = true;
            this.btnTerug.Click += new System.EventHandler(this.BtnTerug_Click);
            // 
            // btnOngedaanMaken
            // 
            this.btnOngedaanMaken.Enabled = false;
            this.btnOngedaanMaken.Location = new System.Drawing.Point(91, 191);
            this.btnOngedaanMaken.Name = "btnOngedaanMaken";
            this.btnOngedaanMaken.Size = new System.Drawing.Size(102, 23);
            this.btnOngedaanMaken.TabIndex = 14;
            this.btnOngedaanMaken.Text = "Ongedaan maken";
            this.btnOngedaanMaken.UseVisualStyleBackColor = true;
            this.btnOngedaanMaken.Click += new System.EventHandler(this.BtnOngedaanMaken_Click);
            // 
            // lvSchoonmaaklijst
            // 
            this.lvSchoonmaaklijst.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.soortBeurt,
            this.beginDatum,
            this.eindtijd,
            this.tramnr,
            this.schoonmaker});
            this.lvSchoonmaaklijst.Location = new System.Drawing.Point(10, 220);
            this.lvSchoonmaaklijst.Name = "lvSchoonmaaklijst";
            this.lvSchoonmaaklijst.Size = new System.Drawing.Size(454, 160);
            this.lvSchoonmaaklijst.TabIndex = 16;
            this.lvSchoonmaaklijst.UseCompatibleStateImageBehavior = false;
            this.lvSchoonmaaklijst.View = System.Windows.Forms.View.Details;
            this.lvSchoonmaaklijst.SelectedIndexChanged += new System.EventHandler(this.LvSchoonmaaklijst_SelectedIndexChanged);
            // 
            // soortBeurt
            // 
            this.soortBeurt.Text = "Soort beurt";
            this.soortBeurt.Width = 80;
            // 
            // beginDatum
            // 
            this.beginDatum.Text = "Begin datum";
            this.beginDatum.Width = 81;
            // 
            // eindtijd
            // 
            this.eindtijd.Text = "Eind Datum/tijd";
            this.eindtijd.Width = 110;
            // 
            // tramnr
            // 
            this.tramnr.Text = "Tram nummer";
            this.tramnr.Width = 81;
            // 
            // schoonmaker
            // 
            this.schoonmaker.Text = "Schoonmaker";
            this.schoonmaker.Width = 98;
            // 
            // lblSoortBeurt
            // 
            this.lblSoortBeurt.AutoSize = true;
            this.lblSoortBeurt.Location = new System.Drawing.Point(88, 104);
            this.lblSoortBeurt.Name = "lblSoortBeurt";
            this.lblSoortBeurt.Size = new System.Drawing.Size(10, 13);
            this.lblSoortBeurt.TabIndex = 17;
            this.lblSoortBeurt.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Begin Datum:";
            // 
            // dtpBeginDatum
            // 
            this.dtpBeginDatum.CustomFormat = "dd-MM-yyyy";
            this.dtpBeginDatum.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpBeginDatum.Location = new System.Drawing.Point(90, 41);
            this.dtpBeginDatum.Name = "dtpBeginDatum";
            this.dtpBeginDatum.Size = new System.Drawing.Size(84, 20);
            this.dtpBeginDatum.TabIndex = 19;
            this.dtpBeginDatum.ValueChanged += new System.EventHandler(this.dtpBeginDatum_ValueChanged);
            // 
            // SchoonmaakSysteem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 388);
            this.Controls.Add(this.dtpBeginDatum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSoortBeurt);
            this.Controls.Add(this.lvSchoonmaaklijst);
            this.Controls.Add(this.btnOngedaanMaken);
            this.Controls.Add(this.btnTerug);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.lblSchoonmakerNaam);
            this.Controls.Add(this.lblTramnr);
            this.Controls.Add(this.cbKlaar);
            this.Controls.Add(this.lblSchoonmaker);
            this.Controls.Add(this.lblBeurt);
            this.Controls.Add(this.lblKlaar);
            this.Controls.Add(this.lblTram);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "SchoonmaakSysteem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Schoonmaak";
            this.Load += new System.EventHandler(this.SchoonmaakSysteem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpBeginDatum;
    }
}