﻿//-----------------------------------------------------------------------
// <copyright file="WachtwoordVergeten.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    public partial class WachtwoordVergeten : Form
    {
        public WachtwoordVergeten()
        {
            this.InitializeComponent();
        }
    }
}
