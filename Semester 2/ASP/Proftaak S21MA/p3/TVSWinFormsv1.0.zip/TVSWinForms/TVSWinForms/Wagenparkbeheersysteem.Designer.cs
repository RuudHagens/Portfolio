﻿namespace TVSWinForms
{
    partial class Wagenparkbeheersysteem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb38 = new System.Windows.Forms.TextBox();
            this.tb37 = new System.Windows.Forms.TextBox();
            this.tb36 = new System.Windows.Forms.TextBox();
            this.tb35 = new System.Windows.Forms.TextBox();
            this.tb34 = new System.Windows.Forms.TextBox();
            this.tb33 = new System.Windows.Forms.TextBox();
            this.tb32 = new System.Windows.Forms.TextBox();
            this.tb31 = new System.Windows.Forms.TextBox();
            this.tb30 = new System.Windows.Forms.TextBox();
            this.tb44 = new System.Windows.Forms.TextBox();
            this.tb43 = new System.Windows.Forms.TextBox();
            this.tb42 = new System.Windows.Forms.TextBox();
            this.tb41 = new System.Windows.Forms.TextBox();
            this.tb40 = new System.Windows.Forms.TextBox();
            this.tb58 = new System.Windows.Forms.TextBox();
            this.tb45 = new System.Windows.Forms.TextBox();
            this.tb45l = new System.Windows.Forms.TextBox();
            this.tb58c1 = new System.Windows.Forms.TextBox();
            this.tb40c1 = new System.Windows.Forms.TextBox();
            this.tb41l = new System.Windows.Forms.TextBox();
            this.tb42l = new System.Windows.Forms.TextBox();
            this.tb43l = new System.Windows.Forms.TextBox();
            this.tb44l = new System.Windows.Forms.TextBox();
            this.tb30l = new System.Windows.Forms.TextBox();
            this.tb31l = new System.Windows.Forms.TextBox();
            this.tb32l = new System.Windows.Forms.TextBox();
            this.tb33l = new System.Windows.Forms.TextBox();
            this.tb34l = new System.Windows.Forms.TextBox();
            this.tb35l = new System.Windows.Forms.TextBox();
            this.tb36l = new System.Windows.Forms.TextBox();
            this.tb37l = new System.Windows.Forms.TextBox();
            this.tb38l = new System.Windows.Forms.TextBox();
            this.tb45c1 = new System.Windows.Forms.TextBox();
            this.tb58c2 = new System.Windows.Forms.TextBox();
            this.tb40c2 = new System.Windows.Forms.TextBox();
            this.tb41c1 = new System.Windows.Forms.TextBox();
            this.tb42c1 = new System.Windows.Forms.TextBox();
            this.tb43c1 = new System.Windows.Forms.TextBox();
            this.tb44c1 = new System.Windows.Forms.TextBox();
            this.tb30c1 = new System.Windows.Forms.TextBox();
            this.tb31c1 = new System.Windows.Forms.TextBox();
            this.tb32c1 = new System.Windows.Forms.TextBox();
            this.tb33c1 = new System.Windows.Forms.TextBox();
            this.tb34c1 = new System.Windows.Forms.TextBox();
            this.tb35c1 = new System.Windows.Forms.TextBox();
            this.tb36c1 = new System.Windows.Forms.TextBox();
            this.tb37c1 = new System.Windows.Forms.TextBox();
            this.tb38c1 = new System.Windows.Forms.TextBox();
            this.tb45c2 = new System.Windows.Forms.TextBox();
            this.tb58c3 = new System.Windows.Forms.TextBox();
            this.tb40c3 = new System.Windows.Forms.TextBox();
            this.tb41c2 = new System.Windows.Forms.TextBox();
            this.tb42c2 = new System.Windows.Forms.TextBox();
            this.tb43c2 = new System.Windows.Forms.TextBox();
            this.tb44c2 = new System.Windows.Forms.TextBox();
            this.tb30c2 = new System.Windows.Forms.TextBox();
            this.tb31c2 = new System.Windows.Forms.TextBox();
            this.tb32c2 = new System.Windows.Forms.TextBox();
            this.tb33c2 = new System.Windows.Forms.TextBox();
            this.tb34c2 = new System.Windows.Forms.TextBox();
            this.tb35c2 = new System.Windows.Forms.TextBox();
            this.tb36c2 = new System.Windows.Forms.TextBox();
            this.tb37c2 = new System.Windows.Forms.TextBox();
            this.tb38c2 = new System.Windows.Forms.TextBox();
            this.tb45c3 = new System.Windows.Forms.TextBox();
            this.tb58c4 = new System.Windows.Forms.TextBox();
            this.tb40c4 = new System.Windows.Forms.TextBox();
            this.tb41c3 = new System.Windows.Forms.TextBox();
            this.tb42c3 = new System.Windows.Forms.TextBox();
            this.tb43c3 = new System.Windows.Forms.TextBox();
            this.tb44c3 = new System.Windows.Forms.TextBox();
            this.tb30c3 = new System.Windows.Forms.TextBox();
            this.tb31c3 = new System.Windows.Forms.TextBox();
            this.tb32c3 = new System.Windows.Forms.TextBox();
            this.tb33c3 = new System.Windows.Forms.TextBox();
            this.tb34c3 = new System.Windows.Forms.TextBox();
            this.tb35c3 = new System.Windows.Forms.TextBox();
            this.tb36c3 = new System.Windows.Forms.TextBox();
            this.tb37c3 = new System.Windows.Forms.TextBox();
            this.tb38c3 = new System.Windows.Forms.TextBox();
            this.tb32c4 = new System.Windows.Forms.TextBox();
            this.tb33c4 = new System.Windows.Forms.TextBox();
            this.tb34c4 = new System.Windows.Forms.TextBox();
            this.tb35c4 = new System.Windows.Forms.TextBox();
            this.tb36c4 = new System.Windows.Forms.TextBox();
            this.tb37c4 = new System.Windows.Forms.TextBox();
            this.tb38c4 = new System.Windows.Forms.TextBox();
            this.tb40c5 = new System.Windows.Forms.TextBox();
            this.tb41c4 = new System.Windows.Forms.TextBox();
            this.tb42c4 = new System.Windows.Forms.TextBox();
            this.tb43c4 = new System.Windows.Forms.TextBox();
            this.tb44c4 = new System.Windows.Forms.TextBox();
            this.tb45c5 = new System.Windows.Forms.TextBox();
            this.tb58c6 = new System.Windows.Forms.TextBox();
            this.tb45c4 = new System.Windows.Forms.TextBox();
            this.tb58c5 = new System.Windows.Forms.TextBox();
            this.tb45c9 = new System.Windows.Forms.TextBox();
            this.tb45c8 = new System.Windows.Forms.TextBox();
            this.tb45c7 = new System.Windows.Forms.TextBox();
            this.tb45c6 = new System.Windows.Forms.TextBox();
            this.tb40c8 = new System.Windows.Forms.TextBox();
            this.tb40c7 = new System.Windows.Forms.TextBox();
            this.tb40c6 = new System.Windows.Forms.TextBox();
            this.tb63c3 = new System.Windows.Forms.TextBox();
            this.tb64c3 = new System.Windows.Forms.TextBox();
            this.tb51c3 = new System.Windows.Forms.TextBox();
            this.tb52c3 = new System.Windows.Forms.TextBox();
            this.tb53c3 = new System.Windows.Forms.TextBox();
            this.tb54c3 = new System.Windows.Forms.TextBox();
            this.tb55c3 = new System.Windows.Forms.TextBox();
            this.tb56c3 = new System.Windows.Forms.TextBox();
            this.tb57c3 = new System.Windows.Forms.TextBox();
            this.tb63c2 = new System.Windows.Forms.TextBox();
            this.tb64c2 = new System.Windows.Forms.TextBox();
            this.tb51c2 = new System.Windows.Forms.TextBox();
            this.tb52c2 = new System.Windows.Forms.TextBox();
            this.tb53c2 = new System.Windows.Forms.TextBox();
            this.tb54c2 = new System.Windows.Forms.TextBox();
            this.tb55c2 = new System.Windows.Forms.TextBox();
            this.tb56c2 = new System.Windows.Forms.TextBox();
            this.tb57c2 = new System.Windows.Forms.TextBox();
            this.tb63c1 = new System.Windows.Forms.TextBox();
            this.tb64c1 = new System.Windows.Forms.TextBox();
            this.tb51c1 = new System.Windows.Forms.TextBox();
            this.tb52c1 = new System.Windows.Forms.TextBox();
            this.tb53c1 = new System.Windows.Forms.TextBox();
            this.tb54c1 = new System.Windows.Forms.TextBox();
            this.tb55c1 = new System.Windows.Forms.TextBox();
            this.tb56c1 = new System.Windows.Forms.TextBox();
            this.tb57c1 = new System.Windows.Forms.TextBox();
            this.tb63l = new System.Windows.Forms.TextBox();
            this.tb64l = new System.Windows.Forms.TextBox();
            this.tb51l = new System.Windows.Forms.TextBox();
            this.tb52l = new System.Windows.Forms.TextBox();
            this.tb53l = new System.Windows.Forms.TextBox();
            this.tb54l = new System.Windows.Forms.TextBox();
            this.tb55l = new System.Windows.Forms.TextBox();
            this.tb56l = new System.Windows.Forms.TextBox();
            this.tb57l = new System.Windows.Forms.TextBox();
            this.tb63 = new System.Windows.Forms.TextBox();
            this.tb64 = new System.Windows.Forms.TextBox();
            this.tb51 = new System.Windows.Forms.TextBox();
            this.tb52 = new System.Windows.Forms.TextBox();
            this.tb53 = new System.Windows.Forms.TextBox();
            this.tb54 = new System.Windows.Forms.TextBox();
            this.tb55 = new System.Windows.Forms.TextBox();
            this.tb56 = new System.Windows.Forms.TextBox();
            this.tb57 = new System.Windows.Forms.TextBox();
            this.tb61c3 = new System.Windows.Forms.TextBox();
            this.tb62c3 = new System.Windows.Forms.TextBox();
            this.tb61c2 = new System.Windows.Forms.TextBox();
            this.tb62c2 = new System.Windows.Forms.TextBox();
            this.tb61c1 = new System.Windows.Forms.TextBox();
            this.tb62c1 = new System.Windows.Forms.TextBox();
            this.tb61l = new System.Windows.Forms.TextBox();
            this.tb62l = new System.Windows.Forms.TextBox();
            this.tb61 = new System.Windows.Forms.TextBox();
            this.tb62 = new System.Windows.Forms.TextBox();
            this.tb77c4 = new System.Windows.Forms.TextBox();
            this.tb76c4 = new System.Windows.Forms.TextBox();
            this.tb77c3 = new System.Windows.Forms.TextBox();
            this.tb76c3 = new System.Windows.Forms.TextBox();
            this.tb77c2 = new System.Windows.Forms.TextBox();
            this.tb76c2 = new System.Windows.Forms.TextBox();
            this.tb77c1 = new System.Windows.Forms.TextBox();
            this.tb76c1 = new System.Windows.Forms.TextBox();
            this.tb77 = new System.Windows.Forms.TextBox();
            this.tb76 = new System.Windows.Forms.TextBox();
            this.tb75c4 = new System.Windows.Forms.TextBox();
            this.tb74c4 = new System.Windows.Forms.TextBox();
            this.tb75c3 = new System.Windows.Forms.TextBox();
            this.tb74c3 = new System.Windows.Forms.TextBox();
            this.tb75c2 = new System.Windows.Forms.TextBox();
            this.tb74c2 = new System.Windows.Forms.TextBox();
            this.tb75c1 = new System.Windows.Forms.TextBox();
            this.tb74c1 = new System.Windows.Forms.TextBox();
            this.tb75 = new System.Windows.Forms.TextBox();
            this.tb74 = new System.Windows.Forms.TextBox();
            this.tb16c1 = new System.Windows.Forms.TextBox();
            this.tb16 = new System.Windows.Forms.TextBox();
            this.tb15c1 = new System.Windows.Forms.TextBox();
            this.tb15 = new System.Windows.Forms.TextBox();
            this.tb14c1 = new System.Windows.Forms.TextBox();
            this.tb14 = new System.Windows.Forms.TextBox();
            this.tb13c1 = new System.Windows.Forms.TextBox();
            this.tb13 = new System.Windows.Forms.TextBox();
            this.tb12c1 = new System.Windows.Forms.TextBox();
            this.tb12 = new System.Windows.Forms.TextBox();
            this.tb20c1 = new System.Windows.Forms.TextBox();
            this.tb20 = new System.Windows.Forms.TextBox();
            this.tb19c1 = new System.Windows.Forms.TextBox();
            this.tb19 = new System.Windows.Forms.TextBox();
            this.tb18c1 = new System.Windows.Forms.TextBox();
            this.tb18 = new System.Windows.Forms.TextBox();
            this.tb17c1 = new System.Windows.Forms.TextBox();
            this.tb17 = new System.Windows.Forms.TextBox();
            this.tb21c1 = new System.Windows.Forms.TextBox();
            this.tb21 = new System.Windows.Forms.TextBox();
            this.tb51c6 = new System.Windows.Forms.TextBox();
            this.tb52c6 = new System.Windows.Forms.TextBox();
            this.tb53c6 = new System.Windows.Forms.TextBox();
            this.tb54c6 = new System.Windows.Forms.TextBox();
            this.tb55c6 = new System.Windows.Forms.TextBox();
            this.tb56c6 = new System.Windows.Forms.TextBox();
            this.tb57c6 = new System.Windows.Forms.TextBox();
            this.tb51c5 = new System.Windows.Forms.TextBox();
            this.tb52c5 = new System.Windows.Forms.TextBox();
            this.tb53c5 = new System.Windows.Forms.TextBox();
            this.tb54c5 = new System.Windows.Forms.TextBox();
            this.tb55c5 = new System.Windows.Forms.TextBox();
            this.tb56c5 = new System.Windows.Forms.TextBox();
            this.tb57c5 = new System.Windows.Forms.TextBox();
            this.tb51c4 = new System.Windows.Forms.TextBox();
            this.tb52c4 = new System.Windows.Forms.TextBox();
            this.tb53c4 = new System.Windows.Forms.TextBox();
            this.tb54c4 = new System.Windows.Forms.TextBox();
            this.tb55c4 = new System.Windows.Forms.TextBox();
            this.tb56c4 = new System.Windows.Forms.TextBox();
            this.tb57c4 = new System.Windows.Forms.TextBox();
            this.tb64c4 = new System.Windows.Forms.TextBox();
            this.tb63c4 = new System.Windows.Forms.TextBox();
            this.tb64c5 = new System.Windows.Forms.TextBox();
            this.tb52c7 = new System.Windows.Forms.TextBox();
            this.tb53c7 = new System.Windows.Forms.TextBox();
            this.tb54c7 = new System.Windows.Forms.TextBox();
            this.tb55c7 = new System.Windows.Forms.TextBox();
            this.tb56c7 = new System.Windows.Forms.TextBox();
            this.tb57c7 = new System.Windows.Forms.TextBox();
            this.tb55c8 = new System.Windows.Forms.TextBox();
            this.tb56c8 = new System.Windows.Forms.TextBox();
            this.tb57c8 = new System.Windows.Forms.TextBox();
            this.tb77c5 = new System.Windows.Forms.TextBox();
            this.tb76c5 = new System.Windows.Forms.TextBox();
            this.tb74c5 = new System.Windows.Forms.TextBox();
            this.btnInvoerTramnummer = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSpoor = new System.Windows.Forms.TextBox();
            this.tbTram = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbReserveringen = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb38
            // 
            this.tb38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb38.Location = new System.Drawing.Point(201, 12);
            this.tb38.Multiline = true;
            this.tb38.Name = "tb38";
            this.tb38.Size = new System.Drawing.Size(60, 32);
            this.tb38.TabIndex = 0;
            this.tb38.Text = "38";
            this.tb38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb37
            // 
            this.tb37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb37.Location = new System.Drawing.Point(267, 12);
            this.tb37.Multiline = true;
            this.tb37.Name = "tb37";
            this.tb37.Size = new System.Drawing.Size(60, 32);
            this.tb37.TabIndex = 1;
            this.tb37.Text = "37";
            this.tb37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb36
            // 
            this.tb36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb36.Location = new System.Drawing.Point(333, 12);
            this.tb36.Multiline = true;
            this.tb36.Name = "tb36";
            this.tb36.Size = new System.Drawing.Size(60, 32);
            this.tb36.TabIndex = 2;
            this.tb36.Text = "36";
            this.tb36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb35
            // 
            this.tb35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb35.Location = new System.Drawing.Point(399, 12);
            this.tb35.Multiline = true;
            this.tb35.Name = "tb35";
            this.tb35.Size = new System.Drawing.Size(60, 32);
            this.tb35.TabIndex = 3;
            this.tb35.Text = "35";
            this.tb35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34
            // 
            this.tb34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb34.Location = new System.Drawing.Point(465, 12);
            this.tb34.Multiline = true;
            this.tb34.Name = "tb34";
            this.tb34.Size = new System.Drawing.Size(60, 32);
            this.tb34.TabIndex = 4;
            this.tb34.Text = "34";
            this.tb34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33
            // 
            this.tb33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb33.Location = new System.Drawing.Point(531, 12);
            this.tb33.Multiline = true;
            this.tb33.Name = "tb33";
            this.tb33.Size = new System.Drawing.Size(60, 32);
            this.tb33.TabIndex = 5;
            this.tb33.Text = "33";
            this.tb33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32
            // 
            this.tb32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb32.Location = new System.Drawing.Point(597, 12);
            this.tb32.Multiline = true;
            this.tb32.Name = "tb32";
            this.tb32.Size = new System.Drawing.Size(60, 32);
            this.tb32.TabIndex = 6;
            this.tb32.Text = "32";
            this.tb32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb31
            // 
            this.tb31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb31.Location = new System.Drawing.Point(663, 12);
            this.tb31.Multiline = true;
            this.tb31.Name = "tb31";
            this.tb31.Size = new System.Drawing.Size(60, 32);
            this.tb31.TabIndex = 7;
            this.tb31.Text = "31";
            this.tb31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb30
            // 
            this.tb30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb30.Location = new System.Drawing.Point(729, 12);
            this.tb30.Multiline = true;
            this.tb30.Name = "tb30";
            this.tb30.Size = new System.Drawing.Size(60, 32);
            this.tb30.TabIndex = 8;
            this.tb30.Text = "30";
            this.tb30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44
            // 
            this.tb44.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb44.Location = new System.Drawing.Point(1072, 12);
            this.tb44.Multiline = true;
            this.tb44.Name = "tb44";
            this.tb44.Size = new System.Drawing.Size(60, 32);
            this.tb44.TabIndex = 9;
            this.tb44.Text = "44";
            this.tb44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43
            // 
            this.tb43.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb43.Location = new System.Drawing.Point(1006, 12);
            this.tb43.Multiline = true;
            this.tb43.Name = "tb43";
            this.tb43.Size = new System.Drawing.Size(60, 32);
            this.tb43.TabIndex = 10;
            this.tb43.Text = "43";
            this.tb43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42
            // 
            this.tb42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb42.Location = new System.Drawing.Point(940, 12);
            this.tb42.Multiline = true;
            this.tb42.Name = "tb42";
            this.tb42.Size = new System.Drawing.Size(60, 32);
            this.tb42.TabIndex = 11;
            this.tb42.Text = "42";
            this.tb42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41
            // 
            this.tb41.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb41.Location = new System.Drawing.Point(874, 12);
            this.tb41.Multiline = true;
            this.tb41.Name = "tb41";
            this.tb41.Size = new System.Drawing.Size(60, 32);
            this.tb41.TabIndex = 12;
            this.tb41.Text = "41";
            this.tb41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40
            // 
            this.tb40.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40.Location = new System.Drawing.Point(808, 12);
            this.tb40.Multiline = true;
            this.tb40.Name = "tb40";
            this.tb40.Size = new System.Drawing.Size(60, 32);
            this.tb40.TabIndex = 13;
            this.tb40.Text = "40";
            this.tb40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58
            // 
            this.tb58.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58.Location = new System.Drawing.Point(1236, 12);
            this.tb58.Multiline = true;
            this.tb58.Name = "tb58";
            this.tb58.Size = new System.Drawing.Size(60, 32);
            this.tb58.TabIndex = 14;
            this.tb58.Text = "58";
            this.tb58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45
            // 
            this.tb45.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45.Location = new System.Drawing.Point(1153, 12);
            this.tb45.Multiline = true;
            this.tb45.Name = "tb45";
            this.tb45.Size = new System.Drawing.Size(60, 32);
            this.tb45.TabIndex = 15;
            this.tb45.Text = "45";
            this.tb45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45l
            // 
            this.tb45l.BackColor = System.Drawing.Color.Red;
            this.tb45l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45l.Location = new System.Drawing.Point(1153, 50);
            this.tb45l.Multiline = true;
            this.tb45l.Name = "tb45l";
            this.tb45l.Size = new System.Drawing.Size(60, 32);
            this.tb45l.TabIndex = 31;
            this.tb45l.Text = "17";
            this.tb45l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58c1
            // 
            this.tb58c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58c1.Location = new System.Drawing.Point(1236, 50);
            this.tb58c1.Multiline = true;
            this.tb58c1.Name = "tb58c1";
            this.tb58c1.Size = new System.Drawing.Size(60, 32);
            this.tb58c1.TabIndex = 30;
            this.tb58c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c1
            // 
            this.tb40c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c1.Location = new System.Drawing.Point(808, 50);
            this.tb40c1.Multiline = true;
            this.tb40c1.Name = "tb40c1";
            this.tb40c1.Size = new System.Drawing.Size(60, 32);
            this.tb40c1.TabIndex = 29;
            this.tb40c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41l
            // 
            this.tb41l.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tb41l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb41l.Location = new System.Drawing.Point(874, 50);
            this.tb41l.Multiline = true;
            this.tb41l.Name = "tb41l";
            this.tb41l.Size = new System.Drawing.Size(60, 32);
            this.tb41l.TabIndex = 28;
            this.tb41l.Text = "10";
            this.tb41l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42l
            // 
            this.tb42l.BackColor = System.Drawing.Color.MediumPurple;
            this.tb42l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb42l.Location = new System.Drawing.Point(940, 50);
            this.tb42l.Multiline = true;
            this.tb42l.Name = "tb42l";
            this.tb42l.Size = new System.Drawing.Size(60, 32);
            this.tb42l.TabIndex = 27;
            this.tb42l.Text = "55";
            this.tb42l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43l
            // 
            this.tb43l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb43l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb43l.Location = new System.Drawing.Point(1006, 50);
            this.tb43l.Multiline = true;
            this.tb43l.Name = "tb43l";
            this.tb43l.Size = new System.Drawing.Size(60, 32);
            this.tb43l.TabIndex = 26;
            this.tb43l.Text = "1";
            this.tb43l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44l
            // 
            this.tb44l.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tb44l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb44l.Location = new System.Drawing.Point(1072, 50);
            this.tb44l.Multiline = true;
            this.tb44l.Name = "tb44l";
            this.tb44l.Size = new System.Drawing.Size(60, 32);
            this.tb44l.TabIndex = 25;
            this.tb44l.Text = "13";
            this.tb44l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb30l
            // 
            this.tb30l.BackColor = System.Drawing.Color.IndianRed;
            this.tb30l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb30l.Location = new System.Drawing.Point(729, 50);
            this.tb30l.Multiline = true;
            this.tb30l.Name = "tb30l";
            this.tb30l.Size = new System.Drawing.Size(60, 32);
            this.tb30l.TabIndex = 24;
            this.tb30l.Text = "16/24";
            this.tb30l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb31l
            // 
            this.tb31l.BackColor = System.Drawing.Color.Fuchsia;
            this.tb31l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb31l.Location = new System.Drawing.Point(663, 50);
            this.tb31l.Multiline = true;
            this.tb31l.Name = "tb31l";
            this.tb31l.Size = new System.Drawing.Size(60, 32);
            this.tb31l.TabIndex = 23;
            this.tb31l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32l
            // 
            this.tb32l.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tb32l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb32l.Location = new System.Drawing.Point(597, 50);
            this.tb32l.Multiline = true;
            this.tb32l.Name = "tb32l";
            this.tb32l.Size = new System.Drawing.Size(60, 32);
            this.tb32l.TabIndex = 22;
            this.tb32l.Text = "10";
            this.tb32l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33l
            // 
            this.tb33l.BackColor = System.Drawing.Color.IndianRed;
            this.tb33l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb33l.Location = new System.Drawing.Point(531, 50);
            this.tb33l.Multiline = true;
            this.tb33l.Name = "tb33l";
            this.tb33l.Size = new System.Drawing.Size(60, 32);
            this.tb33l.TabIndex = 21;
            this.tb33l.Text = "16/24";
            this.tb33l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34l
            // 
            this.tb34l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb34l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb34l.Location = new System.Drawing.Point(465, 50);
            this.tb34l.Multiline = true;
            this.tb34l.Name = "tb34l";
            this.tb34l.Size = new System.Drawing.Size(60, 32);
            this.tb34l.TabIndex = 20;
            this.tb34l.Text = "2";
            this.tb34l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb35l
            // 
            this.tb35l.BackColor = System.Drawing.Color.IndianRed;
            this.tb35l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb35l.Location = new System.Drawing.Point(399, 50);
            this.tb35l.Multiline = true;
            this.tb35l.Name = "tb35l";
            this.tb35l.Size = new System.Drawing.Size(60, 32);
            this.tb35l.TabIndex = 19;
            this.tb35l.Text = "16/24";
            this.tb35l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb36l
            // 
            this.tb36l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb36l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb36l.Location = new System.Drawing.Point(333, 50);
            this.tb36l.Multiline = true;
            this.tb36l.Name = "tb36l";
            this.tb36l.Size = new System.Drawing.Size(60, 32);
            this.tb36l.TabIndex = 18;
            this.tb36l.Text = "1";
            this.tb36l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb37l
            // 
            this.tb37l.BackColor = System.Drawing.Color.MediumPurple;
            this.tb37l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb37l.Location = new System.Drawing.Point(267, 50);
            this.tb37l.Multiline = true;
            this.tb37l.Name = "tb37l";
            this.tb37l.Size = new System.Drawing.Size(60, 32);
            this.tb37l.TabIndex = 17;
            this.tb37l.Text = "5";
            this.tb37l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb38l
            // 
            this.tb38l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb38l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb38l.Location = new System.Drawing.Point(201, 50);
            this.tb38l.Multiline = true;
            this.tb38l.Name = "tb38l";
            this.tb38l.Size = new System.Drawing.Size(60, 32);
            this.tb38l.TabIndex = 16;
            this.tb38l.Text = "2";
            this.tb38l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c1
            // 
            this.tb45c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c1.Location = new System.Drawing.Point(1153, 89);
            this.tb45c1.Multiline = true;
            this.tb45c1.Name = "tb45c1";
            this.tb45c1.Size = new System.Drawing.Size(60, 32);
            this.tb45c1.TabIndex = 47;
            this.tb45c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58c2
            // 
            this.tb58c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58c2.Location = new System.Drawing.Point(1236, 81);
            this.tb58c2.Multiline = true;
            this.tb58c2.Name = "tb58c2";
            this.tb58c2.Size = new System.Drawing.Size(60, 32);
            this.tb58c2.TabIndex = 46;
            this.tb58c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c2
            // 
            this.tb40c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c2.Location = new System.Drawing.Point(808, 81);
            this.tb40c2.Multiline = true;
            this.tb40c2.Name = "tb40c2";
            this.tb40c2.Size = new System.Drawing.Size(60, 32);
            this.tb40c2.TabIndex = 45;
            this.tb40c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41c1
            // 
            this.tb41c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb41c1.Location = new System.Drawing.Point(874, 89);
            this.tb41c1.Multiline = true;
            this.tb41c1.Name = "tb41c1";
            this.tb41c1.Size = new System.Drawing.Size(60, 32);
            this.tb41c1.TabIndex = 44;
            this.tb41c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42c1
            // 
            this.tb42c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb42c1.Location = new System.Drawing.Point(940, 89);
            this.tb42c1.Multiline = true;
            this.tb42c1.Name = "tb42c1";
            this.tb42c1.Size = new System.Drawing.Size(60, 32);
            this.tb42c1.TabIndex = 43;
            this.tb42c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43c1
            // 
            this.tb43c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb43c1.Location = new System.Drawing.Point(1006, 89);
            this.tb43c1.Multiline = true;
            this.tb43c1.Name = "tb43c1";
            this.tb43c1.Size = new System.Drawing.Size(60, 32);
            this.tb43c1.TabIndex = 42;
            this.tb43c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44c1
            // 
            this.tb44c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb44c1.Location = new System.Drawing.Point(1072, 89);
            this.tb44c1.Multiline = true;
            this.tb44c1.Name = "tb44c1";
            this.tb44c1.Size = new System.Drawing.Size(60, 32);
            this.tb44c1.TabIndex = 41;
            this.tb44c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb30c1
            // 
            this.tb30c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb30c1.Location = new System.Drawing.Point(729, 89);
            this.tb30c1.Multiline = true;
            this.tb30c1.Name = "tb30c1";
            this.tb30c1.Size = new System.Drawing.Size(60, 32);
            this.tb30c1.TabIndex = 40;
            this.tb30c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb31c1
            // 
            this.tb31c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb31c1.Location = new System.Drawing.Point(663, 89);
            this.tb31c1.Multiline = true;
            this.tb31c1.Name = "tb31c1";
            this.tb31c1.Size = new System.Drawing.Size(60, 32);
            this.tb31c1.TabIndex = 39;
            this.tb31c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32c1
            // 
            this.tb32c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb32c1.Location = new System.Drawing.Point(597, 89);
            this.tb32c1.Multiline = true;
            this.tb32c1.Name = "tb32c1";
            this.tb32c1.Size = new System.Drawing.Size(60, 32);
            this.tb32c1.TabIndex = 38;
            this.tb32c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33c1
            // 
            this.tb33c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb33c1.Location = new System.Drawing.Point(531, 89);
            this.tb33c1.Multiline = true;
            this.tb33c1.Name = "tb33c1";
            this.tb33c1.Size = new System.Drawing.Size(60, 32);
            this.tb33c1.TabIndex = 37;
            this.tb33c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34c1
            // 
            this.tb34c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb34c1.Location = new System.Drawing.Point(465, 89);
            this.tb34c1.Multiline = true;
            this.tb34c1.Name = "tb34c1";
            this.tb34c1.Size = new System.Drawing.Size(60, 32);
            this.tb34c1.TabIndex = 36;
            this.tb34c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb35c1
            // 
            this.tb35c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb35c1.Location = new System.Drawing.Point(399, 89);
            this.tb35c1.Multiline = true;
            this.tb35c1.Name = "tb35c1";
            this.tb35c1.Size = new System.Drawing.Size(60, 32);
            this.tb35c1.TabIndex = 35;
            this.tb35c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb36c1
            // 
            this.tb36c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb36c1.Location = new System.Drawing.Point(333, 89);
            this.tb36c1.Multiline = true;
            this.tb36c1.Name = "tb36c1";
            this.tb36c1.Size = new System.Drawing.Size(60, 32);
            this.tb36c1.TabIndex = 34;
            this.tb36c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb37c1
            // 
            this.tb37c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb37c1.Location = new System.Drawing.Point(267, 89);
            this.tb37c1.Multiline = true;
            this.tb37c1.Name = "tb37c1";
            this.tb37c1.Size = new System.Drawing.Size(60, 32);
            this.tb37c1.TabIndex = 33;
            this.tb37c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb38c1
            // 
            this.tb38c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb38c1.Location = new System.Drawing.Point(201, 89);
            this.tb38c1.Multiline = true;
            this.tb38c1.Name = "tb38c1";
            this.tb38c1.Size = new System.Drawing.Size(60, 32);
            this.tb38c1.TabIndex = 32;
            this.tb38c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c2
            // 
            this.tb45c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c2.Location = new System.Drawing.Point(1153, 120);
            this.tb45c2.Multiline = true;
            this.tb45c2.Name = "tb45c2";
            this.tb45c2.Size = new System.Drawing.Size(60, 32);
            this.tb45c2.TabIndex = 63;
            this.tb45c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58c3
            // 
            this.tb58c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58c3.Location = new System.Drawing.Point(1236, 112);
            this.tb58c3.Multiline = true;
            this.tb58c3.Name = "tb58c3";
            this.tb58c3.Size = new System.Drawing.Size(60, 32);
            this.tb58c3.TabIndex = 62;
            this.tb58c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c3
            // 
            this.tb40c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c3.Location = new System.Drawing.Point(808, 112);
            this.tb40c3.Multiline = true;
            this.tb40c3.Name = "tb40c3";
            this.tb40c3.Size = new System.Drawing.Size(60, 32);
            this.tb40c3.TabIndex = 61;
            this.tb40c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41c2
            // 
            this.tb41c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb41c2.Location = new System.Drawing.Point(874, 120);
            this.tb41c2.Multiline = true;
            this.tb41c2.Name = "tb41c2";
            this.tb41c2.Size = new System.Drawing.Size(60, 32);
            this.tb41c2.TabIndex = 60;
            this.tb41c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42c2
            // 
            this.tb42c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb42c2.Location = new System.Drawing.Point(940, 120);
            this.tb42c2.Multiline = true;
            this.tb42c2.Name = "tb42c2";
            this.tb42c2.Size = new System.Drawing.Size(60, 32);
            this.tb42c2.TabIndex = 59;
            this.tb42c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43c2
            // 
            this.tb43c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb43c2.Location = new System.Drawing.Point(1006, 120);
            this.tb43c2.Multiline = true;
            this.tb43c2.Name = "tb43c2";
            this.tb43c2.Size = new System.Drawing.Size(60, 32);
            this.tb43c2.TabIndex = 58;
            this.tb43c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44c2
            // 
            this.tb44c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb44c2.Location = new System.Drawing.Point(1072, 120);
            this.tb44c2.Multiline = true;
            this.tb44c2.Name = "tb44c2";
            this.tb44c2.Size = new System.Drawing.Size(60, 32);
            this.tb44c2.TabIndex = 57;
            this.tb44c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb30c2
            // 
            this.tb30c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb30c2.Location = new System.Drawing.Point(729, 120);
            this.tb30c2.Multiline = true;
            this.tb30c2.Name = "tb30c2";
            this.tb30c2.Size = new System.Drawing.Size(60, 32);
            this.tb30c2.TabIndex = 56;
            this.tb30c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb31c2
            // 
            this.tb31c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb31c2.Location = new System.Drawing.Point(663, 120);
            this.tb31c2.Multiline = true;
            this.tb31c2.Name = "tb31c2";
            this.tb31c2.Size = new System.Drawing.Size(60, 32);
            this.tb31c2.TabIndex = 55;
            this.tb31c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32c2
            // 
            this.tb32c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb32c2.Location = new System.Drawing.Point(597, 120);
            this.tb32c2.Multiline = true;
            this.tb32c2.Name = "tb32c2";
            this.tb32c2.Size = new System.Drawing.Size(60, 32);
            this.tb32c2.TabIndex = 54;
            this.tb32c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33c2
            // 
            this.tb33c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb33c2.Location = new System.Drawing.Point(531, 120);
            this.tb33c2.Multiline = true;
            this.tb33c2.Name = "tb33c2";
            this.tb33c2.Size = new System.Drawing.Size(60, 32);
            this.tb33c2.TabIndex = 53;
            this.tb33c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34c2
            // 
            this.tb34c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb34c2.Location = new System.Drawing.Point(465, 120);
            this.tb34c2.Multiline = true;
            this.tb34c2.Name = "tb34c2";
            this.tb34c2.Size = new System.Drawing.Size(60, 32);
            this.tb34c2.TabIndex = 52;
            this.tb34c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb35c2
            // 
            this.tb35c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb35c2.Location = new System.Drawing.Point(399, 120);
            this.tb35c2.Multiline = true;
            this.tb35c2.Name = "tb35c2";
            this.tb35c2.Size = new System.Drawing.Size(60, 32);
            this.tb35c2.TabIndex = 51;
            this.tb35c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb36c2
            // 
            this.tb36c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb36c2.Location = new System.Drawing.Point(333, 120);
            this.tb36c2.Multiline = true;
            this.tb36c2.Name = "tb36c2";
            this.tb36c2.Size = new System.Drawing.Size(60, 32);
            this.tb36c2.TabIndex = 50;
            this.tb36c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb37c2
            // 
            this.tb37c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb37c2.Location = new System.Drawing.Point(267, 120);
            this.tb37c2.Multiline = true;
            this.tb37c2.Name = "tb37c2";
            this.tb37c2.Size = new System.Drawing.Size(60, 32);
            this.tb37c2.TabIndex = 49;
            this.tb37c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb38c2
            // 
            this.tb38c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb38c2.Location = new System.Drawing.Point(201, 120);
            this.tb38c2.Multiline = true;
            this.tb38c2.Name = "tb38c2";
            this.tb38c2.Size = new System.Drawing.Size(60, 32);
            this.tb38c2.TabIndex = 48;
            this.tb38c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c3
            // 
            this.tb45c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c3.Location = new System.Drawing.Point(1153, 151);
            this.tb45c3.Multiline = true;
            this.tb45c3.Name = "tb45c3";
            this.tb45c3.Size = new System.Drawing.Size(60, 32);
            this.tb45c3.TabIndex = 79;
            this.tb45c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58c4
            // 
            this.tb58c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58c4.Location = new System.Drawing.Point(1236, 143);
            this.tb58c4.Multiline = true;
            this.tb58c4.Name = "tb58c4";
            this.tb58c4.Size = new System.Drawing.Size(60, 32);
            this.tb58c4.TabIndex = 78;
            this.tb58c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c4
            // 
            this.tb40c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c4.Location = new System.Drawing.Point(808, 143);
            this.tb40c4.Multiline = true;
            this.tb40c4.Name = "tb40c4";
            this.tb40c4.Size = new System.Drawing.Size(60, 32);
            this.tb40c4.TabIndex = 77;
            this.tb40c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41c3
            // 
            this.tb41c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb41c3.Location = new System.Drawing.Point(874, 151);
            this.tb41c3.Multiline = true;
            this.tb41c3.Name = "tb41c3";
            this.tb41c3.Size = new System.Drawing.Size(60, 32);
            this.tb41c3.TabIndex = 76;
            this.tb41c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42c3
            // 
            this.tb42c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb42c3.Location = new System.Drawing.Point(940, 151);
            this.tb42c3.Multiline = true;
            this.tb42c3.Name = "tb42c3";
            this.tb42c3.Size = new System.Drawing.Size(60, 32);
            this.tb42c3.TabIndex = 75;
            this.tb42c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43c3
            // 
            this.tb43c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb43c3.Location = new System.Drawing.Point(1006, 151);
            this.tb43c3.Multiline = true;
            this.tb43c3.Name = "tb43c3";
            this.tb43c3.Size = new System.Drawing.Size(60, 32);
            this.tb43c3.TabIndex = 74;
            this.tb43c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44c3
            // 
            this.tb44c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb44c3.Location = new System.Drawing.Point(1072, 151);
            this.tb44c3.Multiline = true;
            this.tb44c3.Name = "tb44c3";
            this.tb44c3.Size = new System.Drawing.Size(60, 32);
            this.tb44c3.TabIndex = 73;
            this.tb44c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb30c3
            // 
            this.tb30c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb30c3.Location = new System.Drawing.Point(729, 151);
            this.tb30c3.Multiline = true;
            this.tb30c3.Name = "tb30c3";
            this.tb30c3.Size = new System.Drawing.Size(60, 32);
            this.tb30c3.TabIndex = 72;
            this.tb30c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb31c3
            // 
            this.tb31c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb31c3.Location = new System.Drawing.Point(663, 151);
            this.tb31c3.Multiline = true;
            this.tb31c3.Name = "tb31c3";
            this.tb31c3.Size = new System.Drawing.Size(60, 32);
            this.tb31c3.TabIndex = 71;
            this.tb31c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32c3
            // 
            this.tb32c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb32c3.Location = new System.Drawing.Point(597, 151);
            this.tb32c3.Multiline = true;
            this.tb32c3.Name = "tb32c3";
            this.tb32c3.Size = new System.Drawing.Size(60, 32);
            this.tb32c3.TabIndex = 70;
            this.tb32c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33c3
            // 
            this.tb33c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb33c3.Location = new System.Drawing.Point(531, 151);
            this.tb33c3.Multiline = true;
            this.tb33c3.Name = "tb33c3";
            this.tb33c3.Size = new System.Drawing.Size(60, 32);
            this.tb33c3.TabIndex = 69;
            this.tb33c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34c3
            // 
            this.tb34c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb34c3.Location = new System.Drawing.Point(465, 151);
            this.tb34c3.Multiline = true;
            this.tb34c3.Name = "tb34c3";
            this.tb34c3.Size = new System.Drawing.Size(60, 32);
            this.tb34c3.TabIndex = 68;
            this.tb34c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb35c3
            // 
            this.tb35c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb35c3.Location = new System.Drawing.Point(399, 151);
            this.tb35c3.Multiline = true;
            this.tb35c3.Name = "tb35c3";
            this.tb35c3.Size = new System.Drawing.Size(60, 32);
            this.tb35c3.TabIndex = 67;
            this.tb35c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb36c3
            // 
            this.tb36c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb36c3.Location = new System.Drawing.Point(333, 151);
            this.tb36c3.Multiline = true;
            this.tb36c3.Name = "tb36c3";
            this.tb36c3.Size = new System.Drawing.Size(60, 32);
            this.tb36c3.TabIndex = 66;
            this.tb36c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb37c3
            // 
            this.tb37c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb37c3.Location = new System.Drawing.Point(267, 151);
            this.tb37c3.Multiline = true;
            this.tb37c3.Name = "tb37c3";
            this.tb37c3.Size = new System.Drawing.Size(60, 32);
            this.tb37c3.TabIndex = 65;
            this.tb37c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb38c3
            // 
            this.tb38c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb38c3.Location = new System.Drawing.Point(201, 151);
            this.tb38c3.Multiline = true;
            this.tb38c3.Name = "tb38c3";
            this.tb38c3.Size = new System.Drawing.Size(60, 32);
            this.tb38c3.TabIndex = 64;
            this.tb38c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb32c4
            // 
            this.tb32c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb32c4.Location = new System.Drawing.Point(597, 182);
            this.tb32c4.Multiline = true;
            this.tb32c4.Name = "tb32c4";
            this.tb32c4.Size = new System.Drawing.Size(60, 32);
            this.tb32c4.TabIndex = 86;
            this.tb32c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb33c4
            // 
            this.tb33c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb33c4.Location = new System.Drawing.Point(531, 182);
            this.tb33c4.Multiline = true;
            this.tb33c4.Name = "tb33c4";
            this.tb33c4.Size = new System.Drawing.Size(60, 32);
            this.tb33c4.TabIndex = 85;
            this.tb33c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb34c4
            // 
            this.tb34c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb34c4.Location = new System.Drawing.Point(465, 182);
            this.tb34c4.Multiline = true;
            this.tb34c4.Name = "tb34c4";
            this.tb34c4.Size = new System.Drawing.Size(60, 32);
            this.tb34c4.TabIndex = 84;
            this.tb34c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb35c4
            // 
            this.tb35c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb35c4.Location = new System.Drawing.Point(399, 182);
            this.tb35c4.Multiline = true;
            this.tb35c4.Name = "tb35c4";
            this.tb35c4.Size = new System.Drawing.Size(60, 32);
            this.tb35c4.TabIndex = 83;
            this.tb35c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb36c4
            // 
            this.tb36c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb36c4.Location = new System.Drawing.Point(333, 182);
            this.tb36c4.Multiline = true;
            this.tb36c4.Name = "tb36c4";
            this.tb36c4.Size = new System.Drawing.Size(60, 32);
            this.tb36c4.TabIndex = 82;
            this.tb36c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb37c4
            // 
            this.tb37c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb37c4.Location = new System.Drawing.Point(267, 182);
            this.tb37c4.Multiline = true;
            this.tb37c4.Name = "tb37c4";
            this.tb37c4.Size = new System.Drawing.Size(60, 32);
            this.tb37c4.TabIndex = 81;
            this.tb37c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb38c4
            // 
            this.tb38c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb38c4.Location = new System.Drawing.Point(201, 182);
            this.tb38c4.Multiline = true;
            this.tb38c4.Name = "tb38c4";
            this.tb38c4.Size = new System.Drawing.Size(60, 32);
            this.tb38c4.TabIndex = 80;
            this.tb38c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c5
            // 
            this.tb40c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c5.Location = new System.Drawing.Point(808, 174);
            this.tb40c5.Multiline = true;
            this.tb40c5.Name = "tb40c5";
            this.tb40c5.Size = new System.Drawing.Size(60, 32);
            this.tb40c5.TabIndex = 91;
            this.tb40c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb41c4
            // 
            this.tb41c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb41c4.Location = new System.Drawing.Point(874, 182);
            this.tb41c4.Multiline = true;
            this.tb41c4.Name = "tb41c4";
            this.tb41c4.Size = new System.Drawing.Size(60, 32);
            this.tb41c4.TabIndex = 90;
            this.tb41c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb42c4
            // 
            this.tb42c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb42c4.Location = new System.Drawing.Point(940, 182);
            this.tb42c4.Multiline = true;
            this.tb42c4.Name = "tb42c4";
            this.tb42c4.Size = new System.Drawing.Size(60, 32);
            this.tb42c4.TabIndex = 89;
            this.tb42c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb43c4
            // 
            this.tb43c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb43c4.Location = new System.Drawing.Point(1006, 182);
            this.tb43c4.Multiline = true;
            this.tb43c4.Name = "tb43c4";
            this.tb43c4.Size = new System.Drawing.Size(60, 32);
            this.tb43c4.TabIndex = 88;
            this.tb43c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb44c4
            // 
            this.tb44c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb44c4.Location = new System.Drawing.Point(1072, 182);
            this.tb44c4.Multiline = true;
            this.tb44c4.Name = "tb44c4";
            this.tb44c4.Size = new System.Drawing.Size(60, 32);
            this.tb44c4.TabIndex = 87;
            this.tb44c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c5
            // 
            this.tb45c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c5.Location = new System.Drawing.Point(1153, 213);
            this.tb45c5.Multiline = true;
            this.tb45c5.Name = "tb45c5";
            this.tb45c5.Size = new System.Drawing.Size(60, 32);
            this.tb45c5.TabIndex = 95;
            this.tb45c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58c6
            // 
            this.tb58c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58c6.Location = new System.Drawing.Point(1236, 205);
            this.tb58c6.Multiline = true;
            this.tb58c6.Name = "tb58c6";
            this.tb58c6.Size = new System.Drawing.Size(60, 32);
            this.tb58c6.TabIndex = 94;
            this.tb58c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c4
            // 
            this.tb45c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c4.Location = new System.Drawing.Point(1153, 182);
            this.tb45c4.Multiline = true;
            this.tb45c4.Name = "tb45c4";
            this.tb45c4.Size = new System.Drawing.Size(60, 32);
            this.tb45c4.TabIndex = 93;
            this.tb45c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb58c5
            // 
            this.tb58c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb58c5.Location = new System.Drawing.Point(1236, 174);
            this.tb58c5.Multiline = true;
            this.tb58c5.Name = "tb58c5";
            this.tb58c5.Size = new System.Drawing.Size(60, 32);
            this.tb58c5.TabIndex = 92;
            this.tb58c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c9
            // 
            this.tb45c9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c9.Location = new System.Drawing.Point(1153, 337);
            this.tb45c9.Multiline = true;
            this.tb45c9.Name = "tb45c9";
            this.tb45c9.Size = new System.Drawing.Size(60, 32);
            this.tb45c9.TabIndex = 99;
            this.tb45c9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c8
            // 
            this.tb45c8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c8.Location = new System.Drawing.Point(1153, 306);
            this.tb45c8.Multiline = true;
            this.tb45c8.Name = "tb45c8";
            this.tb45c8.Size = new System.Drawing.Size(60, 32);
            this.tb45c8.TabIndex = 98;
            this.tb45c8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c7
            // 
            this.tb45c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c7.Location = new System.Drawing.Point(1153, 275);
            this.tb45c7.Multiline = true;
            this.tb45c7.Name = "tb45c7";
            this.tb45c7.Size = new System.Drawing.Size(60, 32);
            this.tb45c7.TabIndex = 97;
            this.tb45c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb45c6
            // 
            this.tb45c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb45c6.Location = new System.Drawing.Point(1153, 244);
            this.tb45c6.Multiline = true;
            this.tb45c6.Name = "tb45c6";
            this.tb45c6.Size = new System.Drawing.Size(60, 32);
            this.tb45c6.TabIndex = 96;
            this.tb45c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c8
            // 
            this.tb40c8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c8.Location = new System.Drawing.Point(808, 267);
            this.tb40c8.Multiline = true;
            this.tb40c8.Name = "tb40c8";
            this.tb40c8.Size = new System.Drawing.Size(60, 32);
            this.tb40c8.TabIndex = 102;
            this.tb40c8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c7
            // 
            this.tb40c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c7.Location = new System.Drawing.Point(808, 236);
            this.tb40c7.Multiline = true;
            this.tb40c7.Name = "tb40c7";
            this.tb40c7.Size = new System.Drawing.Size(60, 32);
            this.tb40c7.TabIndex = 101;
            this.tb40c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb40c6
            // 
            this.tb40c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb40c6.Location = new System.Drawing.Point(808, 205);
            this.tb40c6.Multiline = true;
            this.tb40c6.Name = "tb40c6";
            this.tb40c6.Size = new System.Drawing.Size(60, 32);
            this.tb40c6.TabIndex = 100;
            this.tb40c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb63c3
            // 
            this.tb63c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb63c3.Location = new System.Drawing.Point(729, 520);
            this.tb63c3.Multiline = true;
            this.tb63c3.Name = "tb63c3";
            this.tb63c3.Size = new System.Drawing.Size(60, 32);
            this.tb63c3.TabIndex = 147;
            this.tb63c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64c3
            // 
            this.tb64c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64c3.Location = new System.Drawing.Point(663, 520);
            this.tb64c3.Multiline = true;
            this.tb64c3.Name = "tb64c3";
            this.tb64c3.Size = new System.Drawing.Size(60, 32);
            this.tb64c3.TabIndex = 146;
            this.tb64c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51c3
            // 
            this.tb51c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51c3.Location = new System.Drawing.Point(597, 520);
            this.tb51c3.Multiline = true;
            this.tb51c3.Name = "tb51c3";
            this.tb51c3.Size = new System.Drawing.Size(60, 32);
            this.tb51c3.TabIndex = 145;
            this.tb51c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c3
            // 
            this.tb52c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c3.Location = new System.Drawing.Point(531, 520);
            this.tb52c3.Multiline = true;
            this.tb52c3.Name = "tb52c3";
            this.tb52c3.Size = new System.Drawing.Size(60, 32);
            this.tb52c3.TabIndex = 144;
            this.tb52c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c3
            // 
            this.tb53c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c3.Location = new System.Drawing.Point(465, 520);
            this.tb53c3.Multiline = true;
            this.tb53c3.Name = "tb53c3";
            this.tb53c3.Size = new System.Drawing.Size(60, 32);
            this.tb53c3.TabIndex = 143;
            this.tb53c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c3
            // 
            this.tb54c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c3.Location = new System.Drawing.Point(399, 520);
            this.tb54c3.Multiline = true;
            this.tb54c3.Name = "tb54c3";
            this.tb54c3.Size = new System.Drawing.Size(60, 32);
            this.tb54c3.TabIndex = 142;
            this.tb54c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c3
            // 
            this.tb55c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c3.Location = new System.Drawing.Point(333, 520);
            this.tb55c3.Multiline = true;
            this.tb55c3.Name = "tb55c3";
            this.tb55c3.Size = new System.Drawing.Size(60, 32);
            this.tb55c3.TabIndex = 141;
            this.tb55c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c3
            // 
            this.tb56c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c3.Location = new System.Drawing.Point(267, 520);
            this.tb56c3.Multiline = true;
            this.tb56c3.Name = "tb56c3";
            this.tb56c3.Size = new System.Drawing.Size(60, 32);
            this.tb56c3.TabIndex = 140;
            this.tb56c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c3
            // 
            this.tb57c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c3.Location = new System.Drawing.Point(201, 520);
            this.tb57c3.Multiline = true;
            this.tb57c3.Name = "tb57c3";
            this.tb57c3.Size = new System.Drawing.Size(60, 32);
            this.tb57c3.TabIndex = 139;
            this.tb57c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb63c2
            // 
            this.tb63c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb63c2.Location = new System.Drawing.Point(729, 489);
            this.tb63c2.Multiline = true;
            this.tb63c2.Name = "tb63c2";
            this.tb63c2.Size = new System.Drawing.Size(60, 32);
            this.tb63c2.TabIndex = 138;
            this.tb63c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64c2
            // 
            this.tb64c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64c2.Location = new System.Drawing.Point(663, 489);
            this.tb64c2.Multiline = true;
            this.tb64c2.Name = "tb64c2";
            this.tb64c2.Size = new System.Drawing.Size(60, 32);
            this.tb64c2.TabIndex = 137;
            this.tb64c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51c2
            // 
            this.tb51c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51c2.Location = new System.Drawing.Point(597, 489);
            this.tb51c2.Multiline = true;
            this.tb51c2.Name = "tb51c2";
            this.tb51c2.Size = new System.Drawing.Size(60, 32);
            this.tb51c2.TabIndex = 136;
            this.tb51c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c2
            // 
            this.tb52c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c2.Location = new System.Drawing.Point(531, 489);
            this.tb52c2.Multiline = true;
            this.tb52c2.Name = "tb52c2";
            this.tb52c2.Size = new System.Drawing.Size(60, 32);
            this.tb52c2.TabIndex = 135;
            this.tb52c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c2
            // 
            this.tb53c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c2.Location = new System.Drawing.Point(465, 489);
            this.tb53c2.Multiline = true;
            this.tb53c2.Name = "tb53c2";
            this.tb53c2.Size = new System.Drawing.Size(60, 32);
            this.tb53c2.TabIndex = 134;
            this.tb53c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c2
            // 
            this.tb54c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c2.Location = new System.Drawing.Point(399, 489);
            this.tb54c2.Multiline = true;
            this.tb54c2.Name = "tb54c2";
            this.tb54c2.Size = new System.Drawing.Size(60, 32);
            this.tb54c2.TabIndex = 133;
            this.tb54c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c2
            // 
            this.tb55c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c2.Location = new System.Drawing.Point(333, 489);
            this.tb55c2.Multiline = true;
            this.tb55c2.Name = "tb55c2";
            this.tb55c2.Size = new System.Drawing.Size(60, 32);
            this.tb55c2.TabIndex = 132;
            this.tb55c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c2
            // 
            this.tb56c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c2.Location = new System.Drawing.Point(267, 489);
            this.tb56c2.Multiline = true;
            this.tb56c2.Name = "tb56c2";
            this.tb56c2.Size = new System.Drawing.Size(60, 32);
            this.tb56c2.TabIndex = 131;
            this.tb56c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c2
            // 
            this.tb57c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c2.Location = new System.Drawing.Point(201, 489);
            this.tb57c2.Multiline = true;
            this.tb57c2.Name = "tb57c2";
            this.tb57c2.Size = new System.Drawing.Size(60, 32);
            this.tb57c2.TabIndex = 130;
            this.tb57c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb63c1
            // 
            this.tb63c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb63c1.Location = new System.Drawing.Point(729, 458);
            this.tb63c1.Multiline = true;
            this.tb63c1.Name = "tb63c1";
            this.tb63c1.Size = new System.Drawing.Size(60, 32);
            this.tb63c1.TabIndex = 129;
            this.tb63c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64c1
            // 
            this.tb64c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64c1.Location = new System.Drawing.Point(663, 458);
            this.tb64c1.Multiline = true;
            this.tb64c1.Name = "tb64c1";
            this.tb64c1.Size = new System.Drawing.Size(60, 32);
            this.tb64c1.TabIndex = 128;
            this.tb64c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51c1
            // 
            this.tb51c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51c1.Location = new System.Drawing.Point(597, 458);
            this.tb51c1.Multiline = true;
            this.tb51c1.Name = "tb51c1";
            this.tb51c1.Size = new System.Drawing.Size(60, 32);
            this.tb51c1.TabIndex = 127;
            this.tb51c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c1
            // 
            this.tb52c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c1.Location = new System.Drawing.Point(531, 458);
            this.tb52c1.Multiline = true;
            this.tb52c1.Name = "tb52c1";
            this.tb52c1.Size = new System.Drawing.Size(60, 32);
            this.tb52c1.TabIndex = 126;
            this.tb52c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c1
            // 
            this.tb53c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c1.Location = new System.Drawing.Point(465, 458);
            this.tb53c1.Multiline = true;
            this.tb53c1.Name = "tb53c1";
            this.tb53c1.Size = new System.Drawing.Size(60, 32);
            this.tb53c1.TabIndex = 125;
            this.tb53c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c1
            // 
            this.tb54c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c1.Location = new System.Drawing.Point(399, 458);
            this.tb54c1.Multiline = true;
            this.tb54c1.Name = "tb54c1";
            this.tb54c1.Size = new System.Drawing.Size(60, 32);
            this.tb54c1.TabIndex = 124;
            this.tb54c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c1
            // 
            this.tb55c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c1.Location = new System.Drawing.Point(333, 458);
            this.tb55c1.Multiline = true;
            this.tb55c1.Name = "tb55c1";
            this.tb55c1.Size = new System.Drawing.Size(60, 32);
            this.tb55c1.TabIndex = 123;
            this.tb55c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c1
            // 
            this.tb56c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c1.Location = new System.Drawing.Point(267, 458);
            this.tb56c1.Multiline = true;
            this.tb56c1.Name = "tb56c1";
            this.tb56c1.Size = new System.Drawing.Size(60, 32);
            this.tb56c1.TabIndex = 122;
            this.tb56c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c1
            // 
            this.tb57c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c1.Location = new System.Drawing.Point(201, 458);
            this.tb57c1.Multiline = true;
            this.tb57c1.Name = "tb57c1";
            this.tb57c1.Size = new System.Drawing.Size(60, 32);
            this.tb57c1.TabIndex = 121;
            this.tb57c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb63l
            // 
            this.tb63l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb63l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb63l.Location = new System.Drawing.Point(729, 420);
            this.tb63l.Multiline = true;
            this.tb63l.Name = "tb63l";
            this.tb63l.Size = new System.Drawing.Size(60, 32);
            this.tb63l.TabIndex = 120;
            this.tb63l.Text = "2";
            this.tb63l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64l
            // 
            this.tb64l.BackColor = System.Drawing.Color.Fuchsia;
            this.tb64l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64l.Location = new System.Drawing.Point(663, 420);
            this.tb64l.Multiline = true;
            this.tb64l.Name = "tb64l";
            this.tb64l.Size = new System.Drawing.Size(60, 32);
            this.tb64l.TabIndex = 119;
            this.tb64l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51l
            // 
            this.tb51l.BackColor = System.Drawing.Color.Black;
            this.tb51l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51l.Location = new System.Drawing.Point(597, 420);
            this.tb51l.Multiline = true;
            this.tb51l.Name = "tb51l";
            this.tb51l.Size = new System.Drawing.Size(60, 32);
            this.tb51l.TabIndex = 118;
            this.tb51l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52l
            // 
            this.tb52l.BackColor = System.Drawing.Color.Red;
            this.tb52l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52l.Location = new System.Drawing.Point(531, 420);
            this.tb52l.Multiline = true;
            this.tb52l.Name = "tb52l";
            this.tb52l.Size = new System.Drawing.Size(60, 32);
            this.tb52l.TabIndex = 117;
            this.tb52l.Text = "17";
            this.tb52l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53l
            // 
            this.tb53l.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.tb53l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53l.Location = new System.Drawing.Point(465, 420);
            this.tb53l.Multiline = true;
            this.tb53l.Name = "tb53l";
            this.tb53l.Size = new System.Drawing.Size(60, 32);
            this.tb53l.TabIndex = 116;
            this.tb53l.Text = "13";
            this.tb53l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54l
            // 
            this.tb54l.BackColor = System.Drawing.Color.MediumPurple;
            this.tb54l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54l.Location = new System.Drawing.Point(399, 420);
            this.tb54l.Multiline = true;
            this.tb54l.Name = "tb54l";
            this.tb54l.Size = new System.Drawing.Size(60, 32);
            this.tb54l.TabIndex = 115;
            this.tb54l.Text = "5";
            this.tb54l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55l
            // 
            this.tb55l.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tb55l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55l.Location = new System.Drawing.Point(333, 420);
            this.tb55l.Multiline = true;
            this.tb55l.Name = "tb55l";
            this.tb55l.Size = new System.Drawing.Size(60, 32);
            this.tb55l.TabIndex = 114;
            this.tb55l.Text = "2";
            this.tb55l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56l
            // 
            this.tb56l.BackColor = System.Drawing.Color.MediumPurple;
            this.tb56l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56l.Location = new System.Drawing.Point(267, 420);
            this.tb56l.Multiline = true;
            this.tb56l.Name = "tb56l";
            this.tb56l.Size = new System.Drawing.Size(60, 32);
            this.tb56l.TabIndex = 113;
            this.tb56l.Text = "5";
            this.tb56l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57l
            // 
            this.tb57l.BackColor = System.Drawing.Color.IndianRed;
            this.tb57l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57l.Location = new System.Drawing.Point(201, 420);
            this.tb57l.Multiline = true;
            this.tb57l.Name = "tb57l";
            this.tb57l.Size = new System.Drawing.Size(60, 32);
            this.tb57l.TabIndex = 112;
            this.tb57l.Text = "16/24";
            this.tb57l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb63
            // 
            this.tb63.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb63.Location = new System.Drawing.Point(729, 382);
            this.tb63.Multiline = true;
            this.tb63.Name = "tb63";
            this.tb63.Size = new System.Drawing.Size(60, 32);
            this.tb63.TabIndex = 111;
            this.tb63.Text = "63";
            this.tb63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64
            // 
            this.tb64.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64.Location = new System.Drawing.Point(663, 382);
            this.tb64.Multiline = true;
            this.tb64.Name = "tb64";
            this.tb64.Size = new System.Drawing.Size(60, 32);
            this.tb64.TabIndex = 110;
            this.tb64.Text = "64";
            this.tb64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51
            // 
            this.tb51.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51.Location = new System.Drawing.Point(597, 382);
            this.tb51.Multiline = true;
            this.tb51.Name = "tb51";
            this.tb51.Size = new System.Drawing.Size(60, 32);
            this.tb51.TabIndex = 109;
            this.tb51.Text = "51";
            this.tb51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52
            // 
            this.tb52.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52.Location = new System.Drawing.Point(531, 382);
            this.tb52.Multiline = true;
            this.tb52.Name = "tb52";
            this.tb52.Size = new System.Drawing.Size(60, 32);
            this.tb52.TabIndex = 108;
            this.tb52.Text = "52";
            this.tb52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53
            // 
            this.tb53.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53.Location = new System.Drawing.Point(465, 382);
            this.tb53.Multiline = true;
            this.tb53.Name = "tb53";
            this.tb53.Size = new System.Drawing.Size(60, 32);
            this.tb53.TabIndex = 107;
            this.tb53.Text = "53";
            this.tb53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54
            // 
            this.tb54.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54.Location = new System.Drawing.Point(399, 382);
            this.tb54.Multiline = true;
            this.tb54.Name = "tb54";
            this.tb54.Size = new System.Drawing.Size(60, 32);
            this.tb54.TabIndex = 106;
            this.tb54.Text = "54";
            this.tb54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55
            // 
            this.tb55.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55.Location = new System.Drawing.Point(333, 382);
            this.tb55.Multiline = true;
            this.tb55.Name = "tb55";
            this.tb55.Size = new System.Drawing.Size(60, 32);
            this.tb55.TabIndex = 105;
            this.tb55.Text = "55";
            this.tb55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56
            // 
            this.tb56.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56.Location = new System.Drawing.Point(267, 382);
            this.tb56.Multiline = true;
            this.tb56.Name = "tb56";
            this.tb56.Size = new System.Drawing.Size(60, 32);
            this.tb56.TabIndex = 104;
            this.tb56.Text = "56";
            this.tb56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57
            // 
            this.tb57.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57.Location = new System.Drawing.Point(201, 382);
            this.tb57.Multiline = true;
            this.tb57.Name = "tb57";
            this.tb57.Size = new System.Drawing.Size(60, 32);
            this.tb57.TabIndex = 103;
            this.tb57.Text = "57";
            this.tb57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb61c3
            // 
            this.tb61c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb61c3.Location = new System.Drawing.Point(861, 520);
            this.tb61c3.Multiline = true;
            this.tb61c3.Name = "tb61c3";
            this.tb61c3.Size = new System.Drawing.Size(60, 32);
            this.tb61c3.TabIndex = 157;
            this.tb61c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb62c3
            // 
            this.tb62c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb62c3.Location = new System.Drawing.Point(795, 520);
            this.tb62c3.Multiline = true;
            this.tb62c3.Name = "tb62c3";
            this.tb62c3.Size = new System.Drawing.Size(60, 32);
            this.tb62c3.TabIndex = 156;
            this.tb62c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb61c2
            // 
            this.tb61c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb61c2.Location = new System.Drawing.Point(861, 489);
            this.tb61c2.Multiline = true;
            this.tb61c2.Name = "tb61c2";
            this.tb61c2.Size = new System.Drawing.Size(60, 32);
            this.tb61c2.TabIndex = 155;
            this.tb61c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb62c2
            // 
            this.tb62c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb62c2.Location = new System.Drawing.Point(795, 489);
            this.tb62c2.Multiline = true;
            this.tb62c2.Name = "tb62c2";
            this.tb62c2.Size = new System.Drawing.Size(60, 32);
            this.tb62c2.TabIndex = 154;
            this.tb62c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb61c1
            // 
            this.tb61c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb61c1.Location = new System.Drawing.Point(861, 458);
            this.tb61c1.Multiline = true;
            this.tb61c1.Name = "tb61c1";
            this.tb61c1.Size = new System.Drawing.Size(60, 32);
            this.tb61c1.TabIndex = 153;
            this.tb61c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb62c1
            // 
            this.tb62c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb62c1.Location = new System.Drawing.Point(795, 458);
            this.tb62c1.Multiline = true;
            this.tb62c1.Name = "tb62c1";
            this.tb62c1.Size = new System.Drawing.Size(60, 32);
            this.tb62c1.TabIndex = 152;
            this.tb62c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb61l
            // 
            this.tb61l.BackColor = System.Drawing.Color.Salmon;
            this.tb61l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb61l.Location = new System.Drawing.Point(861, 420);
            this.tb61l.Multiline = true;
            this.tb61l.Name = "tb61l";
            this.tb61l.Size = new System.Drawing.Size(60, 32);
            this.tb61l.TabIndex = 151;
            this.tb61l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb62l
            // 
            this.tb62l.BackColor = System.Drawing.Color.Salmon;
            this.tb62l.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb62l.Location = new System.Drawing.Point(795, 420);
            this.tb62l.Multiline = true;
            this.tb62l.Name = "tb62l";
            this.tb62l.Size = new System.Drawing.Size(60, 32);
            this.tb62l.TabIndex = 150;
            this.tb62l.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb61
            // 
            this.tb61.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb61.Location = new System.Drawing.Point(861, 382);
            this.tb61.Multiline = true;
            this.tb61.Name = "tb61";
            this.tb61.Size = new System.Drawing.Size(60, 32);
            this.tb61.TabIndex = 149;
            this.tb61.Text = "61";
            this.tb61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb62
            // 
            this.tb62.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb62.Location = new System.Drawing.Point(795, 382);
            this.tb62.Multiline = true;
            this.tb62.Name = "tb62";
            this.tb62.Size = new System.Drawing.Size(60, 32);
            this.tb62.TabIndex = 148;
            this.tb62.Text = "62";
            this.tb62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb77c4
            // 
            this.tb77c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb77c4.Location = new System.Drawing.Point(1138, 513);
            this.tb77c4.Multiline = true;
            this.tb77c4.Name = "tb77c4";
            this.tb77c4.Size = new System.Drawing.Size(60, 32);
            this.tb77c4.TabIndex = 177;
            this.tb77c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb76c4
            // 
            this.tb76c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb76c4.Location = new System.Drawing.Point(1072, 513);
            this.tb76c4.Multiline = true;
            this.tb76c4.Name = "tb76c4";
            this.tb76c4.Size = new System.Drawing.Size(60, 32);
            this.tb76c4.TabIndex = 176;
            this.tb76c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb77c3
            // 
            this.tb77c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb77c3.Location = new System.Drawing.Point(1138, 482);
            this.tb77c3.Multiline = true;
            this.tb77c3.Name = "tb77c3";
            this.tb77c3.Size = new System.Drawing.Size(60, 32);
            this.tb77c3.TabIndex = 175;
            this.tb77c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb76c3
            // 
            this.tb76c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb76c3.Location = new System.Drawing.Point(1072, 482);
            this.tb76c3.Multiline = true;
            this.tb76c3.Name = "tb76c3";
            this.tb76c3.Size = new System.Drawing.Size(60, 32);
            this.tb76c3.TabIndex = 174;
            this.tb76c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb77c2
            // 
            this.tb77c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb77c2.Location = new System.Drawing.Point(1138, 451);
            this.tb77c2.Multiline = true;
            this.tb77c2.Name = "tb77c2";
            this.tb77c2.Size = new System.Drawing.Size(60, 32);
            this.tb77c2.TabIndex = 173;
            this.tb77c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb76c2
            // 
            this.tb76c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb76c2.Location = new System.Drawing.Point(1072, 451);
            this.tb76c2.Multiline = true;
            this.tb76c2.Name = "tb76c2";
            this.tb76c2.Size = new System.Drawing.Size(60, 32);
            this.tb76c2.TabIndex = 172;
            this.tb76c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb77c1
            // 
            this.tb77c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb77c1.Location = new System.Drawing.Point(1138, 420);
            this.tb77c1.Multiline = true;
            this.tb77c1.Name = "tb77c1";
            this.tb77c1.Size = new System.Drawing.Size(60, 32);
            this.tb77c1.TabIndex = 171;
            this.tb77c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb76c1
            // 
            this.tb76c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb76c1.Location = new System.Drawing.Point(1072, 420);
            this.tb76c1.Multiline = true;
            this.tb76c1.Name = "tb76c1";
            this.tb76c1.Size = new System.Drawing.Size(60, 32);
            this.tb76c1.TabIndex = 170;
            this.tb76c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb77
            // 
            this.tb77.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb77.Location = new System.Drawing.Point(1138, 382);
            this.tb77.Multiline = true;
            this.tb77.Name = "tb77";
            this.tb77.Size = new System.Drawing.Size(60, 32);
            this.tb77.TabIndex = 169;
            this.tb77.Text = "77";
            this.tb77.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb76
            // 
            this.tb76.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb76.Location = new System.Drawing.Point(1072, 382);
            this.tb76.Multiline = true;
            this.tb76.Name = "tb76";
            this.tb76.Size = new System.Drawing.Size(60, 32);
            this.tb76.TabIndex = 168;
            this.tb76.Text = "76";
            this.tb76.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb75c4
            // 
            this.tb75c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb75c4.Location = new System.Drawing.Point(1006, 513);
            this.tb75c4.Multiline = true;
            this.tb75c4.Name = "tb75c4";
            this.tb75c4.Size = new System.Drawing.Size(60, 32);
            this.tb75c4.TabIndex = 167;
            this.tb75c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb74c4
            // 
            this.tb74c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb74c4.Location = new System.Drawing.Point(940, 513);
            this.tb74c4.Multiline = true;
            this.tb74c4.Name = "tb74c4";
            this.tb74c4.Size = new System.Drawing.Size(60, 32);
            this.tb74c4.TabIndex = 166;
            this.tb74c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb75c3
            // 
            this.tb75c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb75c3.Location = new System.Drawing.Point(1006, 482);
            this.tb75c3.Multiline = true;
            this.tb75c3.Name = "tb75c3";
            this.tb75c3.Size = new System.Drawing.Size(60, 32);
            this.tb75c3.TabIndex = 165;
            this.tb75c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb74c3
            // 
            this.tb74c3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb74c3.Location = new System.Drawing.Point(940, 482);
            this.tb74c3.Multiline = true;
            this.tb74c3.Name = "tb74c3";
            this.tb74c3.Size = new System.Drawing.Size(60, 32);
            this.tb74c3.TabIndex = 164;
            this.tb74c3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb75c2
            // 
            this.tb75c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb75c2.Location = new System.Drawing.Point(1006, 451);
            this.tb75c2.Multiline = true;
            this.tb75c2.Name = "tb75c2";
            this.tb75c2.Size = new System.Drawing.Size(60, 32);
            this.tb75c2.TabIndex = 163;
            this.tb75c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb74c2
            // 
            this.tb74c2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb74c2.Location = new System.Drawing.Point(940, 451);
            this.tb74c2.Multiline = true;
            this.tb74c2.Name = "tb74c2";
            this.tb74c2.Size = new System.Drawing.Size(60, 32);
            this.tb74c2.TabIndex = 162;
            this.tb74c2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb75c1
            // 
            this.tb75c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb75c1.Location = new System.Drawing.Point(1006, 420);
            this.tb75c1.Multiline = true;
            this.tb75c1.Name = "tb75c1";
            this.tb75c1.Size = new System.Drawing.Size(60, 32);
            this.tb75c1.TabIndex = 161;
            this.tb75c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb74c1
            // 
            this.tb74c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb74c1.Location = new System.Drawing.Point(940, 420);
            this.tb74c1.Multiline = true;
            this.tb74c1.Name = "tb74c1";
            this.tb74c1.Size = new System.Drawing.Size(60, 32);
            this.tb74c1.TabIndex = 160;
            this.tb74c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb75
            // 
            this.tb75.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb75.Location = new System.Drawing.Point(1006, 382);
            this.tb75.Multiline = true;
            this.tb75.Name = "tb75";
            this.tb75.Size = new System.Drawing.Size(60, 32);
            this.tb75.TabIndex = 159;
            this.tb75.Text = "75";
            this.tb75.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb74
            // 
            this.tb74.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb74.Location = new System.Drawing.Point(940, 382);
            this.tb74.Multiline = true;
            this.tb74.Name = "tb74";
            this.tb74.Size = new System.Drawing.Size(60, 32);
            this.tb74.TabIndex = 158;
            this.tb74.Text = "74";
            this.tb74.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb16c1
            // 
            this.tb16c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb16c1.Location = new System.Drawing.Point(1277, 506);
            this.tb16c1.Multiline = true;
            this.tb16c1.Name = "tb16c1";
            this.tb16c1.Size = new System.Drawing.Size(60, 32);
            this.tb16c1.TabIndex = 187;
            this.tb16c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb16
            // 
            this.tb16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb16.Location = new System.Drawing.Point(1211, 506);
            this.tb16.Multiline = true;
            this.tb16.Name = "tb16";
            this.tb16.Size = new System.Drawing.Size(60, 32);
            this.tb16.TabIndex = 186;
            this.tb16.Text = "16";
            this.tb16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb15c1
            // 
            this.tb15c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb15c1.Location = new System.Drawing.Point(1277, 475);
            this.tb15c1.Multiline = true;
            this.tb15c1.Name = "tb15c1";
            this.tb15c1.Size = new System.Drawing.Size(60, 32);
            this.tb15c1.TabIndex = 185;
            this.tb15c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb15
            // 
            this.tb15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb15.Location = new System.Drawing.Point(1211, 475);
            this.tb15.Multiline = true;
            this.tb15.Name = "tb15";
            this.tb15.Size = new System.Drawing.Size(60, 32);
            this.tb15.TabIndex = 184;
            this.tb15.Text = "15";
            this.tb15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb14c1
            // 
            this.tb14c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb14c1.Location = new System.Drawing.Point(1277, 444);
            this.tb14c1.Multiline = true;
            this.tb14c1.Name = "tb14c1";
            this.tb14c1.Size = new System.Drawing.Size(60, 32);
            this.tb14c1.TabIndex = 183;
            this.tb14c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb14
            // 
            this.tb14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb14.Location = new System.Drawing.Point(1211, 444);
            this.tb14.Multiline = true;
            this.tb14.Name = "tb14";
            this.tb14.Size = new System.Drawing.Size(60, 32);
            this.tb14.TabIndex = 182;
            this.tb14.Text = "14";
            this.tb14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb13c1
            // 
            this.tb13c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb13c1.Location = new System.Drawing.Point(1277, 413);
            this.tb13c1.Multiline = true;
            this.tb13c1.Name = "tb13c1";
            this.tb13c1.Size = new System.Drawing.Size(60, 32);
            this.tb13c1.TabIndex = 181;
            this.tb13c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb13
            // 
            this.tb13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb13.Location = new System.Drawing.Point(1211, 413);
            this.tb13.Multiline = true;
            this.tb13.Name = "tb13";
            this.tb13.Size = new System.Drawing.Size(60, 32);
            this.tb13.TabIndex = 180;
            this.tb13.Text = "13";
            this.tb13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb12c1
            // 
            this.tb12c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb12c1.Location = new System.Drawing.Point(1277, 382);
            this.tb12c1.Multiline = true;
            this.tb12c1.Name = "tb12c1";
            this.tb12c1.Size = new System.Drawing.Size(60, 32);
            this.tb12c1.TabIndex = 179;
            this.tb12c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb12
            // 
            this.tb12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb12.Location = new System.Drawing.Point(1211, 382);
            this.tb12.Multiline = true;
            this.tb12.Name = "tb12";
            this.tb12.Size = new System.Drawing.Size(60, 32);
            this.tb12.TabIndex = 178;
            this.tb12.Text = "12";
            this.tb12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb20c1
            // 
            this.tb20c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb20c1.Location = new System.Drawing.Point(1277, 630);
            this.tb20c1.Multiline = true;
            this.tb20c1.Name = "tb20c1";
            this.tb20c1.Size = new System.Drawing.Size(60, 32);
            this.tb20c1.TabIndex = 195;
            this.tb20c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb20
            // 
            this.tb20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb20.Location = new System.Drawing.Point(1211, 630);
            this.tb20.Multiline = true;
            this.tb20.Name = "tb20";
            this.tb20.Size = new System.Drawing.Size(60, 32);
            this.tb20.TabIndex = 194;
            this.tb20.Text = "20";
            this.tb20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb19c1
            // 
            this.tb19c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb19c1.Location = new System.Drawing.Point(1277, 599);
            this.tb19c1.Multiline = true;
            this.tb19c1.Name = "tb19c1";
            this.tb19c1.Size = new System.Drawing.Size(60, 32);
            this.tb19c1.TabIndex = 193;
            this.tb19c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb19
            // 
            this.tb19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb19.Location = new System.Drawing.Point(1211, 599);
            this.tb19.Multiline = true;
            this.tb19.Name = "tb19";
            this.tb19.Size = new System.Drawing.Size(60, 32);
            this.tb19.TabIndex = 192;
            this.tb19.Text = "19";
            this.tb19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb18c1
            // 
            this.tb18c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb18c1.Location = new System.Drawing.Point(1277, 568);
            this.tb18c1.Multiline = true;
            this.tb18c1.Name = "tb18c1";
            this.tb18c1.Size = new System.Drawing.Size(60, 32);
            this.tb18c1.TabIndex = 191;
            this.tb18c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb18
            // 
            this.tb18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb18.Location = new System.Drawing.Point(1211, 568);
            this.tb18.Multiline = true;
            this.tb18.Name = "tb18";
            this.tb18.Size = new System.Drawing.Size(60, 32);
            this.tb18.TabIndex = 190;
            this.tb18.Text = "18";
            this.tb18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb17c1
            // 
            this.tb17c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb17c1.Location = new System.Drawing.Point(1277, 537);
            this.tb17c1.Multiline = true;
            this.tb17c1.Name = "tb17c1";
            this.tb17c1.Size = new System.Drawing.Size(60, 32);
            this.tb17c1.TabIndex = 189;
            this.tb17c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb17
            // 
            this.tb17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb17.Location = new System.Drawing.Point(1211, 537);
            this.tb17.Multiline = true;
            this.tb17.Name = "tb17";
            this.tb17.Size = new System.Drawing.Size(60, 32);
            this.tb17.TabIndex = 188;
            this.tb17.Text = "17";
            this.tb17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb21c1
            // 
            this.tb21c1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb21c1.Location = new System.Drawing.Point(1277, 661);
            this.tb21c1.Multiline = true;
            this.tb21c1.Name = "tb21c1";
            this.tb21c1.Size = new System.Drawing.Size(60, 32);
            this.tb21c1.TabIndex = 197;
            this.tb21c1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb21
            // 
            this.tb21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb21.Location = new System.Drawing.Point(1211, 661);
            this.tb21.Multiline = true;
            this.tb21.Name = "tb21";
            this.tb21.Size = new System.Drawing.Size(60, 32);
            this.tb21.TabIndex = 196;
            this.tb21.Text = "21";
            this.tb21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51c6
            // 
            this.tb51c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51c6.Location = new System.Drawing.Point(597, 613);
            this.tb51c6.Multiline = true;
            this.tb51c6.Name = "tb51c6";
            this.tb51c6.Size = new System.Drawing.Size(60, 32);
            this.tb51c6.TabIndex = 218;
            this.tb51c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c6
            // 
            this.tb52c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c6.Location = new System.Drawing.Point(531, 613);
            this.tb52c6.Multiline = true;
            this.tb52c6.Name = "tb52c6";
            this.tb52c6.Size = new System.Drawing.Size(60, 32);
            this.tb52c6.TabIndex = 217;
            this.tb52c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c6
            // 
            this.tb53c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c6.Location = new System.Drawing.Point(465, 613);
            this.tb53c6.Multiline = true;
            this.tb53c6.Name = "tb53c6";
            this.tb53c6.Size = new System.Drawing.Size(60, 32);
            this.tb53c6.TabIndex = 216;
            this.tb53c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c6
            // 
            this.tb54c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c6.Location = new System.Drawing.Point(399, 613);
            this.tb54c6.Multiline = true;
            this.tb54c6.Name = "tb54c6";
            this.tb54c6.Size = new System.Drawing.Size(60, 32);
            this.tb54c6.TabIndex = 215;
            this.tb54c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c6
            // 
            this.tb55c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c6.Location = new System.Drawing.Point(333, 613);
            this.tb55c6.Multiline = true;
            this.tb55c6.Name = "tb55c6";
            this.tb55c6.Size = new System.Drawing.Size(60, 32);
            this.tb55c6.TabIndex = 214;
            this.tb55c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c6
            // 
            this.tb56c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c6.Location = new System.Drawing.Point(267, 613);
            this.tb56c6.Multiline = true;
            this.tb56c6.Name = "tb56c6";
            this.tb56c6.Size = new System.Drawing.Size(60, 32);
            this.tb56c6.TabIndex = 213;
            this.tb56c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c6
            // 
            this.tb57c6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c6.Location = new System.Drawing.Point(201, 613);
            this.tb57c6.Multiline = true;
            this.tb57c6.Name = "tb57c6";
            this.tb57c6.Size = new System.Drawing.Size(60, 32);
            this.tb57c6.TabIndex = 212;
            this.tb57c6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51c5
            // 
            this.tb51c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51c5.Location = new System.Drawing.Point(597, 582);
            this.tb51c5.Multiline = true;
            this.tb51c5.Name = "tb51c5";
            this.tb51c5.Size = new System.Drawing.Size(60, 32);
            this.tb51c5.TabIndex = 211;
            this.tb51c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c5
            // 
            this.tb52c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c5.Location = new System.Drawing.Point(531, 582);
            this.tb52c5.Multiline = true;
            this.tb52c5.Name = "tb52c5";
            this.tb52c5.Size = new System.Drawing.Size(60, 32);
            this.tb52c5.TabIndex = 210;
            this.tb52c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c5
            // 
            this.tb53c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c5.Location = new System.Drawing.Point(465, 582);
            this.tb53c5.Multiline = true;
            this.tb53c5.Name = "tb53c5";
            this.tb53c5.Size = new System.Drawing.Size(60, 32);
            this.tb53c5.TabIndex = 209;
            this.tb53c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c5
            // 
            this.tb54c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c5.Location = new System.Drawing.Point(399, 582);
            this.tb54c5.Multiline = true;
            this.tb54c5.Name = "tb54c5";
            this.tb54c5.Size = new System.Drawing.Size(60, 32);
            this.tb54c5.TabIndex = 208;
            this.tb54c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c5
            // 
            this.tb55c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c5.Location = new System.Drawing.Point(333, 582);
            this.tb55c5.Multiline = true;
            this.tb55c5.Name = "tb55c5";
            this.tb55c5.Size = new System.Drawing.Size(60, 32);
            this.tb55c5.TabIndex = 207;
            this.tb55c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c5
            // 
            this.tb56c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c5.Location = new System.Drawing.Point(267, 582);
            this.tb56c5.Multiline = true;
            this.tb56c5.Name = "tb56c5";
            this.tb56c5.Size = new System.Drawing.Size(60, 32);
            this.tb56c5.TabIndex = 206;
            this.tb56c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c5
            // 
            this.tb57c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c5.Location = new System.Drawing.Point(201, 582);
            this.tb57c5.Multiline = true;
            this.tb57c5.Name = "tb57c5";
            this.tb57c5.Size = new System.Drawing.Size(60, 32);
            this.tb57c5.TabIndex = 205;
            this.tb57c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb51c4
            // 
            this.tb51c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb51c4.Location = new System.Drawing.Point(597, 551);
            this.tb51c4.Multiline = true;
            this.tb51c4.Name = "tb51c4";
            this.tb51c4.Size = new System.Drawing.Size(60, 32);
            this.tb51c4.TabIndex = 204;
            this.tb51c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c4
            // 
            this.tb52c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c4.Location = new System.Drawing.Point(531, 551);
            this.tb52c4.Multiline = true;
            this.tb52c4.Name = "tb52c4";
            this.tb52c4.Size = new System.Drawing.Size(60, 32);
            this.tb52c4.TabIndex = 203;
            this.tb52c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c4
            // 
            this.tb53c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c4.Location = new System.Drawing.Point(465, 551);
            this.tb53c4.Multiline = true;
            this.tb53c4.Name = "tb53c4";
            this.tb53c4.Size = new System.Drawing.Size(60, 32);
            this.tb53c4.TabIndex = 202;
            this.tb53c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c4
            // 
            this.tb54c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c4.Location = new System.Drawing.Point(399, 551);
            this.tb54c4.Multiline = true;
            this.tb54c4.Name = "tb54c4";
            this.tb54c4.Size = new System.Drawing.Size(60, 32);
            this.tb54c4.TabIndex = 201;
            this.tb54c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c4
            // 
            this.tb55c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c4.Location = new System.Drawing.Point(333, 551);
            this.tb55c4.Multiline = true;
            this.tb55c4.Name = "tb55c4";
            this.tb55c4.Size = new System.Drawing.Size(60, 32);
            this.tb55c4.TabIndex = 200;
            this.tb55c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c4
            // 
            this.tb56c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c4.Location = new System.Drawing.Point(267, 551);
            this.tb56c4.Multiline = true;
            this.tb56c4.Name = "tb56c4";
            this.tb56c4.Size = new System.Drawing.Size(60, 32);
            this.tb56c4.TabIndex = 199;
            this.tb56c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c4
            // 
            this.tb57c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c4.Location = new System.Drawing.Point(201, 551);
            this.tb57c4.Multiline = true;
            this.tb57c4.Name = "tb57c4";
            this.tb57c4.Size = new System.Drawing.Size(60, 32);
            this.tb57c4.TabIndex = 198;
            this.tb57c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64c4
            // 
            this.tb64c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64c4.Location = new System.Drawing.Point(663, 551);
            this.tb64c4.Multiline = true;
            this.tb64c4.Name = "tb64c4";
            this.tb64c4.Size = new System.Drawing.Size(60, 32);
            this.tb64c4.TabIndex = 219;
            this.tb64c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb63c4
            // 
            this.tb63c4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb63c4.Location = new System.Drawing.Point(729, 551);
            this.tb63c4.Multiline = true;
            this.tb63c4.Name = "tb63c4";
            this.tb63c4.Size = new System.Drawing.Size(60, 32);
            this.tb63c4.TabIndex = 220;
            this.tb63c4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb64c5
            // 
            this.tb64c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb64c5.Location = new System.Drawing.Point(663, 582);
            this.tb64c5.Multiline = true;
            this.tb64c5.Name = "tb64c5";
            this.tb64c5.Size = new System.Drawing.Size(60, 32);
            this.tb64c5.TabIndex = 221;
            this.tb64c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb52c7
            // 
            this.tb52c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb52c7.Location = new System.Drawing.Point(531, 644);
            this.tb52c7.Multiline = true;
            this.tb52c7.Name = "tb52c7";
            this.tb52c7.Size = new System.Drawing.Size(60, 32);
            this.tb52c7.TabIndex = 227;
            this.tb52c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb53c7
            // 
            this.tb53c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb53c7.Location = new System.Drawing.Point(465, 644);
            this.tb53c7.Multiline = true;
            this.tb53c7.Name = "tb53c7";
            this.tb53c7.Size = new System.Drawing.Size(60, 32);
            this.tb53c7.TabIndex = 226;
            this.tb53c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb54c7
            // 
            this.tb54c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb54c7.Location = new System.Drawing.Point(399, 644);
            this.tb54c7.Multiline = true;
            this.tb54c7.Name = "tb54c7";
            this.tb54c7.Size = new System.Drawing.Size(60, 32);
            this.tb54c7.TabIndex = 225;
            this.tb54c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c7
            // 
            this.tb55c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c7.Location = new System.Drawing.Point(333, 644);
            this.tb55c7.Multiline = true;
            this.tb55c7.Name = "tb55c7";
            this.tb55c7.Size = new System.Drawing.Size(60, 32);
            this.tb55c7.TabIndex = 224;
            this.tb55c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c7
            // 
            this.tb56c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c7.Location = new System.Drawing.Point(267, 644);
            this.tb56c7.Multiline = true;
            this.tb56c7.Name = "tb56c7";
            this.tb56c7.Size = new System.Drawing.Size(60, 32);
            this.tb56c7.TabIndex = 223;
            this.tb56c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c7
            // 
            this.tb57c7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c7.Location = new System.Drawing.Point(201, 644);
            this.tb57c7.Multiline = true;
            this.tb57c7.Name = "tb57c7";
            this.tb57c7.Size = new System.Drawing.Size(60, 32);
            this.tb57c7.TabIndex = 222;
            this.tb57c7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb55c8
            // 
            this.tb55c8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb55c8.Location = new System.Drawing.Point(333, 675);
            this.tb55c8.Multiline = true;
            this.tb55c8.Name = "tb55c8";
            this.tb55c8.Size = new System.Drawing.Size(60, 32);
            this.tb55c8.TabIndex = 230;
            this.tb55c8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb56c8
            // 
            this.tb56c8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb56c8.Location = new System.Drawing.Point(267, 675);
            this.tb56c8.Multiline = true;
            this.tb56c8.Name = "tb56c8";
            this.tb56c8.Size = new System.Drawing.Size(60, 32);
            this.tb56c8.TabIndex = 229;
            this.tb56c8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb57c8
            // 
            this.tb57c8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb57c8.Location = new System.Drawing.Point(201, 675);
            this.tb57c8.Multiline = true;
            this.tb57c8.Name = "tb57c8";
            this.tb57c8.Size = new System.Drawing.Size(60, 32);
            this.tb57c8.TabIndex = 228;
            this.tb57c8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb77c5
            // 
            this.tb77c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb77c5.Location = new System.Drawing.Point(1138, 544);
            this.tb77c5.Multiline = true;
            this.tb77c5.Name = "tb77c5";
            this.tb77c5.Size = new System.Drawing.Size(60, 32);
            this.tb77c5.TabIndex = 233;
            this.tb77c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb76c5
            // 
            this.tb76c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb76c5.Location = new System.Drawing.Point(1072, 544);
            this.tb76c5.Multiline = true;
            this.tb76c5.Name = "tb76c5";
            this.tb76c5.Size = new System.Drawing.Size(60, 32);
            this.tb76c5.TabIndex = 232;
            this.tb76c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb74c5
            // 
            this.tb74c5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb74c5.Location = new System.Drawing.Point(940, 544);
            this.tb74c5.Multiline = true;
            this.tb74c5.Name = "tb74c5";
            this.tb74c5.Size = new System.Drawing.Size(60, 32);
            this.tb74c5.TabIndex = 231;
            this.tb74c5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnInvoerTramnummer
            // 
            this.btnInvoerTramnummer.Location = new System.Drawing.Point(12, 72);
            this.btnInvoerTramnummer.Name = "btnInvoerTramnummer";
            this.btnInvoerTramnummer.Size = new System.Drawing.Size(114, 23);
            this.btnInvoerTramnummer.TabIndex = 234;
            this.btnInvoerTramnummer.Text = "Invoer Tramnummer";
            this.btnInvoerTramnummer.UseVisualStyleBackColor = true;
            this.btnInvoerTramnummer.Click += new System.EventHandler(this.btnInvoerTramnummer_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 102);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 23);
            this.button2.TabIndex = 235;
            this.button2.Text = "Testdata simulatie";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(12, 131);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 23);
            this.button3.TabIndex = 236;
            this.button3.Text = "Reset Data";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.tbSpoor);
            this.panel1.Controls.Add(this.tbTram);
            this.panel1.Location = new System.Drawing.Point(11, 160);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(165, 181);
            this.panel1.TabIndex = 237;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(56, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Spoor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tram";
            // 
            // tbSpoor
            // 
            this.tbSpoor.Location = new System.Drawing.Point(33, 119);
            this.tbSpoor.Name = "tbSpoor";
            this.tbSpoor.Size = new System.Drawing.Size(100, 20);
            this.tbSpoor.TabIndex = 1;
            // 
            // tbTram
            // 
            this.tbTram.Location = new System.Drawing.Point(33, 46);
            this.tbTram.Name = "tbTram";
            this.tbTram.Size = new System.Drawing.Size(100, 20);
            this.tbTram.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.lbReserveringen);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(12, 360);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(165, 314);
            this.panel4.TabIndex = 239;
            // 
            // lbReserveringen
            // 
            this.lbReserveringen.FormattingEnabled = true;
            this.lbReserveringen.Location = new System.Drawing.Point(20, 54);
            this.lbReserveringen.Name = "lbReserveringen";
            this.lbReserveringen.Size = new System.Drawing.Size(120, 238);
            this.lbReserveringen.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 31);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "Reserveringen";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 23);
            this.button1.TabIndex = 240;
            this.button1.Text = "Sluit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Wagenparkbeheersysteem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 716);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnInvoerTramnummer);
            this.Controls.Add(this.tb77c5);
            this.Controls.Add(this.tb76c5);
            this.Controls.Add(this.tb74c5);
            this.Controls.Add(this.tb55c8);
            this.Controls.Add(this.tb56c8);
            this.Controls.Add(this.tb57c8);
            this.Controls.Add(this.tb52c7);
            this.Controls.Add(this.tb53c7);
            this.Controls.Add(this.tb54c7);
            this.Controls.Add(this.tb55c7);
            this.Controls.Add(this.tb56c7);
            this.Controls.Add(this.tb57c7);
            this.Controls.Add(this.tb64c5);
            this.Controls.Add(this.tb63c4);
            this.Controls.Add(this.tb64c4);
            this.Controls.Add(this.tb51c6);
            this.Controls.Add(this.tb52c6);
            this.Controls.Add(this.tb53c6);
            this.Controls.Add(this.tb54c6);
            this.Controls.Add(this.tb55c6);
            this.Controls.Add(this.tb56c6);
            this.Controls.Add(this.tb57c6);
            this.Controls.Add(this.tb51c5);
            this.Controls.Add(this.tb52c5);
            this.Controls.Add(this.tb53c5);
            this.Controls.Add(this.tb54c5);
            this.Controls.Add(this.tb55c5);
            this.Controls.Add(this.tb56c5);
            this.Controls.Add(this.tb57c5);
            this.Controls.Add(this.tb51c4);
            this.Controls.Add(this.tb52c4);
            this.Controls.Add(this.tb53c4);
            this.Controls.Add(this.tb54c4);
            this.Controls.Add(this.tb55c4);
            this.Controls.Add(this.tb56c4);
            this.Controls.Add(this.tb57c4);
            this.Controls.Add(this.tb21c1);
            this.Controls.Add(this.tb21);
            this.Controls.Add(this.tb20c1);
            this.Controls.Add(this.tb20);
            this.Controls.Add(this.tb19c1);
            this.Controls.Add(this.tb19);
            this.Controls.Add(this.tb18c1);
            this.Controls.Add(this.tb18);
            this.Controls.Add(this.tb17c1);
            this.Controls.Add(this.tb17);
            this.Controls.Add(this.tb16c1);
            this.Controls.Add(this.tb16);
            this.Controls.Add(this.tb15c1);
            this.Controls.Add(this.tb15);
            this.Controls.Add(this.tb14c1);
            this.Controls.Add(this.tb14);
            this.Controls.Add(this.tb13c1);
            this.Controls.Add(this.tb13);
            this.Controls.Add(this.tb12c1);
            this.Controls.Add(this.tb12);
            this.Controls.Add(this.tb77c4);
            this.Controls.Add(this.tb76c4);
            this.Controls.Add(this.tb77c3);
            this.Controls.Add(this.tb76c3);
            this.Controls.Add(this.tb77c2);
            this.Controls.Add(this.tb76c2);
            this.Controls.Add(this.tb77c1);
            this.Controls.Add(this.tb76c1);
            this.Controls.Add(this.tb77);
            this.Controls.Add(this.tb76);
            this.Controls.Add(this.tb75c4);
            this.Controls.Add(this.tb74c4);
            this.Controls.Add(this.tb75c3);
            this.Controls.Add(this.tb74c3);
            this.Controls.Add(this.tb75c2);
            this.Controls.Add(this.tb74c2);
            this.Controls.Add(this.tb75c1);
            this.Controls.Add(this.tb74c1);
            this.Controls.Add(this.tb75);
            this.Controls.Add(this.tb74);
            this.Controls.Add(this.tb61c3);
            this.Controls.Add(this.tb62c3);
            this.Controls.Add(this.tb61c2);
            this.Controls.Add(this.tb62c2);
            this.Controls.Add(this.tb61c1);
            this.Controls.Add(this.tb62c1);
            this.Controls.Add(this.tb61l);
            this.Controls.Add(this.tb62l);
            this.Controls.Add(this.tb61);
            this.Controls.Add(this.tb62);
            this.Controls.Add(this.tb63c3);
            this.Controls.Add(this.tb64c3);
            this.Controls.Add(this.tb51c3);
            this.Controls.Add(this.tb52c3);
            this.Controls.Add(this.tb53c3);
            this.Controls.Add(this.tb54c3);
            this.Controls.Add(this.tb55c3);
            this.Controls.Add(this.tb56c3);
            this.Controls.Add(this.tb57c3);
            this.Controls.Add(this.tb63c2);
            this.Controls.Add(this.tb64c2);
            this.Controls.Add(this.tb51c2);
            this.Controls.Add(this.tb52c2);
            this.Controls.Add(this.tb53c2);
            this.Controls.Add(this.tb54c2);
            this.Controls.Add(this.tb55c2);
            this.Controls.Add(this.tb56c2);
            this.Controls.Add(this.tb57c2);
            this.Controls.Add(this.tb63c1);
            this.Controls.Add(this.tb64c1);
            this.Controls.Add(this.tb51c1);
            this.Controls.Add(this.tb52c1);
            this.Controls.Add(this.tb53c1);
            this.Controls.Add(this.tb54c1);
            this.Controls.Add(this.tb55c1);
            this.Controls.Add(this.tb56c1);
            this.Controls.Add(this.tb57c1);
            this.Controls.Add(this.tb63l);
            this.Controls.Add(this.tb64l);
            this.Controls.Add(this.tb51l);
            this.Controls.Add(this.tb52l);
            this.Controls.Add(this.tb53l);
            this.Controls.Add(this.tb54l);
            this.Controls.Add(this.tb55l);
            this.Controls.Add(this.tb56l);
            this.Controls.Add(this.tb57l);
            this.Controls.Add(this.tb63);
            this.Controls.Add(this.tb64);
            this.Controls.Add(this.tb51);
            this.Controls.Add(this.tb52);
            this.Controls.Add(this.tb53);
            this.Controls.Add(this.tb54);
            this.Controls.Add(this.tb55);
            this.Controls.Add(this.tb56);
            this.Controls.Add(this.tb57);
            this.Controls.Add(this.tb40c8);
            this.Controls.Add(this.tb40c7);
            this.Controls.Add(this.tb40c6);
            this.Controls.Add(this.tb45c9);
            this.Controls.Add(this.tb45c8);
            this.Controls.Add(this.tb45c7);
            this.Controls.Add(this.tb45c6);
            this.Controls.Add(this.tb45c5);
            this.Controls.Add(this.tb58c6);
            this.Controls.Add(this.tb45c4);
            this.Controls.Add(this.tb58c5);
            this.Controls.Add(this.tb40c5);
            this.Controls.Add(this.tb41c4);
            this.Controls.Add(this.tb42c4);
            this.Controls.Add(this.tb43c4);
            this.Controls.Add(this.tb44c4);
            this.Controls.Add(this.tb32c4);
            this.Controls.Add(this.tb33c4);
            this.Controls.Add(this.tb34c4);
            this.Controls.Add(this.tb35c4);
            this.Controls.Add(this.tb36c4);
            this.Controls.Add(this.tb37c4);
            this.Controls.Add(this.tb38c4);
            this.Controls.Add(this.tb45c3);
            this.Controls.Add(this.tb58c4);
            this.Controls.Add(this.tb40c4);
            this.Controls.Add(this.tb41c3);
            this.Controls.Add(this.tb42c3);
            this.Controls.Add(this.tb43c3);
            this.Controls.Add(this.tb44c3);
            this.Controls.Add(this.tb30c3);
            this.Controls.Add(this.tb31c3);
            this.Controls.Add(this.tb32c3);
            this.Controls.Add(this.tb33c3);
            this.Controls.Add(this.tb34c3);
            this.Controls.Add(this.tb35c3);
            this.Controls.Add(this.tb36c3);
            this.Controls.Add(this.tb37c3);
            this.Controls.Add(this.tb38c3);
            this.Controls.Add(this.tb45c2);
            this.Controls.Add(this.tb58c3);
            this.Controls.Add(this.tb40c3);
            this.Controls.Add(this.tb41c2);
            this.Controls.Add(this.tb42c2);
            this.Controls.Add(this.tb43c2);
            this.Controls.Add(this.tb44c2);
            this.Controls.Add(this.tb30c2);
            this.Controls.Add(this.tb31c2);
            this.Controls.Add(this.tb32c2);
            this.Controls.Add(this.tb33c2);
            this.Controls.Add(this.tb34c2);
            this.Controls.Add(this.tb35c2);
            this.Controls.Add(this.tb36c2);
            this.Controls.Add(this.tb37c2);
            this.Controls.Add(this.tb38c2);
            this.Controls.Add(this.tb45c1);
            this.Controls.Add(this.tb58c2);
            this.Controls.Add(this.tb40c2);
            this.Controls.Add(this.tb41c1);
            this.Controls.Add(this.tb42c1);
            this.Controls.Add(this.tb43c1);
            this.Controls.Add(this.tb44c1);
            this.Controls.Add(this.tb30c1);
            this.Controls.Add(this.tb31c1);
            this.Controls.Add(this.tb32c1);
            this.Controls.Add(this.tb33c1);
            this.Controls.Add(this.tb34c1);
            this.Controls.Add(this.tb35c1);
            this.Controls.Add(this.tb36c1);
            this.Controls.Add(this.tb37c1);
            this.Controls.Add(this.tb38c1);
            this.Controls.Add(this.tb45l);
            this.Controls.Add(this.tb58c1);
            this.Controls.Add(this.tb40c1);
            this.Controls.Add(this.tb41l);
            this.Controls.Add(this.tb42l);
            this.Controls.Add(this.tb43l);
            this.Controls.Add(this.tb44l);
            this.Controls.Add(this.tb30l);
            this.Controls.Add(this.tb31l);
            this.Controls.Add(this.tb32l);
            this.Controls.Add(this.tb33l);
            this.Controls.Add(this.tb34l);
            this.Controls.Add(this.tb35l);
            this.Controls.Add(this.tb36l);
            this.Controls.Add(this.tb37l);
            this.Controls.Add(this.tb38l);
            this.Controls.Add(this.tb45);
            this.Controls.Add(this.tb58);
            this.Controls.Add(this.tb40);
            this.Controls.Add(this.tb41);
            this.Controls.Add(this.tb42);
            this.Controls.Add(this.tb43);
            this.Controls.Add(this.tb44);
            this.Controls.Add(this.tb30);
            this.Controls.Add(this.tb31);
            this.Controls.Add(this.tb32);
            this.Controls.Add(this.tb33);
            this.Controls.Add(this.tb34);
            this.Controls.Add(this.tb35);
            this.Controls.Add(this.tb36);
            this.Controls.Add(this.tb37);
            this.Controls.Add(this.tb38);
            this.Name = "Wagenparkbeheersysteem";
            this.Text = "WagenparkBeheer";
            this.Load += new System.EventHandler(this.Wagenparkbeheersysteem_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb38;
        private System.Windows.Forms.TextBox tb37;
        private System.Windows.Forms.TextBox tb36;
        private System.Windows.Forms.TextBox tb35;
        private System.Windows.Forms.TextBox tb34;
        private System.Windows.Forms.TextBox tb33;
        private System.Windows.Forms.TextBox tb32;
        private System.Windows.Forms.TextBox tb31;
        private System.Windows.Forms.TextBox tb30;
        private System.Windows.Forms.TextBox tb44;
        private System.Windows.Forms.TextBox tb43;
        private System.Windows.Forms.TextBox tb42;
        private System.Windows.Forms.TextBox tb41;
        private System.Windows.Forms.TextBox tb40;
        private System.Windows.Forms.TextBox tb58;
        private System.Windows.Forms.TextBox tb45;
        private System.Windows.Forms.TextBox tb45l;
        private System.Windows.Forms.TextBox tb58c1;
        private System.Windows.Forms.TextBox tb40c1;
        private System.Windows.Forms.TextBox tb41l;
        private System.Windows.Forms.TextBox tb42l;
        private System.Windows.Forms.TextBox tb43l;
        private System.Windows.Forms.TextBox tb44l;
        private System.Windows.Forms.TextBox tb30l;
        private System.Windows.Forms.TextBox tb31l;
        private System.Windows.Forms.TextBox tb32l;
        private System.Windows.Forms.TextBox tb33l;
        private System.Windows.Forms.TextBox tb34l;
        private System.Windows.Forms.TextBox tb35l;
        private System.Windows.Forms.TextBox tb36l;
        private System.Windows.Forms.TextBox tb37l;
        private System.Windows.Forms.TextBox tb38l;
        private System.Windows.Forms.TextBox tb45c1;
        private System.Windows.Forms.TextBox tb58c2;
        private System.Windows.Forms.TextBox tb40c2;
        private System.Windows.Forms.TextBox tb41c1;
        private System.Windows.Forms.TextBox tb42c1;
        private System.Windows.Forms.TextBox tb43c1;
        private System.Windows.Forms.TextBox tb44c1;
        private System.Windows.Forms.TextBox tb30c1;
        private System.Windows.Forms.TextBox tb31c1;
        private System.Windows.Forms.TextBox tb32c1;
        private System.Windows.Forms.TextBox tb33c1;
        private System.Windows.Forms.TextBox tb34c1;
        private System.Windows.Forms.TextBox tb35c1;
        private System.Windows.Forms.TextBox tb36c1;
        private System.Windows.Forms.TextBox tb37c1;
        private System.Windows.Forms.TextBox tb38c1;
        private System.Windows.Forms.TextBox tb45c2;
        private System.Windows.Forms.TextBox tb58c3;
        private System.Windows.Forms.TextBox tb40c3;
        private System.Windows.Forms.TextBox tb41c2;
        private System.Windows.Forms.TextBox tb42c2;
        private System.Windows.Forms.TextBox tb43c2;
        private System.Windows.Forms.TextBox tb44c2;
        private System.Windows.Forms.TextBox tb30c2;
        private System.Windows.Forms.TextBox tb31c2;
        private System.Windows.Forms.TextBox tb32c2;
        private System.Windows.Forms.TextBox tb33c2;
        private System.Windows.Forms.TextBox tb34c2;
        private System.Windows.Forms.TextBox tb35c2;
        private System.Windows.Forms.TextBox tb36c2;
        private System.Windows.Forms.TextBox tb37c2;
        private System.Windows.Forms.TextBox tb38c2;
        private System.Windows.Forms.TextBox tb45c3;
        private System.Windows.Forms.TextBox tb58c4;
        private System.Windows.Forms.TextBox tb40c4;
        private System.Windows.Forms.TextBox tb41c3;
        private System.Windows.Forms.TextBox tb42c3;
        private System.Windows.Forms.TextBox tb43c3;
        private System.Windows.Forms.TextBox tb44c3;
        private System.Windows.Forms.TextBox tb30c3;
        private System.Windows.Forms.TextBox tb31c3;
        private System.Windows.Forms.TextBox tb32c3;
        private System.Windows.Forms.TextBox tb33c3;
        private System.Windows.Forms.TextBox tb34c3;
        private System.Windows.Forms.TextBox tb35c3;
        private System.Windows.Forms.TextBox tb36c3;
        private System.Windows.Forms.TextBox tb37c3;
        private System.Windows.Forms.TextBox tb38c3;
        private System.Windows.Forms.TextBox tb32c4;
        private System.Windows.Forms.TextBox tb33c4;
        private System.Windows.Forms.TextBox tb34c4;
        private System.Windows.Forms.TextBox tb35c4;
        private System.Windows.Forms.TextBox tb36c4;
        private System.Windows.Forms.TextBox tb37c4;
        private System.Windows.Forms.TextBox tb38c4;
        private System.Windows.Forms.TextBox tb40c5;
        private System.Windows.Forms.TextBox tb41c4;
        private System.Windows.Forms.TextBox tb42c4;
        private System.Windows.Forms.TextBox tb43c4;
        private System.Windows.Forms.TextBox tb44c4;
        private System.Windows.Forms.TextBox tb45c5;
        private System.Windows.Forms.TextBox tb58c6;
        private System.Windows.Forms.TextBox tb45c4;
        private System.Windows.Forms.TextBox tb58c5;
        private System.Windows.Forms.TextBox tb45c9;
        private System.Windows.Forms.TextBox tb45c8;
        private System.Windows.Forms.TextBox tb45c7;
        private System.Windows.Forms.TextBox tb45c6;
        private System.Windows.Forms.TextBox tb40c8;
        private System.Windows.Forms.TextBox tb40c7;
        private System.Windows.Forms.TextBox tb40c6;
        private System.Windows.Forms.TextBox tb63c3;
        private System.Windows.Forms.TextBox tb64c3;
        private System.Windows.Forms.TextBox tb51c3;
        private System.Windows.Forms.TextBox tb52c3;
        private System.Windows.Forms.TextBox tb53c3;
        private System.Windows.Forms.TextBox tb54c3;
        private System.Windows.Forms.TextBox tb55c3;
        private System.Windows.Forms.TextBox tb56c3;
        private System.Windows.Forms.TextBox tb57c3;
        private System.Windows.Forms.TextBox tb63c2;
        private System.Windows.Forms.TextBox tb64c2;
        private System.Windows.Forms.TextBox tb51c2;
        private System.Windows.Forms.TextBox tb52c2;
        private System.Windows.Forms.TextBox tb53c2;
        private System.Windows.Forms.TextBox tb54c2;
        private System.Windows.Forms.TextBox tb55c2;
        private System.Windows.Forms.TextBox tb56c2;
        private System.Windows.Forms.TextBox tb57c2;
        private System.Windows.Forms.TextBox tb63c1;
        private System.Windows.Forms.TextBox tb64c1;
        private System.Windows.Forms.TextBox tb51c1;
        private System.Windows.Forms.TextBox tb52c1;
        private System.Windows.Forms.TextBox tb53c1;
        private System.Windows.Forms.TextBox tb54c1;
        private System.Windows.Forms.TextBox tb55c1;
        private System.Windows.Forms.TextBox tb56c1;
        private System.Windows.Forms.TextBox tb57c1;
        private System.Windows.Forms.TextBox tb63l;
        private System.Windows.Forms.TextBox tb64l;
        private System.Windows.Forms.TextBox tb51l;
        private System.Windows.Forms.TextBox tb52l;
        private System.Windows.Forms.TextBox tb53l;
        private System.Windows.Forms.TextBox tb54l;
        private System.Windows.Forms.TextBox tb55l;
        private System.Windows.Forms.TextBox tb56l;
        private System.Windows.Forms.TextBox tb57l;
        private System.Windows.Forms.TextBox tb63;
        private System.Windows.Forms.TextBox tb64;
        private System.Windows.Forms.TextBox tb51;
        private System.Windows.Forms.TextBox tb52;
        private System.Windows.Forms.TextBox tb53;
        private System.Windows.Forms.TextBox tb54;
        private System.Windows.Forms.TextBox tb55;
        private System.Windows.Forms.TextBox tb56;
        private System.Windows.Forms.TextBox tb57;
        private System.Windows.Forms.TextBox tb61c3;
        private System.Windows.Forms.TextBox tb62c3;
        private System.Windows.Forms.TextBox tb61c2;
        private System.Windows.Forms.TextBox tb62c2;
        private System.Windows.Forms.TextBox tb61c1;
        private System.Windows.Forms.TextBox tb62c1;
        private System.Windows.Forms.TextBox tb61l;
        private System.Windows.Forms.TextBox tb62l;
        private System.Windows.Forms.TextBox tb61;
        private System.Windows.Forms.TextBox tb62;
        private System.Windows.Forms.TextBox tb77c4;
        private System.Windows.Forms.TextBox tb76c4;
        private System.Windows.Forms.TextBox tb77c3;
        private System.Windows.Forms.TextBox tb76c3;
        private System.Windows.Forms.TextBox tb77c2;
        private System.Windows.Forms.TextBox tb76c2;
        private System.Windows.Forms.TextBox tb77c1;
        private System.Windows.Forms.TextBox tb76c1;
        private System.Windows.Forms.TextBox tb77;
        private System.Windows.Forms.TextBox tb76;
        private System.Windows.Forms.TextBox tb75c4;
        private System.Windows.Forms.TextBox tb74c4;
        private System.Windows.Forms.TextBox tb75c3;
        private System.Windows.Forms.TextBox tb74c3;
        private System.Windows.Forms.TextBox tb75c2;
        private System.Windows.Forms.TextBox tb74c2;
        private System.Windows.Forms.TextBox tb75c1;
        private System.Windows.Forms.TextBox tb74c1;
        private System.Windows.Forms.TextBox tb75;
        private System.Windows.Forms.TextBox tb74;
        private System.Windows.Forms.TextBox tb16c1;
        private System.Windows.Forms.TextBox tb16;
        private System.Windows.Forms.TextBox tb15c1;
        private System.Windows.Forms.TextBox tb15;
        private System.Windows.Forms.TextBox tb14c1;
        private System.Windows.Forms.TextBox tb14;
        private System.Windows.Forms.TextBox tb13c1;
        private System.Windows.Forms.TextBox tb13;
        private System.Windows.Forms.TextBox tb12c1;
        private System.Windows.Forms.TextBox tb12;
        private System.Windows.Forms.TextBox tb20c1;
        private System.Windows.Forms.TextBox tb20;
        private System.Windows.Forms.TextBox tb19c1;
        private System.Windows.Forms.TextBox tb19;
        private System.Windows.Forms.TextBox tb18c1;
        private System.Windows.Forms.TextBox tb18;
        private System.Windows.Forms.TextBox tb17c1;
        private System.Windows.Forms.TextBox tb17;
        private System.Windows.Forms.TextBox tb21c1;
        private System.Windows.Forms.TextBox tb21;
        private System.Windows.Forms.TextBox tb51c6;
        private System.Windows.Forms.TextBox tb52c6;
        private System.Windows.Forms.TextBox tb53c6;
        private System.Windows.Forms.TextBox tb54c6;
        private System.Windows.Forms.TextBox tb55c6;
        private System.Windows.Forms.TextBox tb56c6;
        private System.Windows.Forms.TextBox tb57c6;
        private System.Windows.Forms.TextBox tb51c5;
        private System.Windows.Forms.TextBox tb52c5;
        private System.Windows.Forms.TextBox tb53c5;
        private System.Windows.Forms.TextBox tb54c5;
        private System.Windows.Forms.TextBox tb55c5;
        private System.Windows.Forms.TextBox tb56c5;
        private System.Windows.Forms.TextBox tb57c5;
        private System.Windows.Forms.TextBox tb51c4;
        private System.Windows.Forms.TextBox tb52c4;
        private System.Windows.Forms.TextBox tb53c4;
        private System.Windows.Forms.TextBox tb54c4;
        private System.Windows.Forms.TextBox tb55c4;
        private System.Windows.Forms.TextBox tb56c4;
        private System.Windows.Forms.TextBox tb57c4;
        private System.Windows.Forms.TextBox tb64c4;
        private System.Windows.Forms.TextBox tb63c4;
        private System.Windows.Forms.TextBox tb64c5;
        private System.Windows.Forms.TextBox tb52c7;
        private System.Windows.Forms.TextBox tb53c7;
        private System.Windows.Forms.TextBox tb54c7;
        private System.Windows.Forms.TextBox tb55c7;
        private System.Windows.Forms.TextBox tb56c7;
        private System.Windows.Forms.TextBox tb57c7;
        private System.Windows.Forms.TextBox tb55c8;
        private System.Windows.Forms.TextBox tb56c8;
        private System.Windows.Forms.TextBox tb57c8;
        private System.Windows.Forms.TextBox tb77c5;
        private System.Windows.Forms.TextBox tb76c5;
        private System.Windows.Forms.TextBox tb74c5;
        private System.Windows.Forms.Button btnInvoerTramnummer;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSpoor;
        private System.Windows.Forms.TextBox tbTram;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ListBox lbReserveringen;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
    }
}