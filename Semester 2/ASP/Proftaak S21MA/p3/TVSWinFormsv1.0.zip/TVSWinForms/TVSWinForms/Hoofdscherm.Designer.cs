﻿//-----------------------------------------------------------------------
// <copyright file="Hoofdscherm.Designer.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace TVSWinForms
{
    public partial class Hoofdscherm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnWagenparkBeheer;
        private System.Windows.Forms.Button btnSchoonmaak;
        private System.Windows.Forms.Button btnOnderhoud;
        private System.Windows.Forms.Button btnPlattegrond;
        private System.Windows.Forms.Button btnTramSysteem;
        private System.Windows.Forms.PictureBox pictureBox1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnWagenparkBeheer = new System.Windows.Forms.Button();
            this.btnOnderhoud = new System.Windows.Forms.Button();
            this.btnPlattegrond = new System.Windows.Forms.Button();
            this.btnTramSysteem = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSchoonmaak = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnWagenparkBeheer
            // 
            this.btnWagenparkBeheer.Enabled = false;
            this.btnWagenparkBeheer.Location = new System.Drawing.Point(16, 15);
            this.btnWagenparkBeheer.Margin = new System.Windows.Forms.Padding(0);
            this.btnWagenparkBeheer.Name = "btnWagenparkBeheer";
            this.btnWagenparkBeheer.Size = new System.Drawing.Size(107, 98);
            this.btnWagenparkBeheer.TabIndex = 1;
            this.btnWagenparkBeheer.Text = "Wagenpark beheer";
            this.btnWagenparkBeheer.UseVisualStyleBackColor = true;
            this.btnWagenparkBeheer.Click += new System.EventHandler(this.BtnWagenparkBeheer_Click);
            // 
            // btnOnderhoud
            // 
            this.btnOnderhoud.Enabled = false;
            this.btnOnderhoud.Location = new System.Drawing.Point(159, 15);
            this.btnOnderhoud.Margin = new System.Windows.Forms.Padding(0);
            this.btnOnderhoud.Name = "btnOnderhoud";
            this.btnOnderhoud.Size = new System.Drawing.Size(107, 98);
            this.btnOnderhoud.TabIndex = 3;
            this.btnOnderhoud.Text = "Onderhoud";
            this.btnOnderhoud.UseVisualStyleBackColor = true;
            this.btnOnderhoud.Click += new System.EventHandler(this.BtnOnderhoud_Click);
            // 
            // btnPlattegrond
            // 
            this.btnPlattegrond.Location = new System.Drawing.Point(299, 121);
            this.btnPlattegrond.Margin = new System.Windows.Forms.Padding(0);
            this.btnPlattegrond.Name = "btnPlattegrond";
            this.btnPlattegrond.Size = new System.Drawing.Size(107, 98);
            this.btnPlattegrond.TabIndex = 4;
            this.btnPlattegrond.Text = "Plattegrond";
            this.btnPlattegrond.UseVisualStyleBackColor = true;
            this.btnPlattegrond.Click += new System.EventHandler(this.BtnPlattegrond_Click);
            // 
            // btnTramSysteem
            // 
            this.btnTramSysteem.Enabled = false;
            this.btnTramSysteem.Location = new System.Drawing.Point(16, 121);
            this.btnTramSysteem.Margin = new System.Windows.Forms.Padding(0);
            this.btnTramSysteem.Name = "btnTramSysteem";
            this.btnTramSysteem.Size = new System.Drawing.Size(107, 98);
            this.btnTramSysteem.TabIndex = 5;
            this.btnTramSysteem.Text = "Tram Systeem";
            this.btnTramSysteem.UseVisualStyleBackColor = true;
            this.btnTramSysteem.Click += new System.EventHandler(this.BtnTramSysteem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(131, 121);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 98);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // btnSchoonmaak
            // 
            this.btnSchoonmaak.Enabled = false;
            this.btnSchoonmaak.Location = new System.Drawing.Point(299, 15);
            this.btnSchoonmaak.Margin = new System.Windows.Forms.Padding(0);
            this.btnSchoonmaak.Name = "btnSchoonmaak";
            this.btnSchoonmaak.Size = new System.Drawing.Size(107, 98);
            this.btnSchoonmaak.TabIndex = 2;
            this.btnSchoonmaak.Text = "Schoonmaak";
            this.btnSchoonmaak.UseVisualStyleBackColor = true;
            this.btnSchoonmaak.Click += new System.EventHandler(this.BtnSchoonmaak_Click);
            // 
            // Hoofdscherm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 235);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnTramSysteem);
            this.Controls.Add(this.btnPlattegrond);
            this.Controls.Add(this.btnOnderhoud);
            this.Controls.Add(this.btnSchoonmaak);
            this.Controls.Add(this.btnWagenparkBeheer);
            this.Margin = new System.Windows.Forms.Padding(0);
            this.Name = "Hoofdscherm";
            this.Text = " Tram Verdeel Systeem";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
        }
        #endregion
    }
}