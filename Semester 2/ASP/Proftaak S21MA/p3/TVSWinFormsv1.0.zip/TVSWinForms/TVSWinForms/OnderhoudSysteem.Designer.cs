﻿//-----------------------------------------------------------------------
// <copyright file="Onderhoud.Designer.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace TVSWinForms
{
    public partial class OnderhoudSysteem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblTramnr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTechnicusNaam;
        private System.Windows.Forms.CheckBox cbKlaar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnOngedaanMaken;
        private System.Windows.Forms.Button btnBevestigen;
        private System.Windows.Forms.Button btnTerug;
        private System.Windows.Forms.DateTimePicker dtpTijdsindicatie;
        private System.Windows.Forms.Label lblOnderhoudSoort;
        private System.Windows.Forms.ListView lvOnderhoudslijstlijst;
        private System.Windows.Forms.ColumnHeader soortBeurt;
        private System.Windows.Forms.ColumnHeader beginDatum;
        private System.Windows.Forms.ColumnHeader eindtijd;
        private System.Windows.Forms.ColumnHeader tramnr;
        private System.Windows.Forms.ColumnHeader technicus;
        private System.Windows.Forms.ColumnHeader tijdsindicatie;
        private System.Windows.Forms.Button btnTijdindicatie;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTramnr = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTechnicusNaam = new System.Windows.Forms.Label();
            this.cbKlaar = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnOngedaanMaken = new System.Windows.Forms.Button();
            this.btnBevestigen = new System.Windows.Forms.Button();
            this.btnTerug = new System.Windows.Forms.Button();
            this.dtpTijdsindicatie = new System.Windows.Forms.DateTimePicker();
            this.lblOnderhoudSoort = new System.Windows.Forms.Label();
            this.lvOnderhoudslijstlijst = new System.Windows.Forms.ListView();
            this.soortBeurt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.beginDatum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tijdsindicatie = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.eindtijd = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tramnr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.technicus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnTijdindicatie = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpBeginDatum = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // lblTramnr
            // 
            this.lblTramnr.AutoSize = true;
            this.lblTramnr.Location = new System.Drawing.Point(86, 69);
            this.lblTramnr.Name = "lblTramnr";
            this.lblTramnr.Size = new System.Drawing.Size(10, 13);
            this.lblTramnr.TabIndex = 1;
            this.lblTramnr.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Soort";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tijdsindicatie";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tram";
            // 
            // lblTechnicusNaam
            // 
            this.lblTechnicusNaam.AutoSize = true;
            this.lblTechnicusNaam.Location = new System.Drawing.Point(86, 135);
            this.lblTechnicusNaam.Name = "lblTechnicusNaam";
            this.lblTechnicusNaam.Size = new System.Drawing.Size(10, 13);
            this.lblTechnicusNaam.TabIndex = 9;
            this.lblTechnicusNaam.Text = "-";
            // 
            // cbKlaar
            // 
            this.cbKlaar.AutoSize = true;
            this.cbKlaar.Enabled = false;
            this.cbKlaar.Location = new System.Drawing.Point(86, 157);
            this.cbKlaar.Name = "cbKlaar";
            this.cbKlaar.Size = new System.Drawing.Size(15, 14);
            this.cbKlaar.TabIndex = 10;
            this.cbKlaar.UseVisualStyleBackColor = true;
            this.cbKlaar.CheckedChanged += new System.EventHandler(this.cbKlaar_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Technicus";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 157);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Klaar";
            // 
            // btnOngedaanMaken
            // 
            this.btnOngedaanMaken.Enabled = false;
            this.btnOngedaanMaken.Location = new System.Drawing.Point(218, 177);
            this.btnOngedaanMaken.Name = "btnOngedaanMaken";
            this.btnOngedaanMaken.Size = new System.Drawing.Size(101, 23);
            this.btnOngedaanMaken.TabIndex = 16;
            this.btnOngedaanMaken.Text = "Ongedaan maken";
            this.btnOngedaanMaken.UseVisualStyleBackColor = true;
            this.btnOngedaanMaken.Click += new System.EventHandler(this.btnOngedaanMaken_Click);
            // 
            // btnBevestigen
            // 
            this.btnBevestigen.Enabled = false;
            this.btnBevestigen.Location = new System.Drawing.Point(13, 177);
            this.btnBevestigen.Name = "btnBevestigen";
            this.btnBevestigen.Size = new System.Drawing.Size(75, 23);
            this.btnBevestigen.TabIndex = 15;
            this.btnBevestigen.Text = "Bevestigen";
            this.btnBevestigen.UseVisualStyleBackColor = true;
            this.btnBevestigen.Click += new System.EventHandler(this.btnBevestigen_Click);
            // 
            // btnTerug
            // 
            this.btnTerug.Location = new System.Drawing.Point(14, 11);
            this.btnTerug.Name = "btnTerug";
            this.btnTerug.Size = new System.Drawing.Size(75, 23);
            this.btnTerug.TabIndex = 17;
            this.btnTerug.Text = "Terug";
            this.btnTerug.UseVisualStyleBackColor = true;
            this.btnTerug.Click += new System.EventHandler(this.BtnTerug_Click);
            // 
            // dtpTijdsindicatie
            // 
            this.dtpTijdsindicatie.CustomFormat = "dd-MM-yyyy HH:mm";
            this.dtpTijdsindicatie.Enabled = false;
            this.dtpTijdsindicatie.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTijdsindicatie.Location = new System.Drawing.Point(86, 86);
            this.dtpTijdsindicatie.Name = "dtpTijdsindicatie";
            this.dtpTijdsindicatie.Size = new System.Drawing.Size(126, 20);
            this.dtpTijdsindicatie.TabIndex = 19;
            this.dtpTijdsindicatie.Value = new System.DateTime(2015, 4, 13, 0, 1, 0, 0);
            // 
            // lblOnderhoudSoort
            // 
            this.lblOnderhoudSoort.AutoSize = true;
            this.lblOnderhoudSoort.Location = new System.Drawing.Point(86, 113);
            this.lblOnderhoudSoort.Name = "lblOnderhoudSoort";
            this.lblOnderhoudSoort.Size = new System.Drawing.Size(10, 13);
            this.lblOnderhoudSoort.TabIndex = 20;
            this.lblOnderhoudSoort.Text = "-";
            // 
            // lvOnderhoudslijstlijst
            // 
            this.lvOnderhoudslijstlijst.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.soortBeurt,
            this.beginDatum,
            this.tijdsindicatie,
            this.eindtijd,
            this.tramnr,
            this.technicus});
            this.lvOnderhoudslijstlijst.Location = new System.Drawing.Point(12, 206);
            this.lvOnderhoudslijstlijst.Name = "lvOnderhoudslijstlijst";
            this.lvOnderhoudslijstlijst.Size = new System.Drawing.Size(613, 195);
            this.lvOnderhoudslijstlijst.TabIndex = 21;
            this.lvOnderhoudslijstlijst.UseCompatibleStateImageBehavior = false;
            this.lvOnderhoudslijstlijst.View = System.Windows.Forms.View.Details;
            this.lvOnderhoudslijstlijst.SelectedIndexChanged += new System.EventHandler(this.lvOnderhoudslijstlijst_SelectedIndexChanged);
            // 
            // soortBeurt
            // 
            this.soortBeurt.Text = "Soort beurt";
            this.soortBeurt.Width = 80;
            // 
            // beginDatum
            // 
            this.beginDatum.Text = "Begin datum";
            this.beginDatum.Width = 100;
            // 
            // tijdsindicatie
            // 
            this.tijdsindicatie.Text = "Tijdsindicatie";
            this.tijdsindicatie.Width = 110;
            // 
            // eindtijd
            // 
            this.eindtijd.Text = "Eind tijd";
            this.eindtijd.Width = 110;
            // 
            // tramnr
            // 
            this.tramnr.Text = "Tram nummer";
            this.tramnr.Width = 80;
            // 
            // technicus
            // 
            this.technicus.Text = "Technicus";
            this.technicus.Width = 100;
            // 
            // btnTijdindicatie
            // 
            this.btnTijdindicatie.Enabled = false;
            this.btnTijdindicatie.Location = new System.Drawing.Point(94, 177);
            this.btnTijdindicatie.Name = "btnTijdindicatie";
            this.btnTijdindicatie.Size = new System.Drawing.Size(118, 23);
            this.btnTijdindicatie.TabIndex = 22;
            this.btnTijdindicatie.Text = "Geef tijdindicatie op";
            this.btnTijdindicatie.UseVisualStyleBackColor = true;
            this.btnTijdindicatie.Click += new System.EventHandler(this.btnTijdindicatie_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "Begin Datum";
            // 
            // dtpBeginDatum
            // 
            this.dtpBeginDatum.CustomFormat = "dd-MM-yyyy";
            this.dtpBeginDatum.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpBeginDatum.Location = new System.Drawing.Point(85, 43);
            this.dtpBeginDatum.Name = "dtpBeginDatum";
            this.dtpBeginDatum.Size = new System.Drawing.Size(91, 20);
            this.dtpBeginDatum.TabIndex = 24;
            this.dtpBeginDatum.ValueChanged += new System.EventHandler(this.dtpBeginDatum_ValueChanged);
            // 
            // OnderhoudSysteem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 412);
            this.Controls.Add(this.dtpBeginDatum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnTijdindicatie);
            this.Controls.Add(this.lvOnderhoudslijstlijst);
            this.Controls.Add(this.lblOnderhoudSoort);
            this.Controls.Add(this.dtpTijdsindicatie);
            this.Controls.Add(this.btnTerug);
            this.Controls.Add(this.btnOngedaanMaken);
            this.Controls.Add(this.btnBevestigen);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cbKlaar);
            this.Controls.Add(this.lblTechnicusNaam);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblTramnr);
            this.Name = "OnderhoudSysteem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Onderhoud";
            this.Load += new System.EventHandler(this.Onderhoud_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpBeginDatum;
    }
}