﻿//-----------------------------------------------------------------------
// <copyright file="TramInvoeren.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Objecten;

    public partial class TramInvoeren : Form
    {
        //private static Tram tram;
        private WagenparkbeheerController wagenparkbeheerController;
        private HoofdController hoofdcontroller;
        public Tram tram;
        public int tramNr;
        public int spoorNr;
        public int sectorNr;
        public TramInvoeren()
        {
            InitializeComponent();
            wagenparkbeheerController = new WagenparkbeheerController();
            hoofdcontroller = new HoofdController();
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            string str = tbTramNr.Text;
            if (!Int32.TryParse(str, out tramNr))
            {
                MessageBox.Show("foute invoer");
            }
            

            string str2 = tbSpoorNr.Text;
            if (!Int32.TryParse(str2, out spoorNr))
            {
                MessageBox.Show("foute invoer");
            }
            

            string s = tbSectorNr.Text;
            if(!string.IsNullOrEmpty(s))
            {
                string str3 = tbSectorNr.Text;
                if (!Int32.TryParse(str3, out sectorNr))
                {
                    MessageBox.Show("foute invoer");
                }
            }

            if(tramNr >-1 && spoorNr >-1)
            {
                if(sectorNr == 0)
                {
                    sectorNr = wagenparkbeheerController.HaalHoogsteSectorOp(spoorNr);
                }
                try
                {
                    tram = wagenparkbeheerController.TramInvoeren(tramNr, spoorNr, sectorNr);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                    return;
                }

                this.Hide();
            }
            else
            {
                MessageBox.Show("Niet alle velden zijn ingevuld");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
