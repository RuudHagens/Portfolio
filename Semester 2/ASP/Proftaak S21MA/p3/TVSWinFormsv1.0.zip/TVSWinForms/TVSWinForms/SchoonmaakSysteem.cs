﻿//-----------------------------------------------------------------------
// <copyright file="SchoonmaakSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Objecten;

    public partial class SchoonmaakSysteem : Form
    {
        private SchoonmaakController schoonmaakcontroller = new SchoonmaakController();

        public SchoonmaakSysteem()
        {
            this.InitializeComponent();
        }

        private void BtnOk_Click(object sender, EventArgs e)
        {
            if (cbKlaar.Checked)
            {
                DialogResult bevestiginBeurt = MessageBox.Show("weet je zeker dat de schoonmaak klaar is?", "bevestig schoonmaakbeurt", MessageBoxButtons.YesNo);
                if (bevestiginBeurt == DialogResult.Yes)
                {
                    string eindtijd = DateTime.Now.ToString("dd-MM-yyyy HH:mm");
                    DateTime eindDatumTijd = Convert.ToDateTime(eindtijd);
                    int schoonmaaknr = Convert.ToInt32(lvSchoonmaaklijst.SelectedItems[0].SubItems[5].Text);
                    int tramnr = Convert.ToInt32(lvSchoonmaaklijst.SelectedItems[0].SubItems[3].Text);
                    this.schoonmaakcontroller.SchoonmaakbeurtKlaar(schoonmaaknr, Inlog.Persoon.Voornaam, Inlog.Persoon.Achternaam, eindDatumTijd, tramnr);
                    SchoonmaakSysteem schoonmaak = new SchoonmaakSysteem();
                    this.Dispose();
                    schoonmaak.Show();
                }
                else if (bevestiginBeurt == DialogResult.No)
                {
                    return;
                }
            }
            else
            {
                MessageBox.Show("geef aan dat de beurt klaar is");
            }
        }

        private void BtnTerug_Click(object sender, EventArgs e)
        {
            this.Hide();
            Hoofdscherm hoofdscherm = new Hoofdscherm();
            hoofdscherm.ShowDialog();
        }

        private void LvSchoonmaaklijst_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lvSchoonmaaklijst.SelectedIndices.Count < 1)
            { 
                return;
            }

            this.lblTramnr.Text = this.lvSchoonmaaklijst.SelectedItems[0].SubItems[3].Text;
            this.lblSoortBeurt.Text = this.lvSchoonmaaklijst.SelectedItems[0].SubItems[0].Text;
            if (this.lvSchoonmaaklijst.SelectedItems[0].SubItems[2].Text != "Nog te doen")
            {
                this.cbKlaar.Checked = true;
                this.cbKlaar.Enabled = false;
                this.btnOk.Enabled = false;
                this.btnOngedaanMaken.Enabled = true;
                this.lblSchoonmakerNaam.Text = lvSchoonmaaklijst.SelectedItems[0].SubItems[4].Text;
            }
            else
            {
                this.cbKlaar.Checked = false;
                this.cbKlaar.Enabled = true;
                this.btnOk.Enabled = false;
                this.btnOngedaanMaken.Enabled = true;
                this.lblSchoonmakerNaam.Text = Inlog.Persoon.Voornaam;
            }
        }

        private void BtnOngedaanMaken_Click(object sender, EventArgs e)
        {
            this.lblSoortBeurt.Text = "-";
            this.lblTramnr.Text = "-";
            this.cbKlaar.Checked = false;
            this.cbKlaar.Enabled = false;
            this.btnOk.Enabled = false;
            this.btnOngedaanMaken.Enabled = false;
            this.lblSchoonmakerNaam.Text = "-";
            this.lvSchoonmaaklijst.SelectedIndices.Clear();
        }

        private void CbKlaar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbKlaar.Checked)
            {
                this.btnOk.Enabled = true;
            }
            else
            {
                this.btnOk.Enabled = false;
            }
        }

        private void SchoonmaakSysteem_Load(object sender, EventArgs e)
        {
            this.lvSchoonmaaklijst.Items.Clear();
            string dag = dtpBeginDatum.Value.ToString("dd-MM-yyyy");
            List<Schoonmaak> schoonmaaklijst = new List<Schoonmaak>(this.schoonmaakcontroller.HaalLijstVanDagOp(Convert.ToDateTime(dag)));
            foreach (Schoonmaak s in this.schoonmaakcontroller.SchoonmaakLijst)
            {
                ListViewItem hoofditem;
                ListViewItem.ListViewSubItem subitem;

                hoofditem = new ListViewItem();

                if (s.GroteBeurt == true)
                {
                    hoofditem.Text = "Groot";
                }
                else if (s.GroteBeurt == false)
                {
                    hoofditem.Text = "Klein";
                }

                subitem = new ListViewItem.ListViewSubItem();
                subitem.Text = s.BeginDatum.ToString("dd-MM-yyyy");
                hoofditem.SubItems.Add(subitem);

                if (Convert.ToString(s.Eindtijd) == "1-1-0001 00:00:00")
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = "Nog te doen";
                    hoofditem.SubItems.Add(subitem);
                }
                else
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = s.Eindtijd.ToString();
                    hoofditem.SubItems.Add(subitem);
                }

                subitem = new ListViewItem.ListViewSubItem();
                subitem.Text = s.Tramnr.ToString();
                hoofditem.SubItems.Add(subitem);

                if (s.Voornaam == "-")
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = "-";
                    hoofditem.SubItems.Add(subitem);
                }
                else
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = s.Voornaam.ToString();
                    hoofditem.SubItems.Add(subitem);
                }

                subitem = new ListViewItem.ListViewSubItem();
                subitem.Text = s.Schoonmaaknr.ToString();
                hoofditem.SubItems.Add(subitem);

                this.lvSchoonmaaklijst.Items.Add(hoofditem);
            }
        }

        private void dtpBeginDatum_ValueChanged(object sender, EventArgs e)
        {
            SchoonmaakSysteem_Load(this, null);
            BtnOngedaanMaken_Click(this, null);
        }
    }
}
