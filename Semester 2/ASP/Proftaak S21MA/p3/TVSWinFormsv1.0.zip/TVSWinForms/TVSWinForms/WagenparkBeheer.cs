﻿//-----------------------------------------------------------------------
// <copyright file="WagenparkBeheer.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace TVSWinForms
{
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
    using System.Threading;
    using Objecten;

    public partial class WagenparkBeheer : Form
    {
        private WagenparkbeheerController wagenparkbeheerController;
        string LocatieTextbox;
        List<int> trams;
        public WagenparkBeheer()
        {
            InitializeComponent();
            wagenparkbeheerController = new WagenparkbeheerController();
            wagenparkbeheerController.VoegSporenToeAanLijst();
            OpstartWagenpark();
        }

        private void btnInvoerTramnummer_Click(object sender, EventArgs e)
        {
            TramInvoeren tramInvoer = new TramInvoeren();
            tramInvoer.ShowDialog();


            string locatieString = wagenparkbeheerController.GetTextboxNaam(tramInvoer.tram);
            ZetTramInTextBox(locatieString, tramInvoer.tram);

            tramInvoer.Hide();
        }

        public void OpstartWagenpark()
        {
            List<Tram> TramsScherm = wagenparkbeheerController.SchermVullen();
            foreach (Tram t in TramsScherm)
            {
                string locatieString = wagenparkbeheerController.GetTextboxNaam(t);
                ZetTramInTextBox(locatieString, t);
            }
            RefreshWagenpark();
        }

        public void RefreshWagenpark()
        {
            this.Refresh();

            //WagenparkBeheer wagenparkBeheer = new WagenparkBeheer();
            //wagenparkBeheer.ShowDialog();

            List<Tram> TramsScherm = wagenparkbeheerController.SchermVullen();
            foreach (Tram t in TramsScherm)
            {
                string locatieString = wagenparkbeheerController.GetTextboxNaam(t);
                ZetTramInTextBox(locatieString, t);
            }

            List<Sector> sectoren = wagenparkbeheerController.HaalAlleGeblokkeerdeSectorenOp();

            foreach (Sector sec in sectoren)
            {
                string tbNaam = "tb" + sec.Spoor.SpoorNr.ToString() + "c" + sec.SectorNr.ToString();

                foreach(Control control in Controls)
                {
                    if(tbNaam == control.Name)
                    {
                        control.BackColor = Color.Gray;
                    }
                }
            }
        }

        public void ZetTramInTextBox(string locatieString, Tram tram)
        {
            // ik doorzoek alle controls, oa txtboxen en kijk of de naam daarvan gelijk is met de locatieString
            // als dit zo is word de text van het control het tramnummer van de desbetreffende tram.
            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                if (control.Name == locatieString)
                {
                    control.Text = Convert.ToString(tram.TramNr);
                        Refresh();
                }
            }
        }
        }

        /// <summary>
        /// Maakt de simulatie voor de remise
        /// </summary>
        public void Simulatie()
        {
            //Nieuw random 
            Random random = new Random();
            //Telt aantal trams in het array
            int count = trams.Count();

            //Nieuwe instantie van random
            int randomTram = random.Next(0, count);
            //Haalt random tram op
            int nummer = trams[randomTram];
            //Maakt nieuwe tram aan
            Tram tram = new Tram(nummer);
            bool tramToegevoegd;
            bool checkOfOpSpoorMag;
            //bool textboxToegevoegd;

            //Haalt random spoor op en zet deze in een string
            string spoor = Convert.ToString(wagenparkbeheerController.HaalRandomSpoorOp());
            //
            checkOfOpSpoorMag = wagenparkbeheerController.CheckOfTramOpSpoorMag(tram.TramNr, spoor);

            if(checkOfOpSpoorMag)
            {
                for (int i = 1; i <= 9; i++)
                {
                    //Doorloopt alle controls in het form
                    foreach (Control c in this.Controls)
                    {
                        if (c is TextBox)
                        {
                            if (c.Enabled)
                            {
                                if (spoor != "74" && spoor != "75" && spoor != "76" && spoor != "77" && spoor != "12" && spoor != "13" && spoor != "14" && spoor != "15" && spoor != "16" && spoor != "17" && spoor != "18" && spoor != "19" && spoor != "20" && spoor != "21")
                                {
                                    //Kijkt of de naam van control gelijk is aan ingegeven waarden en of text leeg is
                                    if (c.Name == "tb" + spoor + "c" + Convert.ToString(i) && string.IsNullOrWhiteSpace(c.Text))
                                    {
                                        //c.Name = "tb" + spoor + "c" + Convert.ToString(1);
                                        //Geeft boolean terug of textbox toegevoegd is of niet
                                        //textboxToegevoegd = wagenparkbeheerController.VoegTextboxToeAanGeweestLijst(c.Name);

                                        //Kijkt of tram is toegevoegd
                                        tramToegevoegd = wagenparkbeheerController.VoegTramsToeAanGeweestLijst(tram);
                                        //Voeg tram toe in textbox
                                        if (tramToegevoegd)
                                        {
                                            c.Text = Convert.ToString(tram.TramNr);
                                            wagenparkbeheerController.VerwijderTextboxUitLijst(c.Name);
                                            trams.Remove(tram.TramNr);
                                            lblTest.Text = Convert.ToString(wagenparkbeheerController.TramsOpRemise.Count());
                                            i = 10;
                                            
                                            break;
                                        }

                                    }
                                }
                            }
                        }
                    }
                    this.Refresh();
                }
            }
        }
            

        private void btnSimulatie_Click(object sender, EventArgs e)
        {
            //Lijst TramsOpRemise leegmaken
            wagenparkbeheerController.TramsOpRemise.Clear();
            //Haal textboxen van sporen leeg
            this.MaakAlleSpoorTextboxenLeeg();
            //Zet alle textbox sectors in een lijst
            this.VoegAlleTextboxenToeAanLijst();
            //Array met trams ophalen en in nieuw array zetten
            trams = wagenparkbeheerController.AlleTrams();
            timerSimulatie.Start();
            //this.Simulatie();
        }

        public void btnTerug_Click(object sender, EventArgs e)
        {
            this.Hide();
            Hoofdscherm hoofdscherm = new Hoofdscherm();
            hoofdscherm.ShowDialog();
        }

        

        //public string GeefSectorNummer(string spoor)
        //{
        //    int nummer = 1;
        //    string textbox;
        //    foreach(Control c in this.Controls)
        //    {
        //        bool continueWhile = true;
        //        while(nummer <= 8 && continueWhile)
        //        {
        //            if (c.Name == "tb" + spoor + "c" + Convert.ToString(nummer) && c.Text != null)
        //            {
        //                textbox = Convert.ToString(c.Name);
        //                return textbox;
        //                continueWhile = false;
        //            }
        //            else
        //            {
        //                nummer++;
        //            }
        //        }
        //        return textbox = "";
        //    }
        //}

        private void tb38c1_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {

            }
        }

        private void tb38c1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb38c1_ContextMenuStripChanged(object sender, EventArgs e)
        {

        }

        private void tb_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                TextBox tb = (TextBox)sender;
                LocatieTextbox = tb.Name;
                cmsTbTram.Show(Cursor.Position.X, Cursor.Position.Y);
                if(tb.Text == "")
                {
                    tsmiSchoonmaak.Visible = false;
                    tsmiDefect.Visible = false;
                    tsmiVerwijder.Visible = false;
                }
                else
                {
                    tsmiSchoonmaak.Visible = true;
                    tsmiDefect.Visible = true;
                    tsmiVerwijder.Visible = true;
                }
            }
        }

        private void tsmiVerwijder_Click(object sender, EventArgs e)
        {
            int tramNr = 0;
            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                    if (control.Name == LocatieTextbox)
                    {
                        if (control.Text != "")
                        {
                            string tramNrString = control.Text;
                            tramNr = Convert.ToInt32(tramNrString);
                            Tram VerwijderdeTram = new Tram(tramNr);
                            wagenparkbeheerController.VeranderStatusRemise(VerwijderdeTram);

                            RefreshWagenpark();
                        }
                        MessageBox.Show("Geen tram aanwezig");
                    }
                }
            }
        }

        private void tsmiSchoonmaak_Click(object sender, EventArgs e)
        {
            int tramNr = 0;
            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                    if (control.Name == LocatieTextbox)
                    {
                        if (control.Text != "")
                        {
                            string tramNrString = control.Text;
                            tramNr = Convert.ToInt32(tramNrString);
                            Tram VerwijderdeTram = new Tram(tramNr);
                            wagenparkbeheerController.VeranderStatusSchoonmaak(VerwijderdeTram);

                            RefreshWagenpark();
                        }
                        MessageBox.Show("Geen tram aanwezig");
                    }
                }
            }
        }

        private void tsmiVeranderStatus_Click(object sender, EventArgs e)
        {

        }

        private void tsmiDefect_Click(object sender, EventArgs e)
        {
            int tramNr = 0;
            foreach (Control control in this.Controls)
            {
                if (control is TextBox)
                {
                    if (control.Name == LocatieTextbox)
                    {
                        if (control.Text != "")
                        {
                            string tramNrString = control.Text;
                            tramNr = Convert.ToInt32(tramNrString);
                            Tram VerwijderdeTram = new Tram(tramNr);
                            wagenparkbeheerController.VeranderStatusDefect(VerwijderdeTram);

                            //RefreshWagenpark();
                        }
                        MessageBox.Show("Geen tram aanwezig");
                    }
                }
            }

        }

        private void WagenparkBeheer_Load(object sender, EventArgs e)
        {

        }

        private void timerSimulatie_Tick(object sender, EventArgs e)
        {
            this.Simulatie();
        }

        /// <summary>
        /// Voegt alle textboxen waarin trams kunnen staan toe aan een lijst
        /// </summary>
        public void VoegAlleTextboxenToeAanLijst()
        {
            foreach(Control c in this.Controls)
            {
                if(c.Enabled)
                {
                    if(c.Name.Contains("c"))
                    {
                        wagenparkbeheerController.VoegTextboxToeAanLijst(c.Name);
                    }
                }
            }
        }

        /// <summary>
        /// Maakt alle textboxen waarin trams kunnen staan in het form leeg
        /// </summary>
        public void MaakAlleSpoorTextboxenLeeg()
        {
            foreach(Control c in this.Controls)
            {
                if(c is TextBox)
                {
                    if(c.Enabled)
                    {
                        if(c.Name.Contains("c"))
                        {
                            c.Text = "";
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.timerSimulatie.Stop();
        }

        private void tsmiBlokkeerSector_Click(object sender, EventArgs e)
        {
            string spoornr = LocatieTextbox.Substring(2,LocatieTextbox.IndexOf('c')-2);
            string sectornr = LocatieTextbox.Substring(LocatieTextbox.IndexOf('c')+1);
            wagenparkbeheerController.ZetSectorOpGeblokkeerd(spoornr,sectornr);
            RefreshWagenpark();
             

            // Zet statusSectorNr op 2
            // Methode aanroepen die alle sporen die de status geblokkeerd hebben grijs maakt.
        }
    }
}
