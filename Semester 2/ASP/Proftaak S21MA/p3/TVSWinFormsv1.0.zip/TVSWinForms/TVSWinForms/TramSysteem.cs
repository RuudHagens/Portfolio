﻿//-----------------------------------------------------------------------
// <copyright file="TramSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using System.Threading;
    using Objecten;

    public partial class TramSysteem : Form
    {
        private BestuurderController bestuurderController = new BestuurderController();
        private Rfid rfid = new Rfid();

        //Constructor voor als het systeem tijdens het programmeren op zichzelf wordt opgestart.
        public TramSysteem()
        {
            this.InitializeComponent();
        }

        //Constructor voor als het systeem vanuit het hoofdscherm wordt opgestart.
        public TramSysteem(Persoon persoon)
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Deze methode zorgt er voor dat, als er op een genummerde knop wordt gedrukt, het nummer in de tramnummertextbox wordt toegevoegt.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Btn_Click(object sender, EventArgs e)
        {
            int knopNummer;
            string knopText;

            knopText = ((Button)sender).Text;
            knopNummer = Convert.ToInt32(knopText);

            if (this.tbTramNummer.Text.Count() < 4)
                this.tbTramNummer.AppendText(knopNummer.ToString());
        }

        /// <summary>
        /// Deze methode zorgt er voor dat er een cijfer bij het tramnummer wordt weg gehaalt.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnC_Click(object sender, EventArgs e)
        {
            if (this.btnV.Enabled == false)
            {
                this.tbSpoorNummer.Text = null;
                this.btnV.Enabled = true;
            }

            if (this.tbTramNummer.Text.Count() > 0)
                this.tbTramNummer.Text = this.tbTramNummer.Text.Remove(this.tbTramNummer.Text.Count() - 1);
        }

        /// <summary>
        /// Deze methode zorgt ervoor dat er een spoornummer wordt aangevraagt.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnV_Click(object sender, EventArgs e)
        {
            string tramNummer;
            string spoornummer;
            bool onderhoud;
            bool schoonmaak;

            if (this.tbTramNummer.Text.Count() > 0)
            {
                this.btnV.Enabled = false;
                this.btnC.Enabled = false;

                onderhoud = this.cbOnderhoudNodig.Checked;
                schoonmaak = this.cbSchoonmaakNodig.Checked;
                tramNummer = this.tbTramNummer.Text;

                spoornummer = this.bestuurderController.WagenInvoeren(Convert.ToInt32(tramNummer), onderhoud, schoonmaak);

                this.tbSpoorNummer.Text = spoornummer.ToString();
            }
        }

       
        
        //Timer tick voor de rfid scanner zodat deze elke ... kijkt of er een rfid wordt gescanned.
        private void tmRfidScan_Tick(object sender, EventArgs e)
        { 
            //Check of er een rfid chip in bereik is.
            if (this.rfid.InReach)
            {
                string rfidNummer = this.rfid.ChipValue;
                this.tbStatus.Text = "RFID" + rfidNummer + "is gescanned.";

                //de rfid disposen zodat deze op de goede manier afgesloten wordt, mocht dit niet gebeuren dan zal de rfid scanner de volgende keer niet goed werken.
                this.rfid.Dispose();
                this.tmRfidScan.Stop();
            }
        }

        private void btnTerug_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //Hoofdscherm hoofdscherm = new Hoofdscherm();
            //hoofdscherm.ShowDialog();
        }
    }
}