﻿//-----------------------------------------------------------------------
// <copyright file="Hoofdscherm.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace TVSWinForms
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Objecten;

    public partial class Hoofdscherm : Form
    {
        public Hoofdscherm()
        {
            this.InitializeComponent();
            this.CheckToegang();
        }

        public void CheckToegang()
        {
            
            if(Inlog.Persoon.Status == PersoonStatus.Beheerder)
            {
                this.btnWagenparkBeheer.Enabled = true;
                this.btnOnderhoud.Enabled = true;
                this.btnSchoonmaak.Enabled = true;
                this.btnTramSysteem.Enabled = true;
            }

            if(Inlog.Persoon.Status == PersoonStatus.WagenparkBeheerder)
            {
                this.btnWagenparkBeheer.Enabled = true;
            }

            if(Inlog.Persoon.Status == PersoonStatus.Bestuurder)
            {
                this.btnTramSysteem.Enabled = true; 
            }

            if(Inlog.Persoon.Status == PersoonStatus.Schoonmaker)
            {
                this.btnSchoonmaak.Enabled = true;
            }

            if(Inlog.Persoon.Status == PersoonStatus.Technicus)
            {
                this.btnOnderhoud.Enabled = true;
            }
        }

        private void BtnWagenparkBeheer_Click(object sender, EventArgs e)
        {
            this.Hide();
            WagenparkBeheer wagenparkBeheer = new WagenparkBeheer();
            wagenparkBeheer.ShowDialog();
        }

        private void BtnTramSysteem_Click(object sender, EventArgs e)
        {
            this.Hide();
            TramSysteem tramSysteem = new TramSysteem();
            tramSysteem.ShowDialog();
        }

        private void BtnSchoonmaak_Click(object sender, EventArgs e)
        {
            this.Hide();
            SchoonmaakSysteem schoonmaakSysteem = new SchoonmaakSysteem();
            schoonmaakSysteem.ShowDialog();
        }

        private void BtnOnderhoud_Click(object sender, EventArgs e)
        {
            this.Hide();
            OnderhoudSysteem onderhoud = new OnderhoudSysteem();
            onderhoud.ShowDialog();
        }

        private void BtnPlattegrond_Click(object sender, EventArgs e)
        {
            this.Hide();
            Plattegrond plattegrond = new Plattegrond();
            plattegrond.ShowDialog();
        }
    }
}
