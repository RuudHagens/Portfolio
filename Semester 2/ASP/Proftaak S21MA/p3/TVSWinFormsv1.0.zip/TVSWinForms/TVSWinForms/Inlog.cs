﻿//-----------------------------------------------------------------------
// <copyright file="Inlog.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace TVSWinForms
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Objecten;

    public partial class Inlog : Form
    {
        private static Persoon persoon;
        private HoofdController hoofdcontroller;
        public Inlog()
        {
            this.InitializeComponent();
            this.hoofdcontroller = new HoofdController();
        }

        public static Persoon Persoon
        {
            get { return persoon; }
            set { persoon = value; }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                persoon = this.hoofdcontroller.Login(this.tbGebruikersnaam.Text, this.tbWachtwoord.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
                        
            if (persoon != null)
            {
                this.Hide();
                Hoofdscherm hoofdscherm = new Hoofdscherm();
                hoofdscherm.ShowDialog();
            }
        }
    }
}
