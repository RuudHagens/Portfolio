﻿//-----------------------------------------------------------------------
// <copyright file="Onderhoud.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace TVSWinForms
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Objecten;

    public partial class OnderhoudSysteem : Form
    {
        private TechnicusController technicuscontroller = new TechnicusController();

        public OnderhoudSysteem()
        {
            this.InitializeComponent();
        }

        private void BtnTerug_Click(object sender, EventArgs e)
        {
            this.Hide();
            Hoofdscherm hoofdscherm = new Hoofdscherm();
            hoofdscherm.ShowDialog();
        }

        private void Onderhoud_Load(object sender, EventArgs e)
        {
            this.lvOnderhoudslijstlijst.Items.Clear();
            string vandaag = dtpBeginDatum.Value.ToString("dd-MM-yyyy");
            List<Onderhoud> onderhoudlijst = new List<Onderhoud>(this.technicuscontroller.HaalLijstVandaagOp(Convert.ToDateTime(vandaag)));
            foreach (Onderhoud o in onderhoudlijst)
            {
                ListViewItem hoofditem;
                ListViewItem.ListViewSubItem subitem;

                hoofditem = new ListViewItem();

                if (o.GroteBeurt == true)
                {
                    hoofditem.Text = "Groot";
                }
                else if (o.GroteBeurt == false)
                {
                    hoofditem.Text = "Klein";
                }

                subitem = new ListViewItem.ListViewSubItem();
                subitem.Text = o.Begindatumtijd.ToString("dd-MM-yyyy");
                hoofditem.SubItems.Add(subitem);

                if (Convert.ToString(o.DatumtijdsIndicatie) == "1-1-0001 00:00:00")
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = "Niet aangegeven";
                    hoofditem.SubItems.Add(subitem);
                }
                else
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = o.DatumtijdsIndicatie.ToString();
                    hoofditem.SubItems.Add(subitem);
                }

                if (Convert.ToString(o.Einddatumtijd) == "1-1-0001 00:00:00")
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = "Nog te doen";
                    hoofditem.SubItems.Add(subitem);
                }
                else
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = o.Einddatumtijd.ToString();
                    hoofditem.SubItems.Add(subitem);
                }

                subitem = new ListViewItem.ListViewSubItem();
                subitem.Text = o.Tramnr.ToString();
                hoofditem.SubItems.Add(subitem);

                if (o.Voornaam == "-")
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = "-";
                    hoofditem.SubItems.Add(subitem);
                }
                else
                {
                    subitem = new ListViewItem.ListViewSubItem();
                    subitem.Text = o.Voornaam.ToString();
                    hoofditem.SubItems.Add(subitem);
                }

                subitem = new ListViewItem.ListViewSubItem();
                subitem.Text = o.Onderhoudsnr.ToString();
                hoofditem.SubItems.Add(subitem);

                this.lvOnderhoudslijstlijst.Items.Add(hoofditem);
            }
        }

        private void btnBevestigen_Click(object sender, EventArgs e)
        {
            if (this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[2].Text != "Niet aangegeven")
            {
                if (this.cbKlaar.Checked)
                {
                    DialogResult bevestigingBeurt = MessageBox.Show("weet je zeker dat de onderhoudsbeurt klaar is?", "bevestig onderhoudsbeurtbeurt", MessageBoxButtons.YesNo);
                    if (bevestigingBeurt == DialogResult.Yes)
                    {
                        string eindtijd = DateTime.Now.ToString("dd-MM-yyyy HH:mm");
                        DateTime eindDatumTijd = Convert.ToDateTime(eindtijd);
                        int onderhoudsnr = Convert.ToInt32(this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[6].Text);
                        int tramnr = Convert.ToInt32(this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[4].Text);
                        this.technicuscontroller.OnderhoudsbeurtKlaar(onderhoudsnr, Inlog.Persoon.Voornaam, Inlog.Persoon.Achternaam, eindDatumTijd, tramnr);
                        OnderhoudSysteem onderhoud = new OnderhoudSysteem();
                        this.Dispose();
                        onderhoud.Show();
                    }
                    else if (bevestigingBeurt == DialogResult.No)
                    {
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("geef aan dat de beurt klaar is");
                }
            }
            else
            {
                MessageBox.Show("Geef eerst een tijdindicatie op voordat je de beurt bevestigd", "geen tijd indicatie");
            }
        }

        private void btnOngedaanMaken_Click(object sender, EventArgs e)
        {
            this.lblOnderhoudSoort.Text = "-";
            this.lblTramnr.Text = "-";
            this.cbKlaar.Checked = false;
            this.cbKlaar.Enabled = false;
            this.btnBevestigen.Enabled = false;
            this.btnOngedaanMaken.Enabled = false;
            this.lblTechnicusNaam.Text = "-";
            this.lvOnderhoudslijstlijst.SelectedIndices.Clear();
            this.dtpTijdsindicatie.Enabled = false;
            this.dtpTijdsindicatie.Value = DateTime.Now;
            this.btnTijdindicatie.Enabled = false;
        }

        private void cbKlaar_CheckedChanged(object sender, EventArgs e)
        {
            if (cbKlaar.Checked)
            {
                this.btnBevestigen.Enabled = true;
            }
            else
            {
                this.btnBevestigen.Enabled = false;
            }
        }

        private void lvOnderhoudslijstlijst_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.lvOnderhoudslijstlijst.SelectedIndices.Count < 1)
            {
                return;
            }

            this.lblTramnr.Text = this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[4].Text;
            this.lblOnderhoudSoort.Text = this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[0].Text;
            if (this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[2].Text == "Niet aangegeven")
            {
                this.dtpTijdsindicatie.Value = DateTime.Now;
                this.dtpTijdsindicatie.Enabled = true;
                this.btnTijdindicatie.Enabled = true;
                this.cbKlaar.Enabled = false;
            }
            else
            {
                this.dtpTijdsindicatie.Enabled = false;
                this.dtpTijdsindicatie.Text = this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[2].Text;
                this.btnTijdindicatie.Enabled = false;
                this.cbKlaar.Enabled = true;
            }
            if (this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[3].Text != "Nog te doen")
            {
                this.cbKlaar.Checked = true;
                this.cbKlaar.Enabled = false;
                this.btnBevestigen.Enabled = false;
                this.btnOngedaanMaken.Enabled = true;
                this.lblTechnicusNaam.Text = this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[5].Text;
            }
            else
            {
                this.cbKlaar.Checked = false;
                this.cbKlaar.Enabled = true;
                this.btnBevestigen.Enabled = false;
                this.btnOngedaanMaken.Enabled = true;
                this.lblTechnicusNaam.Text = Inlog.Persoon.Voornaam;
            }
        }

        private void btnTijdindicatie_Click(object sender, EventArgs e)
        {
            DialogResult bevestigingTijdindicatie= MessageBox.Show("weet je zeker dat " + dtpTijdsindicatie.Text + " de juiste tijdindicatie is?", "bevestig tijdindicatie", MessageBoxButtons.YesNo);
            if (bevestigingTijdindicatie == DialogResult.Yes)
            {
                int onderhoudsnr = Convert.ToInt32(this.lvOnderhoudslijstlijst.SelectedItems[0].SubItems[6].Text);
                string tijdindicatie = this.dtpTijdsindicatie.Value.ToString("dd-MM-yyyy HH:mm");
                DateTime datumtijdindicatie = Convert.ToDateTime(tijdindicatie);
                this.technicuscontroller.GeefTijdindicatieOp(datumtijdindicatie, onderhoudsnr);
                OnderhoudSysteem onderhoud = new OnderhoudSysteem();
                this.Dispose();
                onderhoud.Show();
            }
            else if (bevestigingTijdindicatie == DialogResult.No)
            {
                return;
            }
        }

        private void dtpBeginDatum_ValueChanged(object sender, EventArgs e)
        {
            Onderhoud_Load(this, null);
            btnOngedaanMaken_Click(this, null);
        }
    }
}
