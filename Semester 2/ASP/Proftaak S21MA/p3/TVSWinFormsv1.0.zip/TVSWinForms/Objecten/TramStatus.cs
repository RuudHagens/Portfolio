﻿//-----------------------------------------------------------------------
// <copyright file="TramStatus.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public enum TramStatus
    {
        Defect,
        Schoonmaak,
        Dienst,
        Remise
    }
}
