﻿//-----------------------------------------------------------------------
// <copyright file="Dienst.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Dienst
    {
        private DateTime uitrijtijd;
        private DateTime inrijtijd;
        private Lijn lijn;

        public Dienst(DateTime uitrijtijd, DateTime inrijtijd)
        {
            this.uitrijtijd = uitrijtijd;
            this.inrijtijd = inrijtijd;
        }

        public DateTime Uitrijtijd
        {
            get { return this.uitrijtijd; }
            set { this.uitrijtijd = value; }
        }

        public DateTime Inrijtijd
        {
            get { return this.inrijtijd; }
            set { this.inrijtijd = value; }
        }

        public Lijn Lijn
        {
            get { return this.lijn; }
            set { this.lijn = value; }
        }
    }
}
