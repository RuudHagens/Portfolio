﻿//-----------------------------------------------------------------------
// <copyright file="Schoonmaak.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Schoonmaak
    {
        private int schoonmaaknr;
        private bool groteBeurt;
        private DateTime beginDatum;
        private DateTime eindTijd;
        private Tram tram;
        private Persoon persoon;
        private string voornaam;
        private int tramnr;

        public Schoonmaak(int schoonmaaknr, bool groteBeurt, DateTime beginDatum, DateTime eindTijd, Tram tram, Persoon persoon)
        {
            this.schoonmaaknr = schoonmaaknr;
            this.groteBeurt = groteBeurt;
            this.beginDatum = beginDatum;
            this.eindTijd = eindTijd;
            this.tram = tram;
            this.persoon = persoon;
        }

        public Schoonmaak(int schoonmaaknr, string voornaam, bool groteBeurt, DateTime beginDatum, DateTime eindTijd, int tramnr)
        {
            this.schoonmaaknr = schoonmaaknr;
            this.voornaam = voornaam;
            this.groteBeurt = groteBeurt;
            this.beginDatum = beginDatum;
            this.eindTijd = eindTijd;
            this.tramnr = tramnr;
        }

        public int Schoonmaaknr
        {
            get { return this.schoonmaaknr; }
            set { this.schoonmaaknr = value; }
        }

        public string Voornaam 
        {
            get { return this.voornaam;}
            set { this.voornaam = value; }
        }

        public bool GroteBeurt
        {
            get { return this.groteBeurt; }
            set { this.groteBeurt = value; }
        }

        public DateTime BeginDatum
        {
            get { return this.beginDatum; }
            set { this.beginDatum = value; }
        }
        
	    public DateTime Eindtijd
	    {
		    get { return this.eindTijd;}
		    set { this.eindTijd = value;}
	    }

        public Persoon Persoon
        {
            get { return this.persoon; }
            set { this.persoon = value; }
        }

        public Tram Tram
        {
            get { return this.tram; }
            set { this.tram = value; }
        }

        public int Tramnr
        {
            get { return this.tramnr; }
            set { this.tramnr = value; }
        }
    }
}
