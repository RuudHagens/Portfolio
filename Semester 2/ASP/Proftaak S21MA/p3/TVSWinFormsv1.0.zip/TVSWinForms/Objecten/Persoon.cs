﻿//-----------------------------------------------------------------------
// <copyright file="Persoon.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Persoon
    {
        private string voornaam;
        private string achternaam;
        private string adres;
        private DateTime geboortedatum;
        private string gebruikersnaam;
        private PersoonStatus status;

        public Persoon(string voornaam, string achternaam, string adres, DateTime geboortedatum, string gebruikersnaam, PersoonStatus status)
        {
            this.voornaam = voornaam;
            this.achternaam = achternaam;
            this.adres = adres;
            this.geboortedatum = geboortedatum;
            this.gebruikersnaam = gebruikersnaam;
            this.status = status;
        }

        public string Voornaam
        {
            get { return this.voornaam; }
            set { this.voornaam = value; }
        }

        public string Achternaam
        {
            get { return this.achternaam; }
            set { this.achternaam = value; }
        }

        public string Adres
        {
            get { return this.adres; }
            set { this.adres = value; }
        }

        public DateTime Geboortedatum
        {
            get { return this.geboortedatum; }
            set { this.geboortedatum = value; }
        }

        public string Gebruikersnaam
        {
            get { return this.gebruikersnaam; }
            set { this.gebruikersnaam = value; }
        }

        public PersoonStatus Status
        {
            get { return this.status; }
            set { this.status = value; }
        }
    }
}
