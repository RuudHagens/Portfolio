﻿//-----------------------------------------------------------------------
// <copyright file="Spoor.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Spoor
    {
        private SpoorStatus status;
        private int spoorNr;
        private Lijn lijn;

        public Spoor(SpoorStatus status, int spoorNr, Lijn lijn)
        {
            this.status = status;
            this.spoorNr = spoorNr;
            this.lijn = lijn;
        }

        public Spoor(int spoorNr)
        {
            this.spoorNr = spoorNr;
        }

        public SpoorStatus Status
        {
            get { return this.status; }
            set { this.status = value; }
        }

        public int SpoorNr
        {
            get { return this.spoorNr; }
            set { this.spoorNr = value; }
        }

        public Lijn Lijn
        {
            get { return this.lijn; }
            set { this.lijn = value; }
        }
    }
}
