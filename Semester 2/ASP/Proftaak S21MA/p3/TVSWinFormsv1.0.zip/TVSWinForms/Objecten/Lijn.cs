﻿//-----------------------------------------------------------------------
// <copyright file="Lijn.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Lijn
    {
        private string lijnNr;
        
        public Lijn(string lijnNr)
        {
            this.lijnNr = lijnNr;
        }

        public string LijnNr
        {
            get { return this.lijnNr; }
            set { this.lijnNr = value; }
        }
    }
}
