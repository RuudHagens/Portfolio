﻿//-----------------------------------------------------------------------
// <copyright file="TramType.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public enum TramType
    {
        _Combino,
        _11G,
        _DubbelKopCombino,
        _12G,
        _Opleidingstram
    }
}
