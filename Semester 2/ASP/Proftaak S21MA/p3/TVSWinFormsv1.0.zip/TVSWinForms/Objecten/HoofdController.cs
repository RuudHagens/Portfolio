﻿//-----------------------------------------------------------------------
// <copyright file="HoofdController.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Specialized;
    using Database;

    public class HoofdController
    {
        private TechnicusController technicusController;
        private BestuurderController bestuurderController;
        private SchoonmaakController schoonmaakController;
        private WagenparkbeheerController wagenparkBeheerController;
        private ConnectieHoofdSysteem connectieHoofdSysteem;
        private ConnectieWagenparkBeheerSysteem connectieWagenparkBeheerSysteem;

        public HoofdController()
        {
            this.connectieHoofdSysteem = new ConnectieHoofdSysteem();
            this.connectieWagenparkBeheerSysteem = new ConnectieWagenparkBeheerSysteem();
        }

        public WagenparkbeheerController WagenparkBeheerController
        {
            get { return this.wagenparkBeheerController; }
            set { this.wagenparkBeheerController = value; }
        }

        public SchoonmaakController SchoonmaakController
        {
            get { return this.schoonmaakController; }
            set { this.schoonmaakController = value; }
        }

        public BestuurderController BestuurderController
        {
            get { return this.bestuurderController; }
            set { this.bestuurderController = value; }
        }

        public TechnicusController TechnicusController
        {
            get { return this.technicusController; }
            set { this.technicusController = value; }
        }

        public void Simulatie()
        {

        }

        public void CheckTramSoort(int tramNr)
        {

        }

        public bool CheckOfSpoorBezet(int spoorNr, int sectorNr)
        {
            bool bezet = false;
            return bezet;
        }

        public void ReserveerTram(int tramNr, string soortReservering)
        {

        }

        /// <summary>
        /// Login methode die zorgt dat gebruikers kunnen inloggen
        /// </summary>
        /// <param name="gebruikersnaam">De gebruikersnaam van de gebruiker</param>
        /// <param name="wachtwoord">Het wachtwoord wat bij de gebruikersnaam hoort</param>
        /// <returns>Een string met status van het account als alle gegevens juist zijn</returns>
        public Persoon Login(string gebruikersnaam, string wachtwoord)
        {
            bool inlogGegevens;
            if(string.IsNullOrEmpty(gebruikersnaam)||string.IsNullOrEmpty(wachtwoord))
            {
                throw new Exception("Vul alle velden in!");
            }

            inlogGegevens = this.connectieHoofdSysteem.Login(gebruikersnaam, wachtwoord);

            if (inlogGegevens)
            {
                NameValueCollection persoonsgegevens = this.connectieHoofdSysteem.HaalPersoonsGegevensOp(gebruikersnaam);
                string voornaam = persoonsgegevens["Voornaam"];
                string achternaam = persoonsgegevens["Achternaam"];
                string adres = persoonsgegevens["Adres"];
                DateTime geboortedatum = DateTime.Parse(persoonsgegevens["Geboortedatum"]);
                string naamGebruiker = persoonsgegevens["Gebruikersnaam"];
                string beschrijving = persoonsgegevens["Beschrijving"];

                PersoonStatus status;
                bool gelukt = Enum.TryParse<PersoonStatus>(beschrijving, out status);

                if(gelukt)
                {
                    Persoon persoon = new Persoon(voornaam, achternaam, adres, geboortedatum, naamGebruiker, status);
                    return persoon;
                }
                else
                {
                    throw new Exception("De beschrijving uit de database komt niet overeen met het juiste enum!");
                }
            }
            else
            {
                throw new Exception("Gebruikersnaam of wachtwoord is incorrect!");
            }
        }
    }
}
