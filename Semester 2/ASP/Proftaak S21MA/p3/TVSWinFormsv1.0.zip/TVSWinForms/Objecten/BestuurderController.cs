﻿//-----------------------------------------------------------------------
// <copyright file="BestuurderController.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class BestuurderController
    {
        private ConnectieTramSysteem connectieTramSysteem;
        private ConnectieSchoonmaakSysteem connectieSchoonmaakSysteem;
        private ConnectieOnderhoudSysteem connectieOnderhoudSysteem;

        public BestuurderController()
        {
            this.connectieTramSysteem = new ConnectieTramSysteem();
            this.connectieSchoonmaakSysteem = new ConnectieSchoonmaakSysteem();
            this.connectieOnderhoudSysteem = new ConnectieOnderhoudSysteem();
        }

        /// <summary>
        /// Methode om op basis van een aantal checks, achter het spoor te komen waar de tram naartoe moet. Tevens zorgt deze ervoor dat er een onderhoud of schoonmaak aangemaakt wordt als dit aangegeven is.
        /// </summary>
        /// <param name="tramNr"></param>
        /// <param name="onderhoud">Of de tram onderhoud nodig heeft.</param>
        /// <param name="schoonmaak">Of de tram schoonmaak nodig heeft.</param>
        /// <returns>Spoornummer waar de tram naartoe kan.</returns>
        public string WagenInvoeren(int tramNr, bool onderhoud, bool schoonmaak)
        {
            string spoorNummer = null;
            string sectorNummer = null;
            
            if(onderhoud)// Geeft een onderhoud spoor terug
            {
                spoorNummer = this.connectieTramSysteem.HaalOnderhoudSpoorOp(out sectorNummer);
                this.connectieTramSysteem.VeranderStatusTramOnderhoud(tramNr);
                int onderhoudsnr = this.connectieOnderhoudSysteem.HaalMaxOnderhoudsOp();
                DateTime LaatsteEinddatumOnderhoud = connectieOnderhoudSysteem.HaalLaatsteOnderhoudsdatumOp(tramNr);
                DateTime OnderhoudVandaag = DateTime.Now;
                int soortOnderhoudbeurtVerschil = DateTime.Compare(OnderhoudVandaag, LaatsteEinddatumOnderhoud);
                string soortonderhoudbeurt = "";
                if (LaatsteEinddatumOnderhoud == DateTime.MinValue)
                {
                    soortonderhoudbeurt = "Groot";
                }
                else if (soortOnderhoudbeurtVerschil > 89)
                {
                    soortonderhoudbeurt = "Groot";
                }
                else if (soortOnderhoudbeurtVerschil < 90)
                {
                    soortonderhoudbeurt = "Klein";
                }
                this.connectieOnderhoudSysteem.MaakOnderhoudsbeurtAan(onderhoudsnr, tramNr, OnderhoudVandaag, soortonderhoudbeurt);

            }
            else if(schoonmaak)// Geeft een schoonmaak spoor terug
            {
                spoorNummer = this.connectieTramSysteem.HaalSchoonmaakSpoorOp(out sectorNummer);
                this.connectieTramSysteem.VeranderStatusTramSchoonmaak(tramNr);
                int schoonmaaknr = this.connectieSchoonmaakSysteem.HaalMaxSchoonmaakNrOp();
                DateTime LaatsteEinddatumSchoonmaak = this.connectieSchoonmaakSysteem.HaalLaatsteSchoonmaakdatumOp(tramNr);
                DateTime SchoonmaakVandaag = DateTime.Now;
                int soortSchoonmaakBeurtverschil = DateTime.Compare(SchoonmaakVandaag, LaatsteEinddatumSchoonmaak);
                string soortschoonmaakbeurt = "";
                if (LaatsteEinddatumSchoonmaak == DateTime.MinValue)
                {
                    soortschoonmaakbeurt = "Groot";
                }
                else if (soortSchoonmaakBeurtverschil > 89)
                {
                    soortschoonmaakbeurt = "Groot";
                }
                else if (soortSchoonmaakBeurtverschil < 90)
                {
                    soortschoonmaakbeurt = "Klein";
                }
                this.connectieSchoonmaakSysteem.MaakSchoonmaakbeurtAan(schoonmaaknr, tramNr, SchoonmaakVandaag, soortschoonmaakbeurt);
            }
            else if (this.connectieTramSysteem.HaalTramType(tramNr).ToUpper() == "11G")// Geeft een 11g spoor terug
            {
                spoorNummer = this.connectieTramSysteem.Haal11GSpoorOp(out sectorNummer);
                this.connectieTramSysteem.VeranderStatusTramRemise(tramNr);
            }
            else if (this.connectieTramSysteem.HaalTramType(tramNr).ToUpper() == "12G")// Geeft een 12g spoor terug
            {
                spoorNummer = this.connectieTramSysteem.Haal12GSpoorOp(out sectorNummer);
                this.connectieTramSysteem.VeranderStatusTramRemise(tramNr);
            }
            else// Geeft een normaal spoor terug
            {
                spoorNummer = this.connectieTramSysteem.HaalSpoorOp(out sectorNummer);
                this.connectieTramSysteem.VeranderStatusTramRemise(tramNr);
            }

            this.connectieTramSysteem.GeefEenTramSector(tramNr, Convert.ToInt32(spoorNummer), Convert.ToInt32(sectorNummer));

            return spoorNummer;
        }
    }
}
