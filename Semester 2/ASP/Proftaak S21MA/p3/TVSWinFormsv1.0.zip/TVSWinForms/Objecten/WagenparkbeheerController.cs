﻿//-----------------------------------------------------------------------
// <copyright file="WagenparkbeheerController.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;
    using System.Collections.Specialized;

    public class WagenparkbeheerController
    {
        private Tram tram;
        private Spoor spoor;
        private ConnectieWagenparkBeheerSysteem connectieWagenparkBeheerSysteem;
        private List<Tram> tramsOpRemise = new List<Tram>();
        private List<int> sporen = new List<int>();
        private List<string> textboxenLijst = new List<string>();

        public WagenparkbeheerController()
        {
            this.connectieWagenparkBeheerSysteem = new ConnectieWagenparkBeheerSysteem();
        }

        public Spoor Spoor
        {
            get { return this.spoor; }
            set { this.spoor = value; }
        }

        public Tram Tram
        {
            get { return this.tram; }
            set { this.tram = value; }
        }
        public List<Tram> TramsOpRemise
        {
            get { return this.tramsOpRemise; }
        }

        public List<string> TextboxenLijst
        {
            get { return this.textboxenLijst; }
        }

        public List<int> Sporen
        {
            get { return this.sporen; }
        }

        public List<Tram> SchermVullen()
        {
            List<Tram> TramsInRemise = new List<Tram>();
            List<int> tramNrs = new List<int>();
            tramNrs = connectieWagenparkBeheerSysteem.HaalTramsNrInRemiseOP();
            if (tramNrs != null)
            {
                foreach (int i in tramNrs)
                {
                    int spoorNr = connectieWagenparkBeheerSysteem.HaalSpoorNrOp(i);
                    int sectorNr = connectieWagenparkBeheerSysteem.HaalSectorNrOp(i);
                    TramStatus tramStatus = TramStatus.Remise;
                    string tramStatusString = Convert.ToString(tramStatus);
                    int tramStatusNr = connectieWagenparkBeheerSysteem.FindTramStatusNr(tramStatusString);
                    TramType tramType = FindType(i);
                    Spoor spoor = new Spoor(spoorNr);
                    Sector sector = new Sector(sectorNr, spoor);
                    Tram bestaandeTram = new Tram(i, tramType, spoor, tramStatus, sector);
                    TramsInRemise.Add(bestaandeTram);
                }
            }
            return TramsInRemise;
        }

        public Tram TramInvoeren(int tramnr, int spoornr, int sectornr)
        {
            Spoor spoor = new Spoor(spoornr);
            Sector sector = new Sector(sectornr, spoor);

            TramType tramType = FindType(tramnr);
            int TramTypeNr = FindTypeNr(tramType);

            bool StatusTramNr = connectieWagenparkBeheerSysteem.IsStatusRemise(tramnr);

            TramStatus tramStatus = TramStatus.Remise;
            string tramStatusString = Convert.ToString(tramStatus);
            int tramStatusNr = connectieWagenparkBeheerSysteem.FindTramStatusNr(tramStatusString);

            //Check of tram op spoor mag staan
            bool tramLijnTrue = CheckOfTramOpLijnMag(tramType, spoor);
            bool tramSpoorTrue = CheckOfTramOpSectorMag(sector);

            int sectorID = connectieWagenparkBeheerSysteem.FindSectorID(spoornr, sectornr);

            
            //Check of sectorNr vrij is.
            //int vrijeSector = connectieWagenparkBeheerSysteem.HaalHoogsteSectorOpDatabase(spoornr);
            //if (vrijeSector == sectornr)
            //{
                if (tramLijnTrue)
                {
                    if (tramSpoorTrue)
                    {
                        if (!StatusTramNr)
                        {
                            Tram ingevoerdeTram = new Tram(tramnr, tramType, spoor, tramStatus, sector);

                            connectieWagenparkBeheerSysteem.UpdateSector(sectorID);
                            connectieWagenparkBeheerSysteem.UpdateTram(tramStatusNr, sectorID, tramnr);

                            return ingevoerdeTram;
                        }
                        else
                        {
                            throw new Exception("Tram staat al op remise");
                        }
                    }
                    else
                    {
                        throw new Exception("Spoor mag niet gevuld worden");
                    }
                //}

                //else
                //{
                //    throw new Exception("Tram staat niet op juiste spoor");
                //}
            }
            else
            {
                throw new Exception("Tram staat niet op juiste sector");
            }
        }

        public string GetTextboxNaam(Tram tram)
        {
            string locatieString = "tb" + Convert.ToString(tram.Spoor.SpoorNr) + "c" + Convert.ToString(tram.Sector.SectorNr);

            return locatieString;
        }

        public Tram TramInvoerenInWagenparkBeheerScherm(int tramnr, int spoornr, int sectornr)
        {
            Spoor spoor;
            Tram tram;
            spoor = new Spoor(spoornr);
            Sector sector = new Sector(sectornr, spoor);
            tram = new Tram(tramnr, spoor, sector);
            return tram;
        }

        public TramType FindType(int tramnr)
        {
            TramType gevondenType = new TramType();

            if (2000 < tramnr && tramnr < 2073)
            {
                gevondenType = TramType._Combino;
            }
            else if (900 < tramnr && tramnr < 921)
            {
                gevondenType = TramType._11G;
            }
            else if (2200 < tramnr && tramnr < 2205)
            {
                gevondenType = TramType._DubbelKopCombino;
            }
            else if (816 < tramnr && tramnr < 842)
            {
                gevondenType = TramType._12G;
            }
            else if (808 < tramnr && tramnr < 817)
            {
                gevondenType = TramType._Opleidingstram;
            }
            else
            {
                throw new Exception("TramNr bestaat niet");
            }

            return gevondenType;
        }

        public int FindTypeNr(TramType tramType)
        {
            int TypeNr;

            if (tramType == TramType._Combino)
            {
                TypeNr = 1;
            }
            else if (tramType == TramType._DubbelKopCombino)
            {
                TypeNr = 2;
            }
            else if (tramType == TramType._11G)
            {
                TypeNr = 3;
            }
            else if (tramType == TramType._12G)
            {
                TypeNr = 4;
            }
            else if (tramType == TramType._Opleidingstram)
            {
                TypeNr = 5;
            }
            else
            {
                throw new Exception("TypeNr niet gevonden");
            }

            return TypeNr;
        }

        public void VeranderStatusRemise(Tram tram)
        {
            int SectorID = connectieWagenparkBeheerSysteem.FindSectorID(tram.TramNr);
            connectieWagenparkBeheerSysteem.VeranderTramStatusRemiseDatabase(tram.TramNr);
            connectieWagenparkBeheerSysteem.UpdateSectorVrij(SectorID);
        }

        public void VeranderStatusSchoonmaak(Tram tram)
        {
            int SectorID = connectieWagenparkBeheerSysteem.FindSectorID(tram.TramNr);
            connectieWagenparkBeheerSysteem.VeranderTramStatusSchoonmaakDatabase(tram.TramNr);
            connectieWagenparkBeheerSysteem.UpdateSectorVrij(SectorID);
        }

        public void VeranderStatusDefect(Tram tram)
        {
            int SectorID = connectieWagenparkBeheerSysteem.FindSectorID(tram.TramNr);
            connectieWagenparkBeheerSysteem.VeranderTramStatusDefectDatabase(tram.TramNr);
            connectieWagenparkBeheerSysteem.UpdateSectorVrij(SectorID);
        }

        public Spoor VeranderStatusSpoor(Spoor spoor)
        {
            Spoor nieuwSpoor;
            nieuwSpoor = spoor;
            return nieuwSpoor;
        }

        public int HaalHoogsteSectorOp(int spoorNr)
        {
            int hoogsteSectorNr;
            hoogsteSectorNr = this.connectieWagenparkBeheerSysteem.HaalHoogsteSectorOpDatabase(spoorNr);
            return hoogsteSectorNr;
        }

        public void ZetSectorsOnderParameterSectorOpGeblokkeerd(int sectorNr)
        {
            this.connectieWagenparkBeheerSysteem.ZetSectorsOnderParameterSectorOpGeblokkeerd(sectorNr);
        }

        /// <summary>
        /// Checkt of de tram op een spoor mag
        /// </summary>
        /// <param name="tram"></param>
        /// <returns></returns>
        public bool CheckOfTramOpSectorMag(Sector sector)
        {
            bool check = true;

            int statusSectorNr = connectieWagenparkBeheerSysteem.HaalStatusSectorOp(sector.Spoor.SpoorNr, sector.SectorNr);

            bool IsSectorVrij = connectieWagenparkBeheerSysteem.IsSectorVrijDatabase();
            if(sector.Spoor.SpoorNr == 40 || sector.Spoor.SpoorNr == 58)
            {
                if (IsSectorVrij)
                {
                    if (statusSectorNr == 2)
                    {
                        check = false;
                    }
                    return check;
                }
                return check;
            }
            else
            {
                if (statusSectorNr == 2)
                {
                    check = false;
                }
                return check;
            }
        }


        public bool CheckOfTramOpLijnMag(TramType tramType, Spoor spoor)
        {
            bool check = true;

            if (tramType == TramType._11G)
            {
                string lijnNrVijf = "5";
                string lijnNr = connectieWagenparkBeheerSysteem.HaalLijnNrOp(spoor.SpoorNr);
                if (lijnNr != lijnNrVijf)
                {
                    check = false;
                }
                return check;
            }
            else
            {
                return check;
            }
        }

        /// <summary>
        /// Haalt de lijst uit connectieWagenparkBeheerSysteem
        /// </summary>
        /// <returns>Een lijst met alle trams</returns>
        public List<int> AlleTrams()
        {
            List<int> trams = connectieWagenparkBeheerSysteem.HaalTramsOp();
            return trams;
        }

        /// <summary>
        /// Voegt een tram toe aan de lijst tramsOpRemise
        /// </summary>
        /// <param name="tram">Instantie van tram</param>
        /// <returns>True als het gelukt is, anders false</returns>
        public bool VoegTramsToeAanGeweestLijst(Tram tram)
        {
            bool nogNietInLijst = true;

            foreach (Tram t in tramsOpRemise)
            {
                if (t.TramNr == tram.TramNr)
                {
                    nogNietInLijst = false;
                }
            }
            if (nogNietInLijst)
            {
                tramsOpRemise.Add(tram);
                return true;
            }
            else
            {
                return false;
            }
        }

        public void VerwijderTram(int tramnr, int spoornr, int sectornr)
        {
            Spoor spoor = new Spoor(spoornr);
            Sector sector = new Sector(sectornr, spoor);
            Tram TramVerwijder = new Tram(tramnr, spoor, sector);

        }

        /// <summary>
        /// Zet de opgehaalde lijst van alle sporen om in de sporenlijst
        /// </summary>
        public void VoegSporenToeAanLijst()
        {
            this.sporen = connectieWagenparkBeheerSysteem.HaalAlleSporenOp();
        }

        /// <summary>
        /// Haalt een random spoor uit de lijst
        /// </summary>
        /// <returns>Een int van het spoornummer</returns>
        public int HaalRandomSpoorOp()
        {
            Random random = new Random();
            int max = sporen.Count();
            int randomSpoor = random.Next(0, max);
            int spoor = sporen[randomSpoor];
            return spoor;
        }

        /// <summary>
        /// Methode die textboxen toevoegt aan de textboxenLijst
        /// </summary>
        /// <param name="textbox">De naam van de textbox</param>
        /// <returns>True als gelukt is, anders false</returns>
        public bool VoegTextboxToeAanLijst(string textbox)
        {
            bool nogNietInLijst = true;

            foreach (string s in textboxenLijst)
            {
                if (s == textbox)
                {
                    nogNietInLijst = false;
                }
            }
            if (nogNietInLijst)
            {
                textboxenLijst.Add(textbox);
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Verwijdert opgegeven textbox uit de lijst, als deze in de lijst staat
        /// </summary>
        /// <param name="textbox">De naam van de textbox</param>
        /// <returns>True als het gelukt is</returns>
        public bool VerwijderTextboxUitLijst(string textbox)
        {
            bool gevonden = false;
            string box = "";

            foreach (string s in textboxenLijst)
            {
                if (s == textbox)
                {
                    box = s;
                    gevonden = true;
                }
            }
            if (gevonden)
            {
                textboxenLijst.Remove(box);
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool VerwijderSpoorUitSporenLijst(int spoor)
        {
            bool uitLijst = false;

            foreach (int i in sporen)
            {
                if (i == spoor)
                {
                    sporen.Remove(spoor);
                    uitLijst = true;
                }
                else
                {
                    return uitLijst;
                }
            }
            return uitLijst;
        }

        /// <summary>
        /// checkt of een tram op een spoor mag staan
        /// </summary>
        /// <param name="tramNr">Het nummer van de tram</param>
        /// <param name="spoor">Het spoor als string</param>
        /// <returns>True als tram op spoor mag</returns>
        public bool CheckOfTramOpSpoorMag(int tramNr, string spoor)
        {
            bool magOpSpoor = true;

            //Kijkt of het opgegeven spoor 37, 43, 56 of 54 is(Lijn 5)
            if (spoor == "37" || spoor == "42" || spoor == "56" || spoor == "54")
            {
                //Kijkt of ingevoerde tramNr tussen de 901 en 920 is (11G)
                if (tramNr >= 901 && tramNr <= 920)
                {
                    return magOpSpoor;
                }
                else
                {
                    return false;
                }
            }
            //Kijkt of het spoor 35, 33, 30 of 57 is (Lijn 16/24)
            else if (spoor == "35" || spoor == "33" || spoor == "30" || spoor == "57")
            {
                //Kijkt of tramNr tussen de 817 en 841 is(12G)
                if (tramNr >= 817 && tramNr <= 841)
                {
                    return magOpSpoor;
                }
                else
                {
                    return false;
                }
            }
            //Kijkt of het spoor 38, 36, 34, 32, 31, 44, 41, 43, 45, 55, 54, 52, 51, 64, 63, 62 of 61 is
            else if (spoor == "38" || spoor == "36" || spoor == "34" || spoor == "32" || spoor == "31" || spoor == "44" || spoor == "41" || spoor == "43" || spoor == "45" || spoor == "55" || spoor == "53" || spoor == "52" || spoor == "51" || spoor == "64" || spoor == "63" || spoor == "62" || spoor == "61")
            {
                //Kijkt of het tramNr tussen de 2001 en 2072 is (Combino's)
                if (tramNr >= 2001 && tramNr <= 2072)
                {
                    return magOpSpoor;
                }
                //Kijkt of tramNr tussen 2201 en 2204 is
                else if (tramNr >= 2201 && tramNr <= 2204)
                {
                    return magOpSpoor;
                }
                //Kijkt of tramNr 809 of 816 is (Opleidingstrams)
                else if (tramNr == 809 && tramNr == 816)
                {
                    return magOpSpoor;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public void ZetSectorOpGeblokkeerd(string spoornr, string sectornr)
        {
            connectieWagenparkBeheerSysteem.ZetSectorOpGeblokkeerd(spoornr, sectornr);
        }

        public List<Sector> HaalAlleGeblokkeerdeSectorenOp()
        {
            List<Sector> sectoren = new List<Sector>();
            List<NameValueCollection> nvcList = new List<NameValueCollection>();
            nvcList = connectieWagenparkBeheerSysteem.HaalAlleGeblokkeerdeSectorenOp();
            if (nvcList != null)
            {
                foreach (NameValueCollection nvc in nvcList)
                {
                    string sectorNr = nvc["SECTORNR"];
                    string spoorNr = nvc["SPOORNR"];

                    int spoorNri = Convert.ToInt32(spoorNr);
                    int sectorNri = Convert.ToInt32(sectorNr);

                    Spoor spoor = new Spoor(spoorNri);
                    Sector sector = new Sector(sectorNri, spoor);

                    sectoren.Add(sector);
                }
            }

            return sectoren;
        }
    }
}
