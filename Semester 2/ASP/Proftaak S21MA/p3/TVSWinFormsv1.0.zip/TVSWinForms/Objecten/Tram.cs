﻿//-----------------------------------------------------------------------
// <copyright file="Tram.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Tram
    {
        private int tramNr;
        private TramType type;
        private string bijzonderheden;
        private Spoor spoor;
        private TramStatus status;
        private Sector sector;

        public Tram(int tramNr, TramType type, string bijzonderheden, Spoor spoor, TramStatus status, Sector sector)
        {
            this.tramNr = tramNr;
            this.type = type;
            this.bijzonderheden = bijzonderheden;
            this.spoor = spoor;
            this.status = status;
            this.sector = sector;
        }

        public Tram(int tramNr, TramType type, Spoor spoor, TramStatus status, Sector sector)
        {
            this.tramNr = tramNr;
            this.type = type;
            this.spoor = spoor;
            this.status = status;
            this.sector = sector;
        }

        public Tram(int tramNr, Spoor spoor, Sector sector)
        {
            this.tramNr = tramNr;
            this.spoor = spoor;
            this.sector = sector;
        }
        public Tram(int tramNr, Spoor spoor)
        {
            this.tramNr = tramNr;
            this.spoor = spoor;
        }

        public Tram(int tramNr)
        {
            this.tramNr = tramNr;
        }

        public int TramNr
        {
            get { return this.tramNr; }
            set { this.tramNr = value; }
        }

        public TramType Type
        {
            get { return this.type; }
            set { this.type = value; }
        }

        public string Bijzonderheden
        {
            get { return this.bijzonderheden; }
            set { this.bijzonderheden = value; }
        }

        public Spoor Spoor
        {
            get { return this.spoor; }
            set { this.spoor = value; }
        }

        public TramStatus Status
        {
            get { return this.status; }
            set { this.status = value; }
        }

        public Sector Sector
        {
            get { return this.sector; }
            set { this.sector = value; }
        }
    }
}
