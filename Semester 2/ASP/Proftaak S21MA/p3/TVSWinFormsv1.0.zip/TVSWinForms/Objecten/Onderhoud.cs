﻿//-----------------------------------------------------------------------
// <copyright file="Onderhoud.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Database;

    public class Onderhoud
    {
        private int onderhoudsnr;
        private bool groteBeurt;
        private DateTime datumtijdsIndicatie;
        private DateTime begindatumtijd;
        private DateTime einddatumtijd;
        private Tram tram;
        private Persoon persoon;
        private string voornaam;
        private int tramnr;

        public Onderhoud(bool groteBeurt, DateTime datumtijdsIndicatie, Tram tram, Persoon persoon)
        {
            this.groteBeurt = groteBeurt;
            this.datumtijdsIndicatie = datumtijdsIndicatie;
            this.tram = tram;
            this.persoon = persoon;
        }

        public Onderhoud(int onderhoudsnr, string voornaam, bool groteBeurt, DateTime begindatumtijd, DateTime einddatumtijd, DateTime datumtijdsIndicatie, int tramnr)
        {
            this.onderhoudsnr = onderhoudsnr;
            this.groteBeurt = groteBeurt;
            this.datumtijdsIndicatie = datumtijdsIndicatie;
            this.voornaam = voornaam;
            this.begindatumtijd = begindatumtijd;
            this.einddatumtijd = einddatumtijd;
            this.tramnr = tramnr;
        }

        public int Onderhoudsnr
        {
            get { return this.onderhoudsnr; }
            set { this.onderhoudsnr = value; }
        }

        public bool GroteBeurt
        {
            get { return this.groteBeurt; }
            set { this.groteBeurt = value; }
        }

        public DateTime DatumtijdsIndicatie
        {
            get { return this.datumtijdsIndicatie; }
            set { this.datumtijdsIndicatie = value; }
        }

        public DateTime Begindatumtijd
        {
            get { return this.begindatumtijd; }
            set { this.begindatumtijd = value; }
        }

        public DateTime Einddatumtijd
        {
            get { return this.einddatumtijd; }
            set { this.einddatumtijd = value; }
        }

        public Persoon Persoon
        {
            get { return this.persoon; }
            set { this.persoon = value; }
        }

        public Tram Tram
        {
            get { return this.tram; }
            set { this.tram = value; }
        }

        public string Voornaam
        {
            get { return this.voornaam; }
            set { this.voornaam = value; }
        }

        public int Tramnr
        {
            get { return this.tramnr; }
            set { this.tramnr = value; }
        }
    }
}
