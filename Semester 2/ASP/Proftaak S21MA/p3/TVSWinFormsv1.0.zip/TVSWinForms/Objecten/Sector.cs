﻿//-----------------------------------------------------------------------
// <copyright file="Sector.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Sector
    {
        private int sectorNr;
        private Spoor spoor;

        public Sector(int sectorNr, Spoor spoor)
        {
            this.sectorNr = sectorNr;
            this.spoor = spoor;
        }

        public int SectorNr
        {
            get { return this.sectorNr; }
            set { this.sectorNr = value; }
        }
        public Spoor Spoor
        {
            get { return this.spoor; }
            set { this.spoor = value; }
        }
    }
}
