﻿//-----------------------------------------------------------------------
// <copyright file="Rfid.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Phidgets;
    using Phidgets.Events;

    /// <summary>
    /// Deze klasse bevat alle code om de RFID scanner aan te kunnen sturen.
    /// </summary>
    public class Rfid
    {
        private RFID rfid;
        private string chipValue;
        private bool inReach = false;

        //Initialisatie van de RFID klasse, hierin worden events gekoppelt aan methodes uit de RFID dll.
        public Rfid()
        {
            this.rfid = new RFID();
            this.rfid.Error += new ErrorEventHandler(this.InternalRfidError);
            this.rfid.Tag += new TagEventHandler(this.InternalRfidRead);
            this.rfid.TagLost += new TagEventHandler(this.InternalRfidLost);
            this.rfid.open();
        }

        public string ChipValue
        {
            get { return this.chipValue; }
        }

        public bool InReach
        {
            get { return this.inReach; }
        }

        //Deze mothode wordt aangeroepen als er een rfid tag in de buurt van de scanner komt.
        private void InternalRfidRead(object sender, TagEventArgs e)
        {
            this.rfid.LED = true;
            this.inReach = true;

            this.chipValue = e.Tag;
        }

        //Deze methode wordt aangeroepen als een rfid tag buiten bereik van de scanner raakt.
        private void InternalRfidLost(object sender, TagEventArgs e)
        {
            this.chipValue = null;

            this.rfid.LED = false;
            this.inReach = false;
        }

        //Deze methode wordt aangeroepen als de RFID dll een error geeft.
        private void InternalRfidError(object sender, ErrorEventArgs e)
        {
            this.Dispose();
            throw new Exception(e.Description);
        }

        //Deze methode wordt aangeroepen om de rfid scanner op een goede manier te ontkoppelen.
        public void Dispose()
        {
            this.rfid.LED = false;

            this.rfid.close();
            this.rfid = null;
        }
    }
}
