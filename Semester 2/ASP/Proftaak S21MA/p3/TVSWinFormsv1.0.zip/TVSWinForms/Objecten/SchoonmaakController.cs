﻿//-----------------------------------------------------------------------
// <copyright file="SchoonmaakController.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Specialized;
    using Database;

    public class SchoonmaakController
    {
        private List<Schoonmaak> schoonmaakLijst;
        private ConnectieSchoonmaakSysteem connectieSchoonmaakSysteem;
        private ConnectieWagenparkBeheerSysteem connectieWagenparkBeheerSysteem;

        public SchoonmaakController()
        {
            this.schoonmaakLijst = new List<Schoonmaak>();
            this.connectieSchoonmaakSysteem = new ConnectieSchoonmaakSysteem();
            this.connectieWagenparkBeheerSysteem = new ConnectieWagenparkBeheerSysteem();
        }

        public List<Schoonmaak> SchoonmaakLijst
        {
            get { return this.schoonmaakLijst; }
        }

        /// <summary>
        /// HaalLijstVanDagOp methode die de schoonmaaklijst uit de database omzet naar een list van het object schoonmaak
        /// </summary>
        /// <param name="datum">De dag waarvan je de schoonmaaklijst opvraagt</param>
        /// <returns>een schoonmaak object lijst met schoonmaakbeurten van de gekozen datum</returns>
        public List<Schoonmaak> HaalLijstVanDagOp(DateTime dag)
        {
            this.schoonmaakLijst.Clear();
            List<NameValueCollection> schoonmaaklijst = this.connectieSchoonmaakSysteem.GeefSchoonmakenOpDag(dag);

            foreach (NameValueCollection n in schoonmaaklijst)
            {
                int schoonmaaknr = Convert.ToInt32(n["Schoonmaaknr"]);
                int tramnr = Convert.ToInt32(n["Tramnr"]);
                DateTime begindatum = DateTime.Parse(n["BeginDatum"]);
                DateTime eindtijd = DateTime.Parse(n["EindDatumTijd"]);
                string soortbeurt = n["Soortbeurt"];

                if (soortbeurt == "Groot")
                {
                    Schoonmaak schoonmaak = new Schoonmaak(schoonmaaknr , this.HaalSchoonmakerOp(schoonmaaknr), true, begindatum, eindtijd, tramnr);
                    this.schoonmaakLijst.Add(schoonmaak);
                }
                else
                {
                    Schoonmaak schoonmaak = new Schoonmaak(schoonmaaknr, this.HaalSchoonmakerOp(schoonmaaknr), false, begindatum, eindtijd, tramnr);
                    this.schoonmaakLijst.Add(schoonmaak);
                }
            }

            return this.schoonmaakLijst;
        }

        public string HaalSchoonmakerOp(int schoonmaaknr)
        {
            NameValueCollection schoonmaker = this.connectieSchoonmaakSysteem.HaalSchoonmakerOp(schoonmaaknr);

            if (schoonmaker == null)
            {
                string niemand = "-";
                return niemand;
            }
            else
            {
                string voornaam = schoonmaker["Voornaam"];
                return voornaam;
            }
        }

        public void SchoonmaakbeurtKlaar(int schoonmaakr, string voornaam, string achternaam, DateTime eindtijd, int tramnr)
        {
            NameValueCollection gebruikerID = this.connectieSchoonmaakSysteem.HaalProfielIdOp(voornaam, achternaam);
            int persoonID = Convert.ToInt32(gebruikerID["PersoonID"]);
            this.connectieSchoonmaakSysteem.SchoonmaakbeurtKlaar(eindtijd, persoonID, schoonmaakr);
            //this.connectieWagenparkBeheerSysteem.UpdateTramStatus(tramnr, 4);
        }

        public void Add(Schoonmaak schoonmaakitem)
        {
            this.schoonmaakLijst.Add(schoonmaakitem);
        }
    }
}
