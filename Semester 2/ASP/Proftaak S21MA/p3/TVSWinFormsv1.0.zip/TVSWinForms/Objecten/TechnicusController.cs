﻿//-----------------------------------------------------------------------
// <copyright file="TechnicusController.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//----------------------------------------------------------------------
namespace Objecten
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Specialized;
    using Database;

    public class TechnicusController
    {
        private List<Onderhoud> onderhoudsLijst;
        private ConnectieOnderhoudSysteem connectieOnderhoudSysteem;

        public TechnicusController()
        {
            this.onderhoudsLijst = new List<Onderhoud>();
            this.connectieOnderhoudSysteem = new ConnectieOnderhoudSysteem();
        }

        public List<Onderhoud> OnderhoudsLijst
        {
            get { return this.onderhoudsLijst; }
        }

        /// <summary>
        /// HaalLijstVanDagOp methode die de schoonmaaklijst uit de database omzet naar een list van het object schoonmaak
        /// </summary>
        /// <param name="datum">De dag waarvan je de schoonmaaklijst opvraagt</param>
        /// <returns>een schoonmaak object lijst met schoonmaakbeurten van de gekozen datum</returns>
        public List<Onderhoud> HaalLijstVandaagOp(DateTime dag)
        {
            this.onderhoudsLijst.Clear();
            List<NameValueCollection> onderhoudslijst = this.connectieOnderhoudSysteem.GeefReparatiesOpDag(dag);

            foreach (NameValueCollection o in onderhoudslijst)
            {
                int onderhoudsnr = Convert.ToInt32(o["OnderhoudsNr"]);
                int tramnr = Convert.ToInt32(o["Tramnr"]);
                DateTime begindatum = DateTime.Parse(o["BeginDatumTijd"]);
                DateTime einddatumtijd = DateTime.Parse(o["EindDatumTijd"]);
                DateTime datumtijdsindicatie = DateTime.Parse(o["DatumTijdsIndicatie"]);
                string soortbeurt = o["Soortbeurt"];

                if (soortbeurt == "Groot")
                {
                    Onderhoud onderhoud = new Onderhoud(onderhoudsnr, this.HaalTechnicusOp(onderhoudsnr), true, begindatum, einddatumtijd, datumtijdsindicatie, tramnr);
                    this.onderhoudsLijst.Add(onderhoud);
                }
                else
                {
                    Onderhoud onderhoud = new Onderhoud(onderhoudsnr, this.HaalTechnicusOp(onderhoudsnr), false, begindatum, einddatumtijd, datumtijdsindicatie, tramnr);
                    this.onderhoudsLijst.Add(onderhoud);
                }
            }

            return this.onderhoudsLijst;
        }

        public string HaalTechnicusOp(int schoonmaaknr)
        {
            NameValueCollection technicus = this.connectieOnderhoudSysteem.HaalTechnicusOp(schoonmaaknr);

            if (technicus == null)
            {
                string niemand = "-";
                return niemand;
            }
            else
            {
                string voornaam = technicus["Voornaam"];
                return voornaam;
            }
        }

        public void OnderhoudsbeurtKlaar(int onderhoudsnr, string voornaam, string achternaam, DateTime eindtijd, int tramnr)
        {
            NameValueCollection gebruikerID = this.connectieOnderhoudSysteem.HaalProfielIdOp(voornaam, achternaam);
            int persoonID = Convert.ToInt32(gebruikerID["PersoonID"]);
            this.connectieOnderhoudSysteem.OnderhoudsbeurtKlaar(eindtijd, persoonID, onderhoudsnr);
            this.connectieOnderhoudSysteem.UpdateTramStatus(4, tramnr);
        }

        public void GeefTijdindicatieOp(DateTime tijdsindicatie, int onderhoudsnr )
        {
            this.connectieOnderhoudSysteem.TijdsindicatieAangeven(tijdsindicatie, onderhoudsnr);
        }
    }
}
