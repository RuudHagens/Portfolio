﻿//-----------------------------------------------------------------------
// <copyright file="ConnectieHoofdSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Database
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Specialized;
    using Oracle.DataAccess.Client;
    using Oracle.DataAccess.Types;

    public class ConnectieHoofdSysteem
    {
        /// <summary>
        /// Login methode die gegevens controleert uit de database
        /// </summary>
        /// <param name="gebruikersnaam">De gebruikersnaam van de gebruiker</param>
        /// <param name="wachtwoord">Het wachtwoord wat bij de gebruikersnaam hoort</param>
        /// <returns>True als wachtwoord en gebruikersnaam overeen komen</returns>
        public bool Login(string gebruikersnaam, string wachtwoord)
        {
            bool check = false;

            string query = "SELECT Gebruikersnaam ";
            query += "FROM Account ";
            query += "WHERE Gebruikersnaam = :gebruikersnaam AND Wachtwoord = :wachtwoord";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":gebruikersnaam", gebruikersnaam));
            parameters.Add(new OracleParameter(":wachtwoord", wachtwoord));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (odr != null)
            {
                if (odr.Read())
                {
                    check = true;
                    return check;
                }
                else
                {
                    return check;
                }
            }
            else 
            { 
                return check; 
            }
        }

        /// <summary>
        /// Haalt de status van een account op
        /// </summary>
        /// <param name="gebruikersnaam">De gebruikersnaam van de gebruiker</param>
        /// <returns>De status van het account</returns>
        public NameValueCollection HaalPersoonsGegevensOp(string gebruikersnaam)
        {
            NameValueCollection persoon;
            string query = "SELECT  p.Voornaam, p.Achternaam, p.Adres, p.Geboortedatum, a.Gebruikersnaam, s.Beschrijving ";
            query += "FROM StatusAccount s, Persoon p, Account a ";
            query += "WHERE s.StatusAccountNR = (SELECT StatusAccountNR FROM account WHERE Gebruikersnaam = :gebruikersnaam) ";
            query += "AND p.PersoonId = (SELECT PersoonId FROM account WHERE Gebruikersnaam = :gebruikersnaam) ";
            query += "AND a.Gebruikersnaam = :gebruikersnaam";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":gebruikersnaam", gebruikersnaam));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            persoon = new NameValueCollection();

            if (odr.Read())
            {
                string voornaam = odr.GetString(0);
                string achternaam = odr.GetString(1);
                string adres = odr.GetString(2);
                DateTime geboortedatum = (DateTime)odr[3];
                string naamGebruiker = odr.GetString(4);
                string beschrijving = odr.GetString(5);
                persoon.Add("Voornaam", voornaam);
                persoon.Add("Achternaam", achternaam);
                persoon.Add("Adres", adres);
                persoon.Add("Geboortedatum", geboortedatum.ToShortDateString());
                persoon.Add("Gebruikersnaam", naamGebruiker);
                persoon.Add("Beschrijving", beschrijving);
                return persoon;
            }
            else
            {
                return null;
            }
        }
    }
}
