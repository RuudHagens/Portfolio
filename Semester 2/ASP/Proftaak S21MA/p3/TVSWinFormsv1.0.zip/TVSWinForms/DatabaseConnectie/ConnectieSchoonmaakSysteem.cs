﻿//-----------------------------------------------------------------------
// <copyright file="ConnectieSchoonmaakSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Database
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Oracle.DataAccess.Client;

    public class ConnectieSchoonmaakSysteem
    {
        /// <summary>
        /// GeefSchoonmakenOpDag methode die de schoonmaaklijst ophaalt van de gekozen datum
        /// </summary>
        /// <param name="datum">De dag waarvan je de schoonmaaklijst opvraagt</param>
        /// <returns>een lijst met schoonmaakbeurten van de gekozen datum</returns>
        public List<NameValueCollection> GeefSchoonmakenOpDag(DateTime datum)
        {
            string query = "SELECT Schoonmaaknr, Tramnr, BeginDatum, EindDatumTijd, Soortbeurt ";
            query += "FROM Schoonmaak ";
            query += "WHERE trunc(BeginDatum) = :datum ";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":datum", datum));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);
            List<NameValueCollection> schoonmaaklijst = new List<NameValueCollection>();

            while (odr.Read())
            {
                NameValueCollection schoonmaak = new NameValueCollection();

                int schoonmaaknr = Convert.ToInt32(odr["Schoonmaaknr"]);
                int tramnr = Convert.ToInt32(odr["TramNr"]);
                DateTime begindatum = Convert.ToDateTime(odr["BeginDatum"]);
                DateTime einddatumtijd = Convert.ToDateTime(odr["EindDatumTijd"]);
                string soortbeurt = Convert.ToString(odr["Soortbeurt"]);
                
                //int schoonmaaknr = odr.GetInt32(0);
                //int tramnr = odr.GetInt32(1);
                //DateTime begindatum = odr.GetDateTime(2);
                //DateTime einddatumtijd = odr.GetDateTime(3);
                //string soortbeurt = odr.GetString(4);
                schoonmaak.Add("Schoonmaaknr", Convert.ToString(schoonmaaknr));
                schoonmaak.Add("Tramnr", Convert.ToString(tramnr));
                schoonmaak.Add("BeginDatum", begindatum.ToString("dd-MM-yyyy"));
                schoonmaak.Add("EindDatumTijd", einddatumtijd.ToString("dd-MM-yyyy HH:mm"));
                schoonmaak.Add("Soortbeurt", soortbeurt);

                schoonmaaklijst.Add(schoonmaak);
            }
            return schoonmaaklijst;
        }

        public NameValueCollection HaalSchoonmakerOp(int schoonmaaknr)
        {
            NameValueCollection schoonmaker;
            string query = "SELECT distinct P.Voornaam ";
            query += "FROM Schoonmaak S, Persoon P ";
            query += "WHERE S.PersoonID = (SELECT persoonID From Schoonmaak where Schoonmaaknr = :schoonmaaknr and persoonID is not null) ";
            query += "AND P.PersoonID = S.PersoonID";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":schoonmaaknr", schoonmaaknr));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            schoonmaker = new NameValueCollection();

            if (odr.Read())
            {
                if (odr.GetString(0) == null)
                {
                    return null;
                }
                else
                {
                    string voornaam = odr.GetString(0);
                    schoonmaker.Add("Voornaam", voornaam);
                    return schoonmaker;
                }
            }
            else
            {
                return null;
            }
        }

        public void SchoonmaakbeurtKlaar(DateTime eindtijd, int persoonID, int schoonmaaknr)
        {
            string query = "UPDATE Schoonmaak ";
            query += "SET EindDatumTijd = :eindtijd, PersoonID = :persoonID ";
            query += "WHERE Schoonmaaknr = :onderhoudsnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":eindtijd", eindtijd));
            parameters.Add(new OracleParameter(":persoonID", persoonID));
            parameters.Add(new OracleParameter(":onderhoudsnr", schoonmaaknr));
            Database.ExecuteInsert(query, parameters);
        }

        public NameValueCollection HaalProfielIdOp(string voornaam, string achternaam)
        {
            NameValueCollection profielIdSchoonmaker;
            string query = "SELECT PersoonID ";
            query += "FROM Persoon ";
            query += "WHERE Voornaam = :voornaam ";
            query += "AND Achternaam = :achternaam";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":voornaam", voornaam));
            parameters.Add(new OracleParameter(":achternaam", achternaam));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            profielIdSchoonmaker = new NameValueCollection();

            if (odr.Read())
            {
                int persoonID = odr.GetInt32(0);
                profielIdSchoonmaker.Add("PersoonID", Convert.ToString(persoonID));
                return profielIdSchoonmaker;
            }
            else
            {
                return null;
            }
        }

        public int HaalMaxSchoonmaakNrOp()
        {
            string query = "SELECT MAX(Schoonmaaknr) ";
            query += "FROM Schoonmaak";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr.Read())
            {
                int schoonmaaknr = odr.GetInt32(0);
                return schoonmaaknr + 1;
            }
            else
            {
                return 0;
            }
        }

        public DateTime HaalLaatsteSchoonmaakdatumOp(int tramnr)
        {
            string query = "SELECT MIN(EindDatumTijd) ";
            query += "FROM Schoonmaak ";
            query += "WHERE Tramnr = :tramnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":tramnr", tramnr));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            while (odr.Read())
            {
                DateTime tempDate = DateTime.MinValue;
                DateTime laatsteEindDatum = DateTime.MinValue;
                if (DateTime.TryParse(odr[0].ToString(), out tempDate))
                    laatsteEindDatum = tempDate;
                return laatsteEindDatum;
            }
            return DateTime.MinValue;
        }

        public void MaakSchoonmaakbeurtAan(int Schoonmaaknr, int Tramnr, DateTime BeginDatum, string SoortBeurt)
        {
            string query = "Insert into SCHOONMAAK (SchoonmaakNr, TramNr, PersoonID, BeginDatum, EindDatumTijd, Soortbeurt) ";
            query += "values (:SchoonmaakNr, :TramNr, NULL, :BeginDatum, TO_DATE('01-01-0001 00:00','DD-MM-YYYY HH24:MI'), :Soortbeurt)";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":SchoonmaakNr", Schoonmaaknr));
            parameters.Add(new OracleParameter(":TramNr", Tramnr));
            parameters.Add(new OracleParameter(":BeginDatum", BeginDatum));
            parameters.Add(new OracleParameter(":Soortbeurt", SoortBeurt));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);
        }
    }
}
