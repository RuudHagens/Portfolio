﻿//-----------------------------------------------------------------------
// <copyright file="ConnectieOnderhoudSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Database
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Oracle.DataAccess.Client;

    public class ConnectieOnderhoudSysteem
    {
        public List<NameValueCollection> GeefReparatiesOpDag(DateTime datum)
        {
            string query = "SELECT OnderhoudsNr, TramNr, BeginDatumTijd, DatumTijdsIndicatie, EindDatumTijd, Soortbeurt ";
            query += "FROM Onderhoud ";
            query += "WHERE trunc(BeginDatumTijd) = :datum ";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":datum", datum));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);
            List<NameValueCollection> schoonmaaklijst = new List<NameValueCollection>();

            while (odr.Read())
            {
                NameValueCollection onderhoud = new NameValueCollection();

                int onderhoudsNr = Convert.ToInt32(odr["OnderhoudsNr"]);
                int tramnr = Convert.ToInt32(odr["TramNr"]);
                DateTime begindatumtijd = Convert.ToDateTime(odr["BeginDatumTijd"]);
                DateTime datumtijdsindicatie = Convert.ToDateTime(odr["DatumTijdsIndicatie"]);
                DateTime einddatumtijd = Convert.ToDateTime(odr["EindDatumTijd"]);
                string soortbeurt = Convert.ToString(odr["Soortbeurt"]);


                //int onderhoudsNr = odr.GetInt32(0);
                //int tramnr = odr.GetInt32(1);
                //DateTime begindatumtijd = odr.GetDateTime(2);
                //DateTime datumtijdsindicatie = odr.GetDateTime(3);
                //DateTime einddatumtijd = odr.GetDateTime(4);
                //string soortbeurt = odr.GetString(5);
                onderhoud.Add("OnderhoudsNr", Convert.ToString(onderhoudsNr));
                onderhoud.Add("Tramnr", Convert.ToString(tramnr));
                onderhoud.Add("BeginDatumTijd", begindatumtijd.ToString("dd-MM-yyyy"));
                onderhoud.Add("DatumTijdsIndicatie", datumtijdsindicatie.ToString("dd-MM-yyyy HH:mm"));
                onderhoud.Add("EindDatumTijd", einddatumtijd.ToString("dd-MM-yyyy HH:mm"));
                onderhoud.Add("Soortbeurt", soortbeurt);

                schoonmaaklijst.Add(onderhoud);
            }
            return schoonmaaklijst;
        }

        public NameValueCollection HaalTechnicusOp(int onderhoudsnr)
        {
            NameValueCollection onderhoud;
            string query = "SELECT distinct P.Voornaam ";
            query += "FROM Onderhoud O, Persoon P ";
            query += "WHERE O.PersoonID = (SELECT persoonID From Onderhoud where Onderhoudsnr = :onderhoudsnr and persoonID is not null) ";
            query += "AND P.PersoonID = O.PersoonID";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":onderhoudsnr", onderhoudsnr));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            onderhoud = new NameValueCollection();

            if (odr.Read())
            {
                if (odr.GetString(0) == null)
                {
                    return null;
                }
                else
                {
                    string voornaam = odr.GetString(0);
                    onderhoud.Add("Voornaam", voornaam);
                    return onderhoud;
                }
            }
            else
            {
                return null;
            }
        }

        public void OnderhoudsbeurtKlaar(DateTime eindtijd, int persoonID, int onderhoudsnr)
        {
            string query = "UPDATE Onderhoud ";
            query += "SET EindDatumTijd = :eindtijd, PersoonID = :persoonID ";
            query += "WHERE OnderhoudsNr = :onderhoudsnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":eindtijd", eindtijd));
            parameters.Add(new OracleParameter(":persoonID", persoonID));
            parameters.Add(new OracleParameter(":onderhoudsnr", onderhoudsnr));
            Database.ExecuteInsert(query, parameters);
        }

        public void TijdsindicatieAangeven(DateTime tijdsindicatie, int onderhoudsnr)
        {
            string query = "UPDATE Onderhoud ";
            query += "SET DatumTijdsIndicatie = :tijdsindicatie ";
            query += " WHERE OnderhoudsNr = :onderhoudsnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":tijdsindicatie", tijdsindicatie));
            parameters.Add(new OracleParameter(":onderhoudsnr", onderhoudsnr));
            Database.ExecuteInsert(query, parameters);
        }

        public void UpdateTramStatus(int tramstatus, int tramnr)
        {
            string query = "UPDATE Tram ";
            query += "SET StatusTramNr = :tramstatus ";
            query += "WHERE TramNr = :tramnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":tramstatus", tramstatus));
            parameters.Add(new OracleParameter(":tramnr", tramnr));
            Database.ExecuteInsert(query, parameters);
        }

        public NameValueCollection HaalProfielIdOp(string voornaam, string achternaam)
        {
            NameValueCollection profielIdTechnicus;
            string query = "SELECT PersoonID ";
            query += "FROM Persoon ";
            query += "WHERE Voornaam = :voornaam ";
            query += "AND Achternaam = :achternaam";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":voornaam", voornaam));
            parameters.Add(new OracleParameter(":achternaam", achternaam));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            profielIdTechnicus = new NameValueCollection();

            if (odr.Read())
            {
                int persoonID = odr.GetInt32(0);
                profielIdTechnicus.Add("PersoonID", Convert.ToString(persoonID));
                return profielIdTechnicus;
            }
            else
            {
                return null;
            }
        }

        public int HaalMaxOnderhoudsOp()
        {
            string query = "SELECT MAX(OnderhoudsNr) ";
            query += "FROM Onderhoud";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr.Read())
            {
                int onderhoudsnr = odr.GetInt32(0);
                return onderhoudsnr + 1;
            }
            else
            {
                return 0;
            }
        }

        public DateTime HaalLaatsteOnderhoudsdatumOp(int tramnr)
        {
            string query = "SELECT MIN(EindDatumTijd) ";
            query += "FROM Onderhoud ";
            query += "WHERE Tramnr = :tramnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":tramnr", tramnr));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);
            while (odr.Read())
            {
                DateTime tempDate = DateTime.MinValue;
                DateTime laatsteEindDatum = DateTime.MinValue;
                if(DateTime.TryParse(odr[0].ToString(), out tempDate)) 
                    laatsteEindDatum = tempDate;
                return laatsteEindDatum;                    
            }
            return DateTime.MinValue;
        }

        public void MaakOnderhoudsbeurtAan(int Onderhoudsnr, int Tramnr, DateTime BeginDatum, string SoortBeurt)
        {
            string query = "Insert into ONDERHOUD (OnderhoudsNr, TramNr, PersoonID, DatumTijdsIndicatie, BeginDatumTijd, EindDatumTijd, Soortbeurt) ";
            query += "values (:Onderhoudsnr, :TramNr, NULL, TO_DATE('01-01-0001 00:00','DD-MM-YYYY HH24:MI'), :BeginDatum, TO_DATE('01-01-0001 00:00','DD-MM-YYYY HH24:MI'), :Soortbeurt)";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":Onderhoudsnr", Onderhoudsnr));
            parameters.Add(new OracleParameter(":TramNr", Tramnr));
            parameters.Add(new OracleParameter(":BeginDatum", BeginDatum));
            parameters.Add(new OracleParameter(":Soortbeurt", SoortBeurt));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);
        }
    }
}
