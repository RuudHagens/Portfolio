﻿//-----------------------------------------------------------------------
// <copyright file="ConnectieWagenparkBeheerSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Database
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Specialized;
    using Oracle.DataAccess.Client;
    using Oracle.DataAccess.Types;
 
    public class ConnectieWagenparkBeheerSysteem
    {
        /// <summary>
        /// Checked of SpoorStatus bezet is.
        /// </summary>
        /// <param name="SpoorStatus">De status van de van het spoor</param>
        /// <returns>true als spoor bezet is, anders false</returns>
        public bool SpoorBezet(int spoorNr)
        {
            bool check = false;
            string query = "SELECT SPOORSTATUS FROM SPOOR WHERE SpoorNr = '" + spoorNr + "'";

            OracleDataReader odr = Database.ExecuteQry(query, null);

            while (odr.Read())
            {
                string status = odr.GetString(0);
                if(status == "bezet")
                {
                    check = true;
                }
            }
            return check;
        }

        public bool IsSectorVrijDatabase()
        {
            bool check = false;
            string query = "SELECT COUNT(SECTORID) FROM SECTOR WHERE STATUSSECTORNR = 3";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (!odr.HasRows)
            {
                return check;
            }

            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                int aantal = Convert.ToInt32(x);
                if (aantal > 0)
                {
                    check = true;
                }
                return check;
            }
            return check;
        }

        public string HaalLijnNrOp(int spoorNr)
        {
            string lijnNr = "";

            string query = "SELECT LijnNr FROM SPOOR WHERE SpoorNr = :spoorNr";


            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("spoorNr", spoorNr));


            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                return lijnNr;
            }
             
                while (odr.Read())
                {
                    lijnNr = odr.GetString(0);
                    
                }
                return lijnNr;
            }

        public int HaalHoogsteSectorOpDatabase(int spoorNr)
        {
            // ik vraag het hoogste sector nummer op van het desbetreffende spoor.
            // Dit wil ik weten omdat de volgende tram die word ingevoerd op dit spoor altijd minimaal één sector hoger moet staan.
            int hoogsteSector = 1;
            string query = "SELECT (maxgevuld.hoogstgevuld +1) AS LegeSector FROM (SELECT COUNT(SECTORNR) AS Grootste FROM SECTOR WHERE SpoorNr = :spoorNr) totaal, (SELECT MAX(SECTORNR)as hoogstgevuld FROM SECTOR WHERE SpoorNr = :spoorNr AND (StatusSectorNr = 1 OR StatusSectorNr = 2)) maxgevuld WHERE totaal.Grootste > maxgevuld.hoogstgevuld";
            
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("spoorNr", spoorNr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                return hoogsteSector;
            }
            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                hoogsteSector = Convert.ToInt32(x);
            }
            return hoogsteSector;
        }

        public int HaalHoogsteBezetteSectorOp(int spoorNr)
        {
            int SectorNr = 0;
            string query = "SELECT SECTORNR FROM (SELECT SECTORNR FROM SECTOR WHERE SPOORNR = :spoorNr AND STATUSSECTORNR = 1 ORDER BY SECTORNR DESC) WHERE ROWNUM = 1";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("spoorNr", spoorNr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                return SectorNr;
            }
            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                SectorNr = Convert.ToInt32(x);
            }
            return SectorNr;
        }

        public int FindTramStatusNr(string tramStatus)
        {
            int TramStatusNr =0;
            string query = "SELECT STATUSTRAMNR FROM STATUSTRAM WHERE BESCHRIJVING =:tramStatus";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramStatus", tramStatus));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                throw new Exception("Status van de tram niet bekend");
            }

            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                TramStatusNr = Convert.ToInt32(x);
            }
            return TramStatusNr;
        }

        public int HaalStatusSectorOp(int spoornr, int sectornr)
        {
            int SectorStatusNr = 0;
            string query = "SELECT STATUSSECTORNR FROM SECTOR WHERE SPOORNR = :spoornr AND SECTORNR =:sectornr";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("spoornr", sectornr));
            parameters.Add(new OracleParameter("sectornr", sectornr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                throw new Exception("Sector is geblokkeerd");
            }
            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                SectorStatusNr = Convert.ToInt32(x);
            }
            return SectorStatusNr;
        }

        /// <summary>
        /// Deze methode kijkt hoeveel trams er in de database aanwezig zijn
        /// </summary>
        /// <returns>Het aantal trams aanwezig in de database</returns>
        public int HaalAantalTramsOp()
        {
            int aantalTrams = 0;
            string query = "SELECT COUNT(TramNr) ";
            query += "FROM tram";

            OracleDataReader odr = Database.ExecuteQry(query, null);

            if(!odr.HasRows)
            {
                return aantalTrams;
            }
            while (odr.Read())
            {
                aantalTrams = Convert.ToInt32(odr["COUNT(TramNr)"]);
            } 
            return aantalTrams;
        }

        /// <summary>
        /// Haalt alle trams op uit de database
        /// </summary>
        /// <returns>Een lijst met de trams</returns>
        public List<int> HaalTramsOp()
        {
            List<int> lijstVanTrams = new List<int>();
            string query = "SELECT DISTINCT TramNr ";
            query += "FROM tram";

            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (!odr.HasRows)
            {
                return null;
            }
            while(odr.Read())
            {
                int tram = Convert.ToInt32(odr["TramNr"]);
                lijstVanTrams.Add(tram);
            }
            return lijstVanTrams;
        }

        public List<int> HaalTramsNrInRemiseOP()
        {
            List<int> lijstVanTramNrs = new List<int>();
            string query = "SELECT TRAMNR FROM TRAM WHERE STATUSTRAMNR = 4";

            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (!odr.HasRows)
            {
                return null;
            }
            while (odr.Read())
            {
                int tramnr = Convert.ToInt32(odr["TramNr"]);
                lijstVanTramNrs.Add(tramnr);
            }
            return lijstVanTramNrs;
            
        }

        public int HaalSpoorNrOp(int tramNr)
        {
            int SpoorNr = 0; 
            string query = "SELECT SpoorNr FROM SECTOR WHERE SECTORID = (SELECT SECTORID FROM TRAM WHERE TRAMNR = :tramNr)";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramNr", tramNr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                throw new Exception("Geen spoorNr gevonden");
            }
            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                SpoorNr = Convert.ToInt32(x);
            }
            return SpoorNr;
        }

        public bool IsStatusRemise(int tramnr)
        {
            bool TramStatusNr = false;
            string query = "SELECT STATUSTRAMNR FROM TRAM WHERE TRAMNR = :tramnr";
            
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramnr", tramnr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                throw new Exception("Geen status gevonden");
            }

            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                int TramStatusNri = Convert.ToInt32(x);
                if (TramStatusNri == 4)
                {
                    TramStatusNr = true;
                    return TramStatusNr;
                }
            }
            return TramStatusNr;
        }

        public int HaalSectorNrOp(int tramNr)
        {
            int SectorNr = 0;
            string query = "SELECT SectorNr FROM SECTOR WHERE SECTORID = (SELECT SECTORID FROM TRAM WHERE TRAMNR = :tramNr)";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramNr", tramNr));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (odr != null)
            {
                if (!odr.HasRows)
                {
                    throw new Exception("Geen sectorNr gevonden");
                }
                while (odr.Read())
                {
                    decimal x = odr.GetDecimal(0);
                    SectorNr = Convert.ToInt32(x);
                }
            }
            return SectorNr;
        }
        

        public int FindSectorID(int tramnr)
        {
            int SectorID = 0;
            string query = "SELECT SECTORID FROM TRAM WHERE TRAMNR =:tramnr";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramnr", tramnr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                throw new Exception("Sector bestaat niet");
            }
            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                SectorID = Convert.ToInt32(x);
            }
            return SectorID;
        }

        public int FindSectorID(int spoornr, int sectornr)
        {
            int SectorID = 0;
            string query = "SELECT SECTORID FROM SECTOR WHERE SPOORNR =:spoornr AND SECTORNR =:sectornr";

            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("spoornr", spoornr));
            parameters.Add(new OracleParameter("sectornr", sectornr));

            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (!odr.HasRows)
            {
                throw new Exception("Sector bestaat niet");
            }
            while (odr.Read())
            {
                decimal x = odr.GetDecimal(0);
                SectorID = Convert.ToInt32(x);
            }
            return SectorID;
        }

        public void UpdateSector(int sectorID)
        {
            string query = "UPDATE SECTOR SET STATUSSECTORNR = 1 WHERE SECTORID = :sectorID";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("sectorID", sectorID));

            Database.ExecuteInsert(query,parameters);
        }

        public void UpdateSectorVrij(int sectorID)
        {
            string query = "UPDATE SECTOR SET STATUSSECTORNR = 3 WHERE SECTORID = :sectorID";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("sectorID", sectorID));

            Database.ExecuteInsert(query, parameters);
        }

        public void VeranderTramStatusRemiseDatabase(int tramNr)
        {
            string query = "UPDATE TRAM SET STATUSTRAMNR = 3, SECTORID = NULL WHERE TRAMNR = :tramNr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramNr", tramNr));

            Database.ExecuteInsert(query, parameters);
        }

        public void VeranderTramStatusSchoonmaakDatabase(int tramNr)
        {
            string query = "UPDATE TRAM SET STATUSTRAMNR = 1, SECTORID = NULL WHERE TRAMNR = :tramNr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramNr", tramNr));

            Database.ExecuteInsert(query, parameters);
        }

        public void VeranderTramStatusDefectDatabase(int tramNr)
        {
            string query = "UPDATE TRAM SET STATUSTRAMNR = 2, SECTORID = NULL WHERE TRAMNR = :tramNr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("tramNr", tramNr));

            Database.ExecuteInsert(query, parameters);
        }

        public void UpdateTram(int tramStatus, int sectorID, int tramnr)
        {
            string query2 = "UPDATE TRAM SET StatusTramNr = :tramStatus, SectorID = :sectorID WHERE TramNr = :tramnr";
            List<OracleParameter> parameters2 = new List<OracleParameter>();
            parameters2.Add(new OracleParameter("tramStatus", tramStatus));
            parameters2.Add(new OracleParameter("sectorID", sectorID));
            parameters2.Add(new OracleParameter("tramnr", tramnr));
            

            Database.ExecuteInsert(query2, parameters2);
        }

        /// <summary>
        /// Haalt alle sporen op uit de database
        /// </summary>
        /// <returns>Een lijst met alle sporen</returns>
        public List<int> HaalAlleSporenOp()
        {
            List<int> lijstVanSporen = new List<int>();
            string query = "SELECT DISTINCT SpoorNr ";
            query += "FROM Spoor";

            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (!odr.HasRows)
            {
                return null;
            }
            while (odr.Read())
            {
                int spoor = Convert.ToInt32(odr["SpoorNr"]);
                lijstVanSporen.Add(spoor);
            }
            return lijstVanSporen;
        }

        public void ZetSectorsOnderParameterSectorOpGeblokkeerd(int sectorNr)
        {
            string query = "UPDATE TRAM SET StatusTramNr = :tramStatus, SectorID = :sectorID WHERE TramNr = :tramnr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":sectorNr", sectorNr));

            Database.ExecuteInsert(query, parameters);
        }

        public void ZetSectorOpGeblokkeerd(string spoornr, string sectornr)
        {
            string query = "UPDATE SECTOR SET STATUSSECTORNR = 2 WHERE SPOORNR = :spoornr AND SECTORNR =:sectornr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter("spoornr", spoornr));
            parameters.Add(new OracleParameter("sectornr", sectornr));

            Database.ExecuteInsert(query, parameters);
        }

        public List<NameValueCollection> HaalAlleGeblokkeerdeSectorenOp()
        {
            List<NameValueCollection> geblokkeerdeSectoren;
            string query = "SELECT SECTORNR,SPOORNR FROM SECTOR WHERE STATUSSECTORNR = 2";
                        
            OracleDataReader odr = Database.ExecuteQry(query, null  );

            geblokkeerdeSectoren = new List<NameValueCollection>();

            if(!odr.HasRows)
            {
                return null;
            }
            while (odr.Read())
            {
                NameValueCollection geblokkeerdeSector = new NameValueCollection();
                string sectornr = odr.GetString(0);
                string spoornr = odr.GetString(1);
                geblokkeerdeSector.Add("SECTORNR", Convert.ToString(sectornr));
                geblokkeerdeSector.Add("SPOORNR", Convert.ToString(spoornr));
                geblokkeerdeSectoren.Add(geblokkeerdeSector);
            }
            return geblokkeerdeSectoren;
        }
    }
}
