﻿//-----------------------------------------------------------------------
// <copyright file="ConnectieTramSysteem.cs" company="S21MA">
//     Copyright (c) S21MA. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Database
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Collections.Specialized;
    using Oracle.DataAccess.Client;
    using Oracle.DataAccess.Types;

    /// <summary>
    /// Klasse die de queries bevat van het tram systeem.
    /// </summary>
    public class ConnectieTramSysteem
    {
        //Methode om het type van een tram op te halen.
        public string HaalTramType(int tramNr)
        {
            string tramType = null;

            string query = "select BESCHRIJVING from TRAMTYPE where TRAMTYPENR = ( select TRAMTYPENR from TRAM where TRAMNR = :tramNr) ";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":tramNr", tramNr));
            
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (odr != null)
            {
                if (odr.Read())
                {
                    tramType = odr.GetString(0);
                }
            }

            return tramType;
        }

        //Methode om een spoor op te halen dat voor schoonmaak is.
        public string HaalSchoonmaakSpoorOp(out string sector)
        {
            string spoor = null;
            sector = null;

            string query = "select SPOORNR, SECTORNR from( Select * from Sector Where STATUSSECTORNR = '3'  AND spoornr between '12' and '21' order by SECTORNR asc ) alles Where ROWNUM = 1";
            
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    spoor = odr.GetInt32(0).ToString();
                    sector = odr.GetInt32(1).ToString();
                }
            }

            return spoor;
        }

        //Methode om een spoor op te halen dat voor onderhoud is.
        public string HaalOnderhoudSpoorOp(out string sector)
        {
            string spoor = null;
            sector = null;

            string query = "select SPOORNR, SECTORNR from( Select * from Sector Where STATUSSECTORNR = '3' AND spoornr between '74' and '77' order by SECTORNR asc ) alles Where ROWNUM = 1";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    spoor = odr.GetInt32(0).ToString();
                    sector += odr.GetInt32(1).ToString();
                }
            }

            return spoor;
        }

        //Methode om een spoor op te halen waar een tram kan staan.
        public string HaalSpoorOp(out string sector)
        {
            string spoor = null;
            sector = null;

            string query = "select SPOORNR, SECTORNR from( Select * from Sector Where STATUSSECTORNR = '3' AND (spoornr != '40' AND spoornr != '37' AND spoornr != '42'  AND spoornr != '56'  AND spoornr != '54' AND spoornr != '35' AND spoornr != '33' AND spoornr != '30' AND spoornr != '57' AND spoornr not between '74' and '77' AND spoornr not between '12' and '21') order by SECTORNR asc) alles Where ROWNUM = 1";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    spoor = odr.GetInt32(0).ToString();
                    sector = odr.GetInt32(1).ToString();
                }
            }

            return spoor;
        }

        //Methode om een spoor op te halen dat voor lijn 5 is.
        public string Haal11GSpoorOp(out string sector)
        {
            string spoor = null;
            sector = null;

            string query = "select SPOORNR, SECTORNR from(Select * from Sector Where STATUSSECTORNR = '3' AND( spoornr = '37' OR spoornr = '42'  OR spoornr = '56'  OR spoornr = '54') order by SECTORNR asc ) alles Where ROWNUM = 1";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    spoor = odr.GetInt32(0).ToString();
                    sector = odr.GetInt32(1).ToString();
                }
            }

            return spoor;
        }

        //Methode om een spoor op te halen dat voor lijn 16/24 is.
        public string Haal12GSpoorOp(out string sector)
        {
            string spoor = null;
            sector = null;

            string query = "select SPOORNR, SECTORNR from( Select * from Sector Where STATUSSECTORNR = '3' AND( spoornr = '35' OR spoornr = '33' OR spoornr = '30' OR spoornr = '57') order by SECTORNR asc) alles Where ROWNUM = 1";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    spoor = odr.GetInt32(0).ToString();
                    sector = odr.GetInt32(1).ToString();
                }
            }
            
            return spoor;
        }

        //Methode om de status van een tram te veranderen in schoonmaak.
        public void VeranderStatusTramSchoonmaak(int tramNr)
        {
            int statusNr = 0;

            string query = "SELECT STATUSTRAMNR FROM STATUSTRAM WHERE BESCHRIJVING = 'Schoonmaak'";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    statusNr = odr.GetInt32(0);
        }
            }

            string query2 = "UPDATE TRAM SET STATUSTRAMNR = :statusNr WHERE tramNr = :tramNr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":statusNr", statusNr));
            parameters.Add(new OracleParameter(":tramNr", tramNr));
            Database.ExecuteInsert(query2,parameters);
        }

        //Methode om de status van een tram te veranderen in onderhoud.
        public void VeranderStatusTramOnderhoud(int tramNr)
        {
            int statusNr = 0;

            string query = "SELECT STATUSTRAMNR FROM STATUSTRAM WHERE BESCHRIJVING = 'Defect'";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    statusNr = odr.GetInt32(0);
                }
            }

            string query2 = "UPDATE TRAM SET STATUSTRAMNR = '" + statusNr + "' WHERE tramNr = '" + tramNr + "'";
            Database.ExecuteInsert(query2, null);
        }

        //Methode om de status van een tram te veranderen in remise.
        public void VeranderStatusTramRemise(int tramNr)
        {
            int statusNr = 0;

            string query = "SELECT STATUSTRAMNR FROM STATUSTRAM WHERE BESCHRIJVING = 'Remise'";
            OracleDataReader odr = Database.ExecuteQry(query, null);

            if (odr != null)
            {
                if (odr.Read())
                {
                    statusNr = odr.GetInt32(0);
                }
            }

            string query2 = "UPDATE TRAM SET STATUSTRAMNR = '" + statusNr + "' WHERE tramNr = '" + tramNr + "'";
            Database.ExecuteInsert(query2, null);
        }

        //Methode om een tram een sector te geven op basis van een spoor en sector nummer.
        public void GeefEenTramSector(int tramNr, int spoorNr, int sectorNr)
        {
            int sectorId = 0;

            string query = "select sectorid from sector where sectornr = :sectornr and spoornr = :spoornr";
            List<OracleParameter> parameters = new List<OracleParameter>();
            parameters.Add(new OracleParameter(":sectornr", sectorNr));
            parameters.Add(new OracleParameter(":spoornr", spoorNr));
            OracleDataReader odr = Database.ExecuteQry(query, parameters);

            if (odr != null)
            {
                if (odr.Read())
                {
                    sectorId = odr.GetInt32(0);
                }
            }

            string query2 = "UPDATE TRAM SET SECTORID = :sectorId WHERE tramNr = :tramNr";
            List<OracleParameter> parameters2 = new List<OracleParameter>();
            parameters2.Add(new OracleParameter(":sectorId", sectorId));
            parameters2.Add(new OracleParameter(":tramNr", tramNr));
            Database.ExecuteInsert(query2, parameters2);

            string query3 = "UPDATE SECTOR SET STATUSSECTORNR = '1' WHERE SECTORID = :sectorId";
            List<OracleParameter> parameters3 = new List<OracleParameter>();
            parameters3.Add(new OracleParameter(":sectorId", sectorId));
            Database.ExecuteInsert(query3, parameters3);
        }

    }
}
